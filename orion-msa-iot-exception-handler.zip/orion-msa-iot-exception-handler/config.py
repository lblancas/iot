#!/usr/bin/env python3
"""
Configuration management for Exception Handler microservice
"""

import os
import json
import logging
import boto3
from botocore.exceptions import ClientError
from typing import Dict, Any

logger = logging.getLogger("orion-exception-handler")

class Config:
    """Configuration manager for Exception Handler microservice"""
    
    def __init__(self):
        self.AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
        self.AWS_SECRET_NAME = os.getenv("AWS_SECRET_NAME")
        self.PORT = int(os.getenv("PORT", 40085))
        
        if not self.AWS_SECRET_NAME:
            raise ValueError("AWS_SECRET_NAME environment variable is required")
    
    def get_secrets(self) -> Dict[str, Any]:
        """Get secrets from AWS Secrets Manager"""
        try:
            session = boto3.session.Session()
            client = session.client("secretsmanager", region_name=self.AWS_REGION)
            
            response = client.get_secret_value(SecretId=self.AWS_SECRET_NAME)
            secrets = json.loads(response["SecretString"])
            
            logger.info("✓ Successfully retrieved secrets from AWS Secrets Manager")
            return secrets
            
        except ClientError as e:
            logger.error(f"❌ Error retrieving secrets from {self.AWS_SECRET_NAME}: {e}")
            raise
        except Exception as e:
            logger.error(f"❌ Unexpected error retrieving secrets: {e}")
            raise

# Global config instance
config = Config()