#!/usr/bin/env python3
"""
Exception Manager for Exception Handler Microservice
Handles RabbitMQ connections and message routing
"""

import asyncio
import logging
from typing import Dict, Any, Callable, Optional

from rabbitmq_client import RabbitMQClient, create_rabbitmq_client

logger = logging.getLogger("orion-exception-handler")

class ExceptionHandlerManager:
    """Manager for exception handler RabbitMQ operations"""
    
    def __init__(self, rabbitmq_config: Dict[str, Any]):
        self.rabbitmq_config = rabbitmq_config
        self.rabbitmq_client: Optional[RabbitMQClient] = None
        self._initialized = False
        
    async def initialize(self) -> None:
        """Initialize RabbitMQ connections"""
        try:
            if self._initialized:
                logger.info("✅ Exception manager already initialized")
                return
                
            logger.info("🔄 Initializing exception handler manager...")
            
            # Initialize RabbitMQ client
            self.rabbitmq_client = create_rabbitmq_client(
                host=self.rabbitmq_config["host"],
                environment=self.rabbitmq_config.get("environment", "dev"),
                username=self.rabbitmq_config.get("username", "orion_admin"),
                password=self.rabbitmq_config.get("password", "OrionMQ2024!")
            )
            
            await self.rabbitmq_client.connect()
            logger.info("✅ RabbitMQ client connected")
            
            # Declare exception handler queue
            await self.rabbitmq_client.declare_queue("exception-handler")
            
            # Bind exception handler queue to receive error messages
            queue = self.rabbitmq_client._queues["exception-handler"]
            await queue.bind(
                self.rabbitmq_client._exchange,
                routing_key="orion.exception-handler.notification"  # Correct routing key from state-handler
            )
            
            self._initialized = True
            logger.info("✅ Exception handler manager initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize exception manager: {e}")
            raise
    
    async def start_consuming(self, message_handler: Callable[[Dict[str, Any]], None]) -> None:
        """Start consuming exception messages from RabbitMQ"""
        try:
            if not self._initialized:
                raise RuntimeError("Exception manager not initialized")
                
            if not self.rabbitmq_client:
                raise RuntimeError("RabbitMQ client not available")
            
            logger.info("🔄 Starting to consume exception messages...")
            
            # Start consuming from exception-handler queue
            await self.rabbitmq_client.consume_messages(
                service="exception-handler",
                callback=message_handler,
                auto_ack=False  # Manual acknowledgment for reliability
            )
            
            logger.info("✅ Started consuming exception messages from RabbitMQ")
            
        except Exception as e:
            logger.error(f"❌ Error starting message consumption: {e}")
            raise
    
    async def health_check(self) -> bool:
        """Check health of RabbitMQ connection"""
        try:
            if not self.rabbitmq_client:
                return False
            return await self.rabbitmq_client.health_check()
        except Exception as e:
            logger.error(f"❌ Health check failed: {e}")
            return False
    
    async def disconnect(self) -> None:
        """Disconnect from RabbitMQ"""
        try:
            if self.rabbitmq_client:
                await self.rabbitmq_client.disconnect()
                logger.info("🔌 Exception manager disconnected from RabbitMQ")
        except Exception as e:
            logger.error(f"❌ Error disconnecting exception manager: {e}")

# Global exception manager instance
_exception_manager: Optional[ExceptionHandlerManager] = None

def get_exception_manager() -> ExceptionHandlerManager:
    """Get or create the global exception manager instance"""
    global _exception_manager
    
    if _exception_manager is None:
        raise RuntimeError("Exception manager not configured. Call setup_exception_manager() first.")
    
    return _exception_manager

def setup_exception_manager(rabbitmq_config: Dict[str, Any]) -> None:
    """Setup the global exception manager with configuration"""
    global _exception_manager
    _exception_manager = ExceptionHandlerManager(rabbitmq_config)