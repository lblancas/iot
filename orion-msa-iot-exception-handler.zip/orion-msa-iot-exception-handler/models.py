#!/usr/bin/env python3
"""
Data models for Exception Handler microservice
"""

from typing import Dict, Any, Optional
from datetime import datetime
from pydantic import BaseModel

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str
    service: str
    timestamp: datetime
    version: str

class ExceptionMessage(BaseModel):
    """Exception message model from other services"""
    transaction_folio: str
    operation_type: str
    current_step: str
    status: str
    payload: Dict[str, Any]
    execution_start_time: datetime
    execution_end_time: datetime
    execution_total_time: str
    response_code: str
    response_message: str
    error_details: Optional[str] = None