#!/usr/bin/env python3
"""
Exception Handler Microservice
Processes exception messages from other microservices for monitoring and alerting
"""

import os
import sys
import json
import asyncio
import logging
import threading
from datetime import datetime
from typing import Dict, Any, List
from fastapi import FastAPI
import uvicorn
import uvloop

from config import config
from models import HealthResponse, ExceptionMessage
from exception_manager import get_exception_manager, setup_exception_manager

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("orion-exception-handler")

# FastAPI app for health endpoint
app = FastAPI(title="Exception Handler Microservice", version="1.0.0")

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    rabbitmq_accessible = False
    
    try:
        # Test RabbitMQ connection
        exception_manager = get_exception_manager()
        rabbitmq_accessible = await exception_manager.health_check()
    except Exception as e:
        logger.warning(f"RabbitMQ health check failed: {e}")
    
    overall_status = "healthy" if rabbitmq_accessible else "degraded"
    
    return HealthResponse(
        status=overall_status,
        service="exception-handler", 
        timestamp=datetime.now(),
        version="1.0.0"
    )

async def handle_exception_message(message_body: Dict[str, Any]) -> None:
    """Handle a single exception message from RabbitMQ"""
    try:
        # Extract exception details
        transaction_folio = message_body.get("transaction_folio", "N/A")
        operation_type = message_body.get("operation_type", "N/A")
        current_step = message_body.get("current_step", "N/A")
        status = message_body.get("status", "unknown")
        response_code = message_body.get("response_code", "unknown")
        response_message = message_body.get("response_message", "No message")
        execution_time = message_body.get("execution_total_time", "unknown")
        
        logger.info(f"📥 Exception received: {transaction_folio}, {current_step}, {operation_type}, {status}")
        
        # ONLY process error messages - exception handler should only receive errors
        if status == "error":
            logger.error(f"❌ EXCEPTION ALERT: {transaction_folio}, {current_step}, {operation_type}, {response_code}, {response_message}, {execution_time}ms")
            
            # TODO: Add processing logic:
            # - Send to alerting system (SNS, Slack, etc.)
            # - Store in error database for analysis
            # - Generate metrics for monitoring dashboards
            # - Send notifications based on error type/severity
            
        else:
            logger.warning(f"⚠️ Non-error in exception queue: {transaction_folio}, {current_step}, {status}")
            
    except Exception as e:
        logger.error(f"❌ Error processing exception message: {e}")
        import traceback
        logger.error(f"🔍 Exception traceback: {traceback.format_exc()}")

async def process_messages():
    """Message processing with RabbitMQ support"""
    try:
        # Get configuration
        secrets = config.get_secrets()
        
        # Setup RabbitMQ configuration
        rabbitmq_config = {
            "host": secrets["rabbitmq_host"],
            "environment": secrets.get("environment", "dev"),
            "username": secrets.get("rabbitmq_username", "orion_admin"),
            "password": secrets.get("rabbitmq_password", "OrionMQ2024!")
        }
        
        # Initialize exception manager
        setup_exception_manager(rabbitmq_config)
        exception_manager = get_exception_manager()
        await exception_manager.initialize()
        
        logger.info("✅ Exception handler manager initialized")
        logger.info("🚀 Starting RabbitMQ exception message processing...")
        
        # Start consuming from RabbitMQ
        await exception_manager.start_consuming(handle_exception_message)
        logger.info("✅ RabbitMQ mode: Started consuming exception messages")
        
        # Keep running (RabbitMQ handles the message loop)
        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            logger.info("🛑 Shutting down...")
            await exception_manager.disconnect()
            
    except Exception as e:
        logger.error(f"❌ Fatal error in process_messages: {e}")
        raise

def run_fastapi():
    """Run FastAPI server in a separate thread"""
    uvicorn.run(app, host="0.0.0.0", port=config.PORT, log_level="info")

async def main():
    """Main function to run both FastAPI and message processing"""
    try:
        # Start FastAPI in a separate thread
        fastapi_thread = threading.Thread(target=run_fastapi, daemon=True)
        fastapi_thread.start()
        
        logger.info(f"Health endpoint available at http://0.0.0.0:{config.PORT}/health")
        
        # Start message processing
        await process_messages()
        
    except Exception as e:
        logger.error(f"Fatal error in main: {e}")
        raise

if __name__ == "__main__":
    try:
        # Configure uvloop for ultra-high performance async I/O (2-4x faster)
        logger.info("🚀 Configuring uvloop for ultra-high performance...")
        asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
        logger.info("✅ uvloop configured - async operations will be 2-4x faster")
        
        # Run main application with high-performance event loop
        asyncio.run(main())
        
    except KeyboardInterrupt:
        logger.info("🛑 Shutting down...")
    except Exception as e:
        logger.error(f"❌ Application error: {e}")
        sys.exit(1)