package main

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"

	"terminal-health-monitor/internal/core/domain"
	
	"terminal-health-monitor/internal/handlers"
)

type MockTerminalStatusRepository struct {
	mock.Mock
}

func (m *MockTerminalStatusRepository) Get(ctx context.Context, correlationID uuid.UUID) (*domain.TerminalStatus, error) {
	args := m.Called(ctx, correlationID)
	return args.Get(0).(*domain.TerminalStatus), args.Error(1)
}

func (m *MockTerminalStatusRepository) Upsert(ctx context.Context, status *domain.TerminalStatus) error {
	args := m.Called(ctx, status)
	return args.Error(0)
}

func TestAPI_UpdateTerminalStatus(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.Default()

	repo := new(MockTerminalStatusRepository)
	apiHandler := handlers.NewAPIHandler(repo)

	r.PUT("/terminals/:correlation_id/status", apiHandler.UpdateTerminalStatus)

	correlationID := uuid.New()
	requestBody := map[string]string{"status": "online"}
	jsonBody, _ := json.Marshal(requestBody)

	repo.On("Upsert", mock.Anything, mock.AnythingOfType("*domain.TerminalStatus")).Return(nil).Run(func(args mock.Arguments) {
		statusArg := args.Get(1).(*domain.TerminalStatus)
		assert.Equal(t, correlationID, statusArg.CorrelationID)
		assert.Equal(t, "online", statusArg.Status)
	})

	req, _ := http.NewRequest(http.MethodPut, "/terminals/"+correlationID.String()+"/status", bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")

	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusOK, w.Code)
	repo.AssertExpectations(t)
}
