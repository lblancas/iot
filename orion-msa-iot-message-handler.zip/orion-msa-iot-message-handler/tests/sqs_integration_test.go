package main

import (
	"context"
	"encoding/json"
	"testing"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sqs"
	"github.com/aws/aws-sdk-go-v2/service/sqs/types"
	"github.com/google/uuid"
	"github.com/stretchr/testify/mock"

	"terminal-health-monitor/internal/core/domain"
	"terminal-health-monitor/internal/handlers"
)

type MockSQSClient struct {
	mock.Mock
}

func (m *MockSQSClient) ReceiveMessage(ctx context.Context, params *sqs.ReceiveMessageInput, optFns ...func(*sqs.Options)) (*sqs.ReceiveMessageOutput, error) {
	args := m.Called(ctx, params, optFns)
	return args.Get(0).(*sqs.ReceiveMessageOutput), args.Error(1)
}

func (m *MockSQSClient) DeleteMessage(ctx context.Context, params *sqs.DeleteMessageInput, optFns ...func(*sqs.Options)) (*sqs.DeleteMessageOutput, error) {
	args := m.Called(ctx, params, optFns)
	return args.Get(0).(*sqs.DeleteMessageOutput), args.Error(1)
}

type MockHealthCheckService struct {
	mock.Mock
}

func (m *MockHealthCheckService) ProcessHealthCheck(ctx context.Context, message []byte) error {
	args := m.Called(ctx, message)
	return args.Error(0)
}

func TestSQSHandler_Start(t *testing.T) {
	sqsClient := new(MockSQSClient)
	healthSvc := new(MockHealthCheckService)
	queueURL := "test-queue-url"

	handler := handlers.NewSQSHandler(sqsClient, queueURL, healthSvc)

	ctx, cancel := context.WithCancel(context.Background())

	correlationID := uuid.New()
	msgBody := domain.HealthCheckMessage{
		Payload: struct {
			CorrelationID   uuid.UUID `json:"correlation_id"`
			FlowID          string    `json:"flow_id"`
			NextStep        struct {
				Topic string `json:"topic"`
			} `json:"next_step"`
			OriginalMessage json.RawMessage `json:"original_message"`
		}{
			CorrelationID:   correlationID,
			FlowID:          "test-flow-id",
			NextStep:        struct{ Topic string `json:"topic"` }{Topic: "next-step-queue"},
			OriginalMessage: []byte(`{"foo":"bar"}`),
		},
	}
	msgBodyBytes, _ := json.Marshal(msgBody)

	sqsClient.On("ReceiveMessage", mock.Anything, mock.Anything, mock.Anything).Return(
		&sqs.ReceiveMessageOutput{
			Messages: []types.Message{
				{
					Body:          aws.String(string(msgBodyBytes)),
					ReceiptHandle: aws.String("test-receipt-handle"),
				},
			},
		},
		nil,
	).Once()

	sqsClient.On("ReceiveMessage", mock.Anything, mock.Anything, mock.Anything).Return(
		&sqs.ReceiveMessageOutput{},
		nil,
	)

	healthSvc.On("ProcessHealthCheck", mock.Anything, msgBodyBytes).Return(nil).Once()
	sqsClient.On("DeleteMessage", mock.Anything, mock.Anything, mock.Anything).Return(&sqs.DeleteMessageOutput{}, nil).Once()

	go handler.Start(ctx)

	// Wait for the message to be processed and deleted
	time.Sleep(100 * time.Millisecond)
	cancel()

	sqsClient.AssertExpectations(t)
	healthSvc.AssertExpectations(t)
}