package domain

import (
	"encoding/json"
	"time"

	"github.com/google/uuid"
)

type TerminalStatus struct {
	CorrelationID uuid.UUID `db:"correlation_id"`
	Status        string    `db:"status"`
	LastUpdatedAt time.Time `db:"last_updated_at"`
}

type HealthCheckMessage struct {
	Metadata struct {
		MessageID string    `json:"message_id"`
		Timestamp time.Time `json:"timestamp"`
	} `json:"metadata"`
	Payload struct {
		CorrelationID   uuid.UUID `json:"correlation_id"`
		FlowID          string    `json:"flow_id"`
		NextStep        struct {
			Topic string `json:"topic"`
		} `json:"next_step"`
		OriginalMessage json.RawMessage `json:"original_message"`
	} `json:"payload"`
}

type AuditMessage struct {
	EventType string `json:"event_type"`
	Timestamp time.Time `json:"timestamp"`
	Details   struct {
		CorrelationID string `json:"correlation_id"`
		FlowID        string `json:"flow_id"`
		Message       string `json:"message"`
	} `json:"details"`
}

type GatewayMessage struct {
	Status        string `json:"status"`
	CorrelationID string `json:"correlation_id"`
	FlowID        string `json:"flow_id"`
	Error         struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}
