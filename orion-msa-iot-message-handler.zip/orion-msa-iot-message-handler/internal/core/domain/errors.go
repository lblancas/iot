package domain

import "fmt"

type NotFoundError struct {
	Message string
}

func (e *NotFoundError) Error() string {
	return e.Message
}

type BadRequestError struct {
	Message string
}

func (e *BadRequestError) Error() string {
	return e.Message
}

type InternalServerError struct {
	Message string
}

func (e *InternalServerError) Error() string {
	return e.Message
}

func NewNotFoundError(message string) error {
	return &NotFoundError{Message: message}
}

func NewBadRequestError(message string) error {
	return &BadRequestError{Message: message}
}

func NewInternalServerError(message string) error {
	return &InternalServerError{Message: message}
}

func NewErrorf(format string, a ...interface{}) error {
	return fmt.Errorf(format, a...)
}
