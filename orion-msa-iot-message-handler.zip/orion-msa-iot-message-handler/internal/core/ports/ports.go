package ports

import (
	"context"
	"encoding/json"

	"github.com/aws/aws-sdk-go-v2/service/sqs"
	"github.com/google/uuid"

	"terminal-health-monitor/internal/core/domain"
)

type SQSClientAPI interface {
	ReceiveMessage(ctx context.Context, params *sqs.ReceiveMessageInput, optFns ...func(*sqs.Options)) (*sqs.ReceiveMessageOutput, error)
	DeleteMessage(ctx context.Context, params *sqs.DeleteMessageInput, optFns ...func(*sqs.Options)) (*sqs.DeleteMessageOutput, error)
}

type TerminalStatusRepository interface {
	Get(ctx context.Context, correlationID uuid.UUID) (*domain.TerminalStatus, error)
	Upsert(ctx context.Context, status *domain.TerminalStatus) error
}

type SQSPublisher interface {
	Publish(ctx context.Context, queue string, message json.RawMessage) error
}

type HealthCheckService interface {
	ProcessHealthCheck(ctx context.Context, message []byte) error
}
