package services

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"terminal-health-monitor/internal/core/domain"
)

func TestHealthCheckService_ProcessHealthCheck_Online(t *testing.T) {
	repo := new(MockTerminalStatusRepository)
	publisher := new(MockSQSPublisher)
	service := NewHealthCheckService(repo, publisher)

	correlationID := uuid.New()
	msg := domain.HealthCheckMessage{
		Payload: struct {
			CorrelationID   uuid.UUID `json:"correlation_id"`
			FlowID          string    `json:"flow_id"`
			NextStep        struct {
				Topic string `json:"topic"`
			} `json:"next_step"`
			OriginalMessage json.RawMessage `json:"original_message"`
		}{
			CorrelationID:   correlationID,
			NextStep:        struct{ Topic string `json:"topic"` }{Topic: "next-step-queue"},
			OriginalMessage: []byte(`{"foo":"bar"}`),
		},
	}
	msgBytes, _ := json.Marshal(msg)

	repo.On("Get", mock.Anything, correlationID).Return(&domain.TerminalStatus{Status: "online"}, nil)
		publisher.On("Publish", mock.Anything, "next-step-queue", mock.AnythingOfType("json.RawMessage")).Return(nil)
	publisher.On("Publish", mock.Anything, "event-audit-queue", mock.Anything).Return(nil)

	err := service.ProcessHealthCheck(context.Background(), msgBytes)

	assert.NoError(t, err)
	repo.AssertExpectations(t)
	publisher.AssertExpectations(t)
}

func TestHealthCheckService_ProcessHealthCheck_Offline(t *testing.T) {
	repo := new(MockTerminalStatusRepository)
	publisher := new(MockSQSPublisher)
	service := NewHealthCheckService(repo, publisher)

	correlationID := uuid.New()
	msg := domain.HealthCheckMessage{
		Payload: struct {
			CorrelationID   uuid.UUID `json:"correlation_id"`
			FlowID          string    `json:"flow_id"`
			NextStep        struct {
				Topic string `json:"topic"`
			} `json:"next_step"`
			OriginalMessage json.RawMessage `json:"original_message"`
		}{
			CorrelationID:   correlationID,
			FlowID:          "test-flow-id",
			NextStep:        struct{ Topic string `json:"topic"` }{Topic: "next-step-queue"},
			OriginalMessage: []byte(`{"foo":"bar"}`),
		},
	}
	msgBytes, _ := json.Marshal(msg)

	repo.On("Get", mock.Anything, correlationID).Return(&domain.TerminalStatus{Status: "offline"}, nil)
	publisher.On("Publish", mock.Anything, "gateway-processing-queue", mock.AnythingOfType("json.RawMessage")).Return(nil)
	publisher.On("Publish", mock.Anything, "event-audit-queue", mock.Anything).Return(nil)

	err := service.ProcessHealthCheck(context.Background(), msgBytes)

	assert.NoError(t, err)
	repo.AssertExpectations(t)
	publisher.AssertExpectations(t)
}

func TestHealthCheckService_ProcessHealthCheck_NotFound(t *testing.T) {
	repo := new(MockTerminalStatusRepository)
	publisher := new(MockSQSPublisher)
	service := NewHealthCheckService(repo, publisher)

	correlationID := uuid.New()
	msg := domain.HealthCheckMessage{
		Payload: struct {
			CorrelationID   uuid.UUID `json:"correlation_id"`
			FlowID          string    `json:"flow_id"`
			NextStep        struct {
				Topic string `json:"topic"`
			} `json:"next_step"`
			OriginalMessage json.RawMessage `json:"original_message"`
		}{
			CorrelationID:   correlationID,
			FlowID:          "test-flow-id",
			NextStep:        struct{ Topic string `json:"topic"` }{Topic: "next-step-queue"},
			OriginalMessage: []byte(`{"foo":"bar"}`),
		},
	}
	msgBytes, _ := json.Marshal(msg)

	repo.On("Get", mock.Anything, correlationID).Return(&domain.TerminalStatus{}, pgx.ErrNoRows)
	publisher.On("Publish", mock.Anything, "gateway-processing-queue", mock.AnythingOfType("json.RawMessage")).Return(nil)
	publisher.On("Publish", mock.Anything, "event-audit-queue", mock.Anything).Return(nil)

	err := service.ProcessHealthCheck(context.Background(), msgBytes)

	assert.NoError(t, err)
	repo.AssertExpectations(t)
	publisher.AssertExpectations(t)
}
