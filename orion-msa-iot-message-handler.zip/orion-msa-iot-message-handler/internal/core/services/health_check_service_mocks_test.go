package services

import (
	"context"
	"encoding/json"

	"github.com/google/uuid"
	"github.com/stretchr/testify/mock"
	"terminal-health-monitor/internal/core/domain"
)

type MockTerminalStatusRepository struct {
	mock.Mock
}

func (m *MockTerminalStatusRepository) Get(ctx context.Context, correlationID uuid.UUID) (*domain.TerminalStatus, error) {
	args := m.Called(ctx, correlationID)
	return args.Get(0).(*domain.TerminalStatus), args.Error(1)
}

func (m *MockTerminalStatusRepository) Upsert(ctx context.Context, status *domain.TerminalStatus) error {
	args := m.Called(ctx, status)
	return args.Error(0)
}

type MockSQSPublisher struct {
	mock.Mock
}

func (m *MockSQSPublisher) Publish(ctx context.Context, queue string, message json.RawMessage) error {
	args := m.Called(ctx, queue, message)
	return args.Error(0)
}
