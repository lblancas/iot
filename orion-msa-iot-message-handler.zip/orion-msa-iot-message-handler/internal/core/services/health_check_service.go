package services

import (
	"context"
	"encoding/json"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/rs/zerolog/log"

	"terminal-health-monitor/internal/core/domain"
	"terminal-health-monitor/internal/core/ports"
)

type healthCheckService struct {
	repo      ports.TerminalStatusRepository
	publisher ports.SQSPublisher
}

func NewHealthCheckService(repo ports.TerminalStatusRepository, publisher ports.SQSPublisher) ports.HealthCheckService {
	return &healthCheckService{repo: repo, publisher: publisher}
}

func (s *healthCheckService) ProcessHealthCheck(ctx context.Context, message []byte) error {
	var msg domain.HealthCheckMessage
	if err := json.Unmarshal(message, &msg); err != nil {
		log.Error().Err(err).Msg("Error unmarshalling message")
		return err
	}

	status, err := s.repo.Get(ctx, msg.Payload.CorrelationID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			log.Info().Str("correlation_id", msg.Payload.CorrelationID.String()).Msg("Terminal not found. Treating as offline.")
			s.publishOfflineMessages(ctx, msg.Payload.CorrelationID.String(), msg.Payload.FlowID)
			return nil
		}
		log.Error().Err(err).Msg("Error getting terminal status")
		return err
	}

	if status.Status == "online" {
		log.Info().Str("correlation_id", status.CorrelationID.String()).Msg("Terminal is online. Proceeding to next step.")
		if err := s.publisher.Publish(ctx, msg.Payload.NextStep.Topic, msg.Payload.OriginalMessage); err != nil {
			log.Error().Err(err).Msg("Error publishing to next step topic")
			return err
		}
		s.publishAuditEvent(ctx, "TERMINAL_HEALTH_CHECK_SUCCEEDED", msg.Payload.CorrelationID.String(), msg.Payload.FlowID, "Terminal is online. Proceeding to next step.")
	} else {
		log.Info().Str("correlation_id", status.CorrelationID.String()).Msg("Terminal is offline.")
		s.publishOfflineMessages(ctx, msg.Payload.CorrelationID.String(), msg.Payload.FlowID)
	}

	return nil
}

func (s *healthCheckService) publishOfflineMessages(ctx context.Context, correlationID, flowID string) {
	gatewayMsg := domain.GatewayMessage{
		Status:        "TRANSACTION_FAILED",
		CorrelationID: correlationID,
		FlowID:        flowID,
		Error: struct {
			Code    string `json:"code"`
			Message string `json:"message"`
		}{
			Code:    "TERMINAL_OFFLINE",
			Message: "The terminal is not connected to the network.",
		},
	}
	gatewayMsgBytes, _ := json.Marshal(gatewayMsg)
	if err := s.publisher.Publish(ctx, "gateway-processing-queue", gatewayMsgBytes); err != nil {
		log.Error().Err(err).Msg("Error publishing to gateway queue")
	}

	s.publishAuditEvent(ctx, "TERMINAL_HEALTH_CHECK_FAILED", correlationID, flowID, "Terminal is offline. Transaction failed.")
}

func (s *healthCheckService) publishAuditEvent(ctx context.Context, eventType, correlationID, flowID, message string) {
	auditMsg := domain.AuditMessage{
		EventType: eventType,
		Timestamp: time.Now(),
		Details: struct {
			CorrelationID string `json:"correlation_id"`
			FlowID        string `json:"flow_id"`
			Message       string `json:"message"`
		}{
			CorrelationID: correlationID,
			FlowID:        flowID,
			Message:       message,
		},
	}
	auditMsgBytes, _ := json.Marshal(auditMsg)
	if err := s.publisher.Publish(ctx, "event-audit-queue", auditMsgBytes); err != nil {
		log.Error().Err(err).Msg("Error publishing to audit queue")
	}
}
