package repositories

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sqs"
)

type sqsPublisher struct {
	client *sqs.Client
}

func NewSQSPublisher(client *sqs.Client) *sqsPublisher {
	return &sqsPublisher{client: client}
}

func (p *sqsPublisher) Publish(ctx context.Context, queue string, message json.RawMessage) error {
	_, err := p.client.SendMessage(ctx, &sqs.SendMessageInput{
		QueueUrl:    aws.String(queue),
		MessageBody: aws.String(string(message)),
	})
	return err
}
