package repositories

import (
	"context"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"

	"terminal-health-monitor/internal/core/domain"
)

type terminalStatusRepository struct {
	pool *pgxpool.Pool
}

func NewTerminalStatusRepository(pool *pgxpool.Pool) *terminalStatusRepository {
	return &terminalStatusRepository{pool: pool}
}

func (r *terminalStatusRepository) Get(ctx context.Context, correlationID uuid.UUID) (*domain.TerminalStatus, error) {
	query := `SELECT correlation_id, status, last_updated_at FROM cloud.bt_terminal_status WHERE correlation_id = $1`
	row := r.pool.QueryRow(ctx, query, correlationID)

	var status domain.TerminalStatus
	if err := row.Scan(&status.CorrelationID, &status.Status, &status.LastUpdatedAt); err != nil {
		return nil, err
	}

	return &status, nil
}

func (r *terminalStatusRepository) Upsert(ctx context.Context, status *domain.TerminalStatus) error {
	query := `
		INSERT INTO cloud.bt_terminal_status (correlation_id, status, last_updated_at)
		VALUES ($1, $2, NOW())
		ON CONFLICT (correlation_id) DO UPDATE
		SET status = EXCLUDED.status,
			last_updated_at = NOW()`

	_, err := r.pool.Exec(ctx, query, status.CorrelationID, status.Status)
	return err
}
