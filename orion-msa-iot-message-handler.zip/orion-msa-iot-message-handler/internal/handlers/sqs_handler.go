package handlers

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/service/sqs"
	"github.com/rs/zerolog/log"

	"terminal-health-monitor/internal/core/ports"
)

type SQSHandler struct {
	sqsClient ports.SQSClientAPI
	queueURL  string
	healthSvc ports.HealthCheckService
}

func NewSQSHandler(client ports.SQSClientAPI, queueURL string, healthSvc ports.HealthCheckService) *SQSHandler {
	return &SQSHandler{
		sqsClient: client,
		queueURL:  queueURL,
		healthSvc: healthSvc,
	}
}

func (h *SQSHandler) Start(ctx context.Context) {
	for {
		select {
		case <-ctx.Done():
			log.Info().Msg("SQS handler shutting down.")
			return
		default:
			output, err := h.sqsClient.ReceiveMessage(ctx, &sqs.ReceiveMessageInput{
				QueueUrl:            &h.queueURL,
				MaxNumberOfMessages: 1,
				WaitTimeSeconds:     20,
			})

			if err != nil {
				log.Error().Err(err).Msg("Error receiving message from SQS")
				continue
			}

			for _, message := range output.Messages {
				if err := h.healthSvc.ProcessHealthCheck(ctx, []byte(*message.Body)); err != nil {
					log.Error().Err(err).Msg("Error processing message")
					continue
				}

				_, err := h.sqsClient.DeleteMessage(ctx, &sqs.DeleteMessageInput{
					QueueUrl:      &h.queueURL,
					ReceiptHandle: message.ReceiptHandle,
				})
				if err != nil {
					log.Error().Err(err).Msg("Error deleting message from SQS")
				}
			}
		}
	}
}
