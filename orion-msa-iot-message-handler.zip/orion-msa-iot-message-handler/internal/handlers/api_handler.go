package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"terminal-health-monitor/internal/core/domain"
	"terminal-health-monitor/internal/core/ports"
)

type APIHandler struct {
	repo ports.TerminalStatusRepository
}

func NewAPIHandler(repo ports.TerminalStatusRepository) *APIHandler {
	return &APIHandler{repo: repo}
}

type UpdateTerminalStatusRequest struct {
	Status string `json:"status" binding:"required,oneof=online offline"`
}

// @Summary Update terminal status
// @Description Creates or updates the connectivity status of a terminal.
// @Tags terminals
// @Accept json
// @Produce json
// @Param correlation_id path string true "Terminal Correlation ID"
// @Param status body UpdateTerminalStatusRequest true "Terminal status update request"
// @Success 200 {string} string "OK"
// @Failure 400 {object} map[string]string "Invalid correlation_id format or request body"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /terminals/{correlation_id}/status [put]
func (h *APIHandler) UpdateTerminalStatus(c *gin.Context) {
	correlationIDStr := c.Param("correlation_id")
	correlationID, err := uuid.Parse(correlationIDStr)
	if err != nil {
		c.Error(domain.NewBadRequestError("Invalid correlation_id format"))
		return
	}

	var req UpdateTerminalStatusRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.Error(domain.NewBadRequestError(err.Error()))
		return
	}

	status := &domain.TerminalStatus{
		CorrelationID: correlationID,
		Status:        req.Status,
	}

	if err := h.repo.Upsert(c.Request.Context(), status); err != nil {
		c.Error(domain.NewInternalServerError("Failed to update terminal status"))
		return
	}

	c.Status(http.StatusOK)
}
