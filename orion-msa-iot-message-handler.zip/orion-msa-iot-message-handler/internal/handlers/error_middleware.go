package handlers

import (
	"errors"
	"net/http"

	"github.com/gin-gonic/gin"

	"terminal-health-monitor/internal/core/domain"
)

func ErrorHandlingMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Next()

		if len(c.Errors) > 0 {
			err := c.Errors[0].Err // Get the first error

			var notFoundErr *domain.NotFoundError
			var badRequestErr *domain.BadRequestError
			var internalServerErr *domain.InternalServerError

			if errors.As(err, &notFoundErr) {
				c.JSON(http.StatusNotFound, gin.H{"error": notFoundErr.Error()})
			} else if errors.As(err, &badRequestErr) {
				c.JSON(http.StatusBadRequest, gin.H{"error": badRequestErr.Error()})
			} else if errors.As(err, &internalServerErr) {
				c.JSON(http.StatusInternalServerError, gin.H{"error": internalServerErr.Error()})
			} else {
				c.JSON(http.StatusInternalServerError, gin.H{"error": "An unexpected error occurred"})
			}
			c.Abort()
		}
	}
}
