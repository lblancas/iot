package main

import (
	"context"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"github.com/gin-gonic/gin"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/rs/zerolog/log"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"

	"terminal-health-monitor/docs"
	"terminal-health-monitor/internal/core/services"
	"terminal-health-monitor/internal/handlers"
	"terminal-health-monitor/internal/pkg/logger"
	"terminal-health-monitor/internal/repositories"
)

// @title Terminal Health Monitor API
// @version 1.0
// @description This is the API for the Terminal Health Monitor microservice.
// @host localhost:8080
// @BasePath /
func main() {
	logger.InitLogger()

	// TODO: Load configuration using Viper

	// Database connection
	dbpool, err := pgxpool.New(context.Background(), "postgres://user:password@localhost:5432/mydb?sslmode=disable") // Replace with actual connection string from config
	if err != nil {
		log.Fatal().Err(err).Msg("Unable to create connection pool")
	}
	defer dbpool.Close()

	// Repositories
	repo := repositories.NewTerminalStatusRepository(dbpool)

	// SQS Publisher (mock for now)
	// TODO: Replace with actual AWS SQS client
	publisher := &repositories.MockSQSPublisher{} // Using the mock for now

	// Services
	healthSvc := services.NewHealthCheckService(repo, publisher)

	// Handlers
	apiHandler := handlers.NewAPIHandler(repo)
	sqsHandler := handlers.NewSQSHandler(nil, "", healthSvc) // TODO: Replace nil and empty string with actual SQS client and queue URL

	// Setup Gin router
	r := gin.Default()
	r.Use(handlers.ErrorHandlingMiddleware())

	// API routes
	r.PUT("/terminals/:correlation_id/status", apiHandler.UpdateTerminalStatus)

	// Swagger UI
	docs.SwaggerInfo.BasePath = "/"
	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

	// Start SQS consumer in a goroutine
	ctx, cancel := context.WithCancel(context.Background())
	go sqsHandler.Start(ctx)

	// Start HTTP server
	go func() {
		if err := r.Run(":8080"); err != nil && err != http.ErrServerClosed {
			log.Fatal().Err(err).Msg("listen")
		}
	}()

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Info().Msg("Shutting down server...")

	cancel()
	// TODO: Implement graceful shutdown for HTTP server
}