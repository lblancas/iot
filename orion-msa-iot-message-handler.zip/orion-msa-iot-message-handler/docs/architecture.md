## **🎯 ¿Qué problema resuelve?**

Este sistema aborda una vulnerabilidad crítica en los flujos de transacciones de punto de venta (POS): el intento de procesar operaciones para terminales que están desconectadas o fuera de línea. Procesar estas transacciones consume recursos computacionales, genera logs de errores innecesarios y puede causar inconsistencias de datos si no se maneja adecuadamente.

El microservicio **Terminal Health Monitor** actúa como un guardián o "gatekeeper" que valida en tiempo real el estado de conectividad de una terminal antes de que la transacción continúe su flujo, asegurando que solo las terminales activas y en línea puedan procesar operaciones.

## **💡 Valor que aporta**

* **Fiabilidad del Sistema:** Aumenta la tasa de éxito de las transacciones al prevenir fallos predecibles por desconexión.  
* **Eficiencia de Recursos:** Reduce la carga en los servicios de procesamiento posteriores y en la base de datos al filtrar transacciones inviables en una etapa temprana.  
* **Visibilidad Operacional:** Proporciona un mecanismo centralizado para conocer y gestionar el estado de salud de toda la flota de terminales.  
* **Resiliencia:** Mejora la capacidad del sistema para manejar fallos de conectividad de las terminales de manera elegante y controlada.

## **📋 Objetivo Técnico**

Desarrollar un microservicio en **Golang**, llamado **Terminal Health Monitor**, que exponga dos funcionalidades principales:

1. **Consumidor de Eventos (SQS):** Un proceso que escucha una cola SQS (terminal-health-monitor-queue) para validar el estado de una terminal como un paso dentro de un flujo de transacción más grande.  
2. **API RESTful:** Un endpoint seguro (PUT /terminals/{correlation\_id}/status) para que sistemas externos o las propias terminales puedan actualizar su estado de conectividad ('online'/'offline').

El servicio será desplegado como un contenedor en **AWS EKS**, siguiendo las mejores prácticas de seguridad y configuración para cada entorno (local, dev, qa, sbx, prod).

## **📖 Descripción General del Proyecto**

### **Contexto del Sistema**

El **Terminal Health Monitor** es un componente de una arquitectura de microservicios orientada a eventos. Se integra con el ecosistema existente comunicándose a través de **Amazon SQS** y persistiendo el estado en una base de datos compartida **Amazon Aurora (PostgreSQL)**, específicamente en el esquema cloud.

### **¿A quién sirve este sistema?**

* **Consumidores Primarios:** Otros microservicios del backend que orquestan el flujo de transacciones (ej. Gateway Processing, Flow Dispatcher).  
* **Consumidores Secundarios:** Sistemas de gestión de terminales, paneles de administración o las propias terminales (mediante un servicio intermedio) que necesiten reportar su estado de conectividad.

**🏢 Sistemas que se benefician:**

* **Gateway Processing:** Recibe una respuesta rápida si una terminal está fuera de línea, permitiéndole terminar el flujo de forma anticipada.  
* **Event Audit:** Recibe eventos detallados sobre las validaciones de estado, enriqueciendo la trazabilidad de las transacciones.  
* **Flow Dispatcher:** Puede usar la información de estado para tomar decisiones de enrutamiento más inteligentes.

### **Problema Específico que Resuelve**

Dentro del flujo de una transacción, no existe un punto de control explícito y en tiempo real para verificar si la terminal de origen está en línea. Esto significa que una transacción puede avanzar a través de varios servicios antes de fallar en un paso que requiere comunicación directa con la terminal. Este servicio introduce esa validación como un paso atómico y reutilizable, simplificando la lógica de los demás servicios y centralizando la gestión del estado de la terminal.

## **🏗️ Arquitectura del Sistema**

El servicio se compone de dos flujos de trabajo principales que operan de forma independiente pero comparten el acceso a la misma tabla en la base de datos.

### **Flujo de Datos**

**1\. Flujo de Validación de Estado (Asíncrono vía SQS)**

```mermaid
flowchart TD
    A[SQS Cola: terminal-health-monitor] -->|1. Mensaje recibido| B[SQS Consumer Go<br/>- Lee y parsea mensaje]
    B -->|2. Procesa mensaje| C[Lógica de Negocio<br/>- Extrae correlation_id]
    C -->|3. Consulta estado| D[Aurora PostgreSQL<br/>cloud.bt_terminal_status]
    D -->|4. Estado devuelto<br/>online/offline| C

    %% Condición de estado
    C -->|5a. Si está ONLINE<br/>Publica a next_step_topic| E[Cola SQS Dinámica<br/>next_step_topic]
    C -->|5b. Publica éxito<br/>de validación| F[Cola SQS<br/>event-audit]
    C -->|5c. Si está OFFLINE<br/>Publica fallo y error| G[Cola SQS<br/>gateway-processing]

    subgraph THS ["Terminal Health Monitor Service"]
        B
        C
        D
        E
        F
        G
    end
```

**2\. Flujo de Actualización de Estado (Síncrono vía API REST)**

```mermaid
flowchart TD
    A[Cliente<br/>Admin, Terminal, etc.] -->|1. PUT /terminals/...| B[Amazon API Gateway]
    B -->|2. Petición recibida| C[API Handler Go<br/>- Valida request]
    C -->|3. Actualiza/Inserta| D[Aurora PostgreSQL<br/>cloud.bt_terminal_status]
    D -->|4. Resultado OK/Error| E[Respuesta HTTP<br/>200 OK, 404, etc.]
    E -->|5. Envía respuesta| B
    B -->|6. Respuesta final| A
    
    subgraph EKS ["Servicio en EKS (Terminal Health Monitor)"]
        C
        D
        E
    end
```

## **🎯 Capacidades del Sistema**

### **Tipos de Transacciones Soportadas**

1. **Solicitud de Verificación de Salud (Health Check Request):** Un mensaje JSON recibido vía SQS que desencadena el flujo de validación.  
2. **Actualización de Estado (Status Update):** Una petición HTTP PUT que modifica el estado de una terminal en la base de datos.

### **Gestión de Estado Transaccional**

El estado principal que gestiona el servicio es el estado de conectividad (online u offline) de una terminal. Este estado se persiste en la tabla cloud.bt\_terminal\_status de la base de datos Aurora PostgreSQL. La columna last\_updated\_at es crucial para auditoría y para posibles mecanismos de "staleness" (detectar terminales que no han reportado su estado en mucho tiempo).

### **Operaciones CRUD Disponibles**

El servicio implementa las siguientes operaciones sobre la entidad TerminalStatus:

* **Create (Crear):** Implícitamente a través de la API de actualización. Si se recibe una actualización para un correlation\_id que no existe, se creará un nuevo registro.  
* **Read (Leer):** Realizado por el consumidor de SQS para verificar el estado actual de una terminal.  
* **Update (Actualizar):** Realizado explícitamente a través del endpoint de la API REST.

La operación **Delete (Borrar)** no es responsabilidad de este servicio. El ciclo de vida (desaprovisionamiento) de las terminales se gestiona en otro lugar.

## **📋 Especificaciones Técnicas**

### **Clasificación de Transacciones**

Mensaje de Entrada (Cola: terminal-health-monitor-queue)  
Pseudocódigo JSON:  
{  
  "metadata": {  
    "message\_id": "uuid-v4-string",  
    "timestamp": "iso-8601-string"  
  },  
  "payload": {  
    "correlation\_id": "uuid-v4-string",  
    "flow\_id": "string",  
    "next\_step": {  
      "topic": "sqs-queue-name-for-next-service"  
    },  
    "original\_message": { }  
  }  
}

Mensaje de Salida (Éxito) (Cola: event-audit)  
Pseudocódigo JSON:  
{  
  "event\_type": "TERMINAL\_HEALTH\_CHECK\_SUCCEEDED",  
  "timestamp": "iso-8601-string",  
  "details": {  
    "correlation\_id": "uuid-v4-string",  
    "flow\_id": "string",  
    "message": "Terminal is online. Proceeding to next step."  
  }  
}

Mensaje de Salida (Fallo) (Cola: gateway-processing)  
Pseudocódigo JSON:  
{  
  "status": "TRANSACTION\_FAILED",  
  "correlation\_id": "uuid-v4-string",  
  "flow\_id": "string",  
  "error": {  
    "code": "TERMINAL\_OFFLINE",  
    "message": "The terminal is not connected to the network."  
  }  
}

### **Gestión de Estado**

La lógica de negocio consultará la tabla cloud.bt\_terminal\_status usando el correlation\_id.

* **SELECT status FROM cloud.bt\_terminal\_status WHERE correlation\_id \= $1**  
* Si la fila no existe o el status es 'offline', se considera fuera de línea.  
* Si el status es 'online', se considera en línea.

### **Operaciones CRUD**

**Endpoint de la API: PUT /terminals/{correlation\_id}/status**

* **Parámetro de Ruta:**  
  * correlation\_id (UUID): El identificador único de la terminal.  
* **Cuerpo de la Petición (Request Body):**  
  * *Content-Type:* application/json  
  * *Esquema:*  
    {  
      "status": "online" | "offline"  
    }

* **Respuestas:**  
  * **200 OK**: El estado se actualizó correctamente.  
  * **400 Bad Request**: El cuerpo de la petición es inválido (ej. status no es 'online' ni 'offline').  
  * **404 Not Found**: Aunque la lógica es de "upsert", se podría devolver si se decide que las terminales deben ser pre-registradas. Para este diseño, usaremos lógica de "upsert", por lo que este código no se usaría.  
  * **500 Internal Server Error**: Error al comunicarse con la base de datos.  
* **Lógica de Implementación (Pseudocódigo Go):**  
  // En el handler de la API  
  // 1\. Parsear y validar \`correlation\_id\` de la URL.  
  // 2\. Parsear y validar el cuerpo JSON. El campo \`status\` es obligatorio.  
  // 3\. Ejecutar una consulta SQL de tipo "UPSERT" (INSERT ON CONFLICT).  
  sql\_statement := \`  
      INSERT INTO cloud.bt\_terminal\_status (correlation\_id, status, last\_updated\_at)  
      VALUES ($1, $2, NOW())  
      ON CONFLICT (correlation\_id) DO UPDATE  
      SET status \= EXCLUDED.status,  
          last\_updated\_at \= NOW();  
  \`  
  // 4\. Ejecutar la consulta con los parámetros.  
  // 5\. Devolver la respuesta HTTP correspondiente.

## **Guía detallada de implementación**

### **Generación de flujo en Gherkin**

**Feature: Validación del Estado de Salud de la Terminal**

**Scenario: Una transacción se procesa para una terminal que está en línea**

Given una terminal con correlation\_id "c4a7e3d6-3b9e-4b0d-828d-7f8a9e6b1c2a" tiene el estado "online" en la base de datos  
And un mensaje de transacción para esa terminal llega a la cola "terminal-health-monitor-queue" con el "next\_step" apuntando a "payment-processor-queue"  
When el servicio "Terminal Health Monitor" procesa el mensaje  
Then el servicio debe enviar el mensaje de la transacción original a la cola "payment-processor-queue"  
And el servicio debe enviar un evento de éxito a la cola "event-audit"

**Scenario: Una transacción se intenta procesar para una terminal que está fuera de línea**

Given una terminal con correlation\_id "a1b2c3d4-e5f6-7890-1234-56789abcdef0" tiene el estado "offline" en la base de datos  
And un mensaje de transacción para esa terminal llega a la cola "terminal-health-monitor-queue"  
When el servicio "Terminal Health Monitor" procesa el mensaje  
Then el servicio debe enviar un mensaje de error a la cola "gateway-processing" indicando que la terminal está fuera de línea  
And el servicio debe enviar un evento de fallo a la cola "event-audit"  
And el servicio NO debe enviar ningún mensaje a la cola del siguiente paso

**Feature: Gestión del Estado de la Terminal vía API**

**Scenario: Actualizar el estado de una terminal existente a "online"**

Given una terminal con correlation\_id "f0e9d8c7-b6a5-4321-fedc-ba9876543210" existe en la base de datos con estado "offline"  
When un cliente envía una petición PUT a "/terminals/f0e9d8c7-b6a5-4321-fedc-ba9876543210/status" con el cuerpo {"status": "online"}  
Then el sistema debe responder con un código de estado 200 OK  
And el estado de la terminal en la base de datos debe ser "online"  
And el campo "last\_updated\_at" debe ser actualizado

**Scenario: Registrar y actualizar el estado de una nueva terminal**

Given una terminal con correlation\_id "11223344-5566-7788-9900-aabbccddeeff" NO existe en la base de datos  
When un cliente envía una petición PUT a "/terminals/11223344-5566-7788-9900-aabbccddeeff/status" con el cuerpo {"status": "online"}  
Then el sistema debe responder con un código de estado 200 OK  
And un nuevo registro para esa terminal debe ser creado en la base de datos con el estado "online"

## **⚙️ Requisitos del Sistema**

### **🖥️ Requisitos Mínimos**

* **CPU:** 256m (0.25 vCPU)  
* **Memoria:** 512Mi  
* Estos son valores iniciales. Se deben ajustar basados en pruebas de carga.

### **📋 Versiones de Software**

#### **Requerido (Core)**

* **Go:** 1.22 o superior  
* **Docker:** 20.10 o superior  
* **PostgreSQL Client:** Compatible con PostgreSQL 13+

#### **Cloud Services (AWS)**

* **EKS:** Versión 1.28+  
* **Amazon Aurora (PostgreSQL):** Versión 13+  
* **Amazon SQS:** Standard Queues  
* **Amazon API Gateway:** REST API  
* **Amazon Secrets Manager**  
* **Amazon ECR** (para la imagen del contenedor)

#### **Desarrollo Local (Opcional)**

* **Docker Desktop**  
* **make** (para automatizar comandos)  
* **LocalStack** (para simular servicios AWS) o conexión a un entorno dev.

### **🔐 Permisos AWS Necesarios**

El rol de IAM asociado al Service Account del Pod en EKS debe tener los siguientes permisos:

{  
    "Version": "2012-10-17",  
    "Statement": \[  
        {  
            "Effect": "Allow",  
            "Action": \[  
                "sqs:ReceiveMessage",  
                "sqs:DeleteMessage",  
                "sqs:GetQueueAttributes"  
            \],  
            "Resource": "arn:aws:sqs:us-east-1:123456789012:terminal-health-monitor-queue"  
        },  
        {  
            "Effect": "Allow",  
            "Action": "sqs:SendMessage",  
            "Resource": \[  
                "arn:aws:sqs:us-east-1:123456789012:event-audit-queue",  
                "arn:aws:sqs:us-east-1:123456789012:gateway-processing-queue",  
                "arn:aws:sqs:us-east-1:123456789012:\*"  
            \]  
        },  
        {  
            "Effect": "Allow",  
            "Action": "secretsmanager:GetSecretValue",  
            "Resource": "arn:aws:secretsmanager:us-east-1:123456789012:secret:aurora/db/credentials-AbCdEf"  
        }  
    \]  
}

*Nota: Los ARNs son ejemplos y deben ser reemplazados con los valores reales.*

### **📊 Estimaciones de Rendimiento**

* **Latencia (API):** \< 50ms en el percentil 95, ya que la operación principal es una consulta de base de datos indexada.  
* **Latencia (Consumidor SQS):** \< 100ms desde que se recibe el mensaje hasta que se publican los mensajes de salida.  
* **Throughput:** El sistema debe ser capaz de escalar horizontalmente. El rendimiento estará limitado por los límites de la base de datos y SQS. Se espera poder procesar miles de mensajes por minuto con un número adecuado de réplicas del pod.

## **🛠️ Stack Tecnológico**

### **Core Technologies**

* **Lenguaje:** Golang  
* **Framework API:** Gin Gonic (o net/http estándar para simplicidad)  
* **Driver PostgreSQL:** jackc/pgx/v5  
* **AWS SDK:** aws-sdk-go-v2

### **Dependencies**

* github.com/aws/aws-sdk-go-v2  
* github.com/aws/aws-sdk-go-v2/config  
* github.com/aws/aws-sdk-go-v2/service/sqs  
* github.com/aws/aws-sdk-go-v2/service/secretsmanager  
* github.com/gin-gonic/gin  
* github.com/jackc/pgx/v5/pgxpool  
* github.com/spf13/viper (para gestión de configuración en diferentes entornos)

## **🚀 Quick Start**

1. **Clonar el Repositorio:** git clone \<url-del-repositorio\>  
2. **Configuración Local:**  
   * Copiar .env.example a .env.  
   * Llenar las variables de entorno en .env con los datos de conexión a la base de datos local o de dev.

\# .env  
APP\_ENV=local  
DB\_HOST=localhost  
DB\_PORT=5432  
DB\_USER=user  
DB\_PASSWORD=password  
DB\_NAME=mydb  
DB\_SCHEMA=cloud

3. **Instalar Dependencias:** go mod tidy  
4. **Ejecutar el Servicio:** go run ./cmd/main.go  
5. **Construir Imagen Docker:** docker build \-t terminal-health-monitor .  
6. **Despliegue en EKS:** Utilizar los manifiestos de Kubernetes (deployment.yaml, service.yaml, hpa.yaml) del repositorio.

## **📡 API Reference**

### **📋 Documentación Completa**

La API está completamente documentada usando **OpenAPI 3.0**. El fichero openapi.yaml se encontrará en la raíz del repositorio del proyecto.

**Endpoint: Actualizar Estado de Terminal**

PUT /terminals/{correlation\_id}/status

**Descripción:** Crea o actualiza el estado de conectividad de una terminal.

**Parámetros de Ruta:**

* correlation\_id (string, formato: uuid, **requerido**): Identificador único de la terminal.

**Cuerpo de la Petición:**

* application/json

{  
  "status": "online"  
}

**Respuestas:**

* 200 OK  
* 400 Bad Request  
* 500 Internal Server Error

### **📋 Estándares de Desarrollo**

* **Logging:** Todos los logs deben ser emitidos a stdout en formato JSON estructurado para ser capturados por el agente de New Relic.  
* **Testing:** Se requiere una cobertura de pruebas unitarias superior al 80%. Las pruebas de integración deben cubrir los flujos principales.  
* **CI/CD:** El pipeline debe incluir pasos para linting, testing, build, publicación de imagen en ECR y despliegue en los diferentes entornos.  
* **Gestión de Configuración:** La configuración se cargará según el entorno (APP\_ENV). Para entornos en EKS, los datos sensibles (como el ARN del secret de la BD) se inyectarán como variables de entorno desde el manifiesto de despliegue. Para local, se usará el fichero .env.

## **📚 Recursos Adicionales**

* [Documentación de AWS SDK for Go V2](https://www.google.com/search?q=https://aws.github.io/aws-sdk-go-v2/docs/)  
* [Documentación del driver pgx](https://pkg.go.dev/github.com/jackc/pgx/v5)  
* [Guía de IAM Roles for Service Accounts (IRSA)](https://docs.aws.amazon.com/eks/latest/userguide/iam-roles-for-service-accounts.html)