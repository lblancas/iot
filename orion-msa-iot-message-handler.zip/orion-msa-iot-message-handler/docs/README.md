# Terminal Health Monitor Microservice

## Description

This microservice, developed in Go, acts as a gatekeeper for Point-of-Sale (POS) transactions, ensuring that operations are only processed for terminals that are currently online. It provides real-time validation of terminal connectivity status, reducing computational waste and improving system reliability.

## Tech Stack

*   **Language:** Golang (Go)
*   **API Framework:** Gin Gonic
*   **Database Driver:** jackc/pgx/v5 (for PostgreSQL)
*   **Configuration Management:** spf13/viper
*   **AWS SDK:** aws-sdk-go-v2 (for SQS and Secrets Manager)
*   **Logging:** zerolog

## Environment Variables

To run the service, the following environment variables are required:

*   `APP_ENV`: Application environment (e.g., `local`, `dev`, `qa`, `prod`)
*   `DB_HOST`: PostgreSQL database host
*   `DB_PORT`: PostgreSQL database port
*   `DB_USER`: PostgreSQL database user
*   `DB_PASSWORD`: PostgreSQL database password
*   `DB_NAME`: PostgreSQL database name
*   `DB_SCHEMA`: PostgreSQL database schema (e.g., `cloud`)
*   `AWS_REGION`: AWS region for SQS and Secrets Manager
*   `SQS_QUEUE_URL`: URL of the SQS queue for terminal health messages

## How to Run Locally

1.  **Clone the repository:**
    ```bash
    git clone <repository-url>
    cd terminal-health-monitor
    ```
2.  **Create a `.env` file:**
    Copy `.env.example` to `.env` and fill in the required environment variables.
    ```bash
    cp .env.example .env
    ```
3.  **Install dependencies:**
    ```bash
    go mod tidy
    ```
4.  **Run the service:**
    ```bash
    go run ./cmd/api/main.go
    ```

## How to Run Tests

To run all unit and integration tests:

```bash
go test ./...
```

## API Reference

### `PUT /terminals/{correlation_id}/status`

**Description:** Creates or updates the connectivity status of a terminal.

**Path Parameters:**

*   `correlation_id` (string, UUID format, **required**): Unique identifier of the terminal.

**Request Body (application/json):**

```json
{
  "status": "online" | "offline"
}
```

**Responses:**

*   `200 OK`: Status updated successfully.
*   `400 Bad Request`: Invalid request body or `correlation_id` format.
*   `500 Internal Server Error`: Internal server error.
