#!/usr/bin/env python3
"""
Workflow Manager - Handles RabbitMQ message broker operations
"""

import logging
from typing import Dict, Any, Optional, Callable
from config import config

# Import RabbitMQ client
from rabbitmq_workflow_client import WorkflowRabbitMQClient

logger = logging.getLogger(__name__)

class WorkflowManager:
    """
    Manages message broker connections and operations for Workflow
    Currently supports RabbitMQ backend only (SQS support removed)
    """
    
    def __init__(self):
        # Get broker type from secrets - only RabbitMQ is supported now
        secrets = config.get_secrets()
        self.broker_type = secrets.get("message_broker", "rabbitmq")
        
        # Fail fast if someone tries to use SQS
        if self.broker_type == "sqs":
            raise ValueError("SQS is no longer supported. Please configure message_broker='rabbitmq' in secrets.")
        self.rabbitmq_client: Optional[WorkflowRabbitMQClient] = None
        
        logger.info(f"🔧 Workflow Manager initialized with broker: {self.broker_type}")
    
    async def initialize(self) -> None:
        """Initialize the appropriate message broker client"""
        try:
            secrets = config.get_secrets()
            
            if self.broker_type == "rabbitmq":
                # Initialize RabbitMQ client with secrets
                rabbitmq_host = secrets.get("rabbitmq_host")
                rabbitmq_env = secrets.get("rabbitmq_environment", "dev")
                
                if not rabbitmq_host:
                    raise ValueError("rabbitmq_host not found in secrets")
                
                self.rabbitmq_client = WorkflowRabbitMQClient(
                    rabbitmq_host=rabbitmq_host,
                    environment=rabbitmq_env
                )
                await self.rabbitmq_client.initialize()
                logger.info("✅ RabbitMQ client initialized")
                
            else:
                raise ValueError(f"Unsupported message broker type: {self.broker_type}. Only 'rabbitmq' is supported.")
                
        except Exception as e:
            logger.error(f"❌ Failed to initialize Workflow Manager: {e}")
            raise
    
    async def start_consuming(self, message_handler: Callable[[Dict[str, Any]], None]) -> None:
        """Start consuming messages from workflow queue"""
        if self.broker_type == "rabbitmq":
            await self.rabbitmq_client.start_consuming(message_handler)
        else:
            raise ValueError(f"Unsupported broker type: {self.broker_type}. Only 'rabbitmq' is supported.")
    
    async def send_to_mapper(self, payload: Dict[str, Any]) -> None:
        """Send message to mapper service"""
        if self.broker_type == "rabbitmq":
            await self.rabbitmq_client.send_to_mapper(payload)
        else:
            raise ValueError(f"Unsupported broker type: {self.broker_type}. Only 'rabbitmq' is supported.")
    
    async def send_to_link(self, payload: Dict[str, Any]) -> None:
        """Send message to link service"""
        if self.broker_type == "rabbitmq":
            await self.rabbitmq_client.send_to_link(payload)
        else:
            raise ValueError(f"Unsupported broker type: {self.broker_type}. Only 'rabbitmq' is supported.")
    
    async def send_to_switch_link(self, payload: Dict[str, Any]) -> None:
        """Send message to switch-link service"""
        if self.broker_type == "rabbitmq":
            await self.rabbitmq_client.send_to_switch_link(payload)
        else:
            raise ValueError(f"Unsupported broker type: {self.broker_type}. Only 'rabbitmq' is supported.")
    
    async def send_to_gateway(self, payload: Dict[str, Any]) -> None:
        """Send response message back to gateway"""
        if self.broker_type == "rabbitmq":
            await self.rabbitmq_client.send_to_gateway(payload)
        else:
            raise ValueError(f"Unsupported broker type: {self.broker_type}. Only 'rabbitmq' is supported.")
    
    async def send_to_state_handler(self, payload: Dict[str, Any]) -> None:
        """Send message to state handler service"""
        if self.broker_type == "rabbitmq":
            await self.rabbitmq_client.send_to_state_handler(payload)
        else:
            raise ValueError(f"Unsupported broker type: {self.broker_type}. Only 'rabbitmq' is supported.")
    
    async def health_check(self) -> bool:
        """Check broker health"""
        try:
            if self.broker_type == "rabbitmq":
                return await self.rabbitmq_client.health_check()
            else:
                return False
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def disconnect(self) -> None:
        """Disconnect from message broker"""
        try:
            if self.broker_type == "rabbitmq" and self.rabbitmq_client:
                await self.rabbitmq_client.disconnect()
                logger.info(f"🔌 {self.broker_type.upper()} client disconnected")
            
        except Exception as e:
            logger.error(f"Error disconnecting from {self.broker_type}: {e}")

# Global workflow manager instance
workflow_manager: Optional[WorkflowManager] = None

def get_workflow_manager() -> WorkflowManager:
    """Get or create workflow manager singleton"""
    global workflow_manager
    if workflow_manager is None:
        workflow_manager = WorkflowManager()
    return workflow_manager