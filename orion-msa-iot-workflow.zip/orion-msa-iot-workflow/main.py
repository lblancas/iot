#!/usr/bin/env python3
"""
Workflow Microservice
Routes messages based on workflow configuration and transaction requirements
"""

import os
import sys
import json
import asyncio
import logging
import threading
import psycopg2
from psycopg2 import pool
from datetime import datetime
from typing import Dict, Any, Optional
import boto3
from fastapi import FastAPI
import uvicorn
from psycopg2.extras import RealDictCursor

from config import config
from models import HealthResponse, WorkflowEntry, StateHandlerMessage
from performance_config import PerformanceConfig
from workflow_manager import get_workflow_manager

# Global cache for workflow configurations
workflow_cache = {}
cache_last_updated = None

# Track processed messages to prevent duplicates
processed_messages = set()

# Database connection pool
db_pool = None

# Global workflow manager instance
workflow_manager = None

# Configure logging with timestamps
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger("orion-workflow")

# FastAPI app for health endpoint
app = FastAPI(title="Workflow Microservice", version="1.0.0")

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        service="workflow", 
        timestamp=datetime.now(),
        version="1.0.0"
    )

def init_db_pool():
    """Initialize database connection pool"""
    global db_pool
    try:
        secrets = config.get_secrets()
        
        # Create connection pool to read-only replica
        db_pool = psycopg2.pool.SimpleConnectionPool(
            1,  # min connections
            3,  # max connections
            host=secrets["host_ro"],  # Use read-only replica
            port=int(secrets.get("port", 5432)),
            database=secrets["dbname"],
            user=secrets["username"],
            password=secrets["password"]
        )
        
        logger.info("✅ Database connection pool initialized: 1-3 connections to read-only replica")
        
    except Exception as e:
        logger.error(f"❌ Error creating database connection pool: {e}")
        raise

def load_workflow_cache():
    """Load all workflow configurations into memory cache using connection pool"""
    global workflow_cache, cache_last_updated, db_pool
    connection = None
    
    try:
        logger.info("🔄 Loading workflow cache from database...")
        
        # Get connection from pool
        connection = db_pool.getconn()
        
        with connection.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute("""
                SELECT stateid, code, endpoint_type, require_translation
                FROM cloud.bt_transaction_workflow
            """)
            
            results = cursor.fetchall()
        
        # Build cache dictionary with composite key
        new_cache = {}
        for row in results:
            cache_key = f"{row['stateid']}:{row['code']}:{row['endpoint_type']}"
            new_cache[cache_key] = WorkflowEntry(
                stateid=row['stateid'],
                code=str(row['code']),  # Ensure it's string
                endpoint_type=row['endpoint_type'],
                require_translation=row['require_translation']
            )
        
        workflow_cache = new_cache
        cache_last_updated = datetime.now()
        
        logger.info(f"✅ Loaded {len(workflow_cache)} workflow configurations into cache")
        
    except Exception as e:
        logger.error(f"❌ Error loading workflow cache: {e}")
        # Don't raise - continue with empty cache, will fallback to database
    finally:
        # Return connection to pool
        if connection and db_pool:
            db_pool.putconn(connection)

def is_cache_expired() -> bool:
    """Check if cache needs to be refreshed"""
    global cache_last_updated
    if cache_last_updated is None:
        return True
    
    elapsed = (datetime.now() - cache_last_updated).total_seconds()
    return elapsed > PerformanceConfig.CACHE_TTL_SECONDS

def get_workflow_entry(state_id: str, code: str, endpoint_type: str) -> Optional[WorkflowEntry]:
    """Get workflow configuration from cache (with database fallback)"""
    global workflow_cache
    
    # Check if cache needs refresh
    if is_cache_expired() or not workflow_cache:
        load_workflow_cache()
    
    # Try cache first (super fast lookup)
    cache_key = f"{state_id}:{code}:{endpoint_type}"
    if cache_key in workflow_cache:
        entry = workflow_cache[cache_key]
        logger.info(f"⚡ Cache HIT - StateID='{state_id}', Code={code}, EndpointType='{endpoint_type}', require_translation={entry.require_translation}")
        return entry
    
    # Cache miss - fallback to database query
    logger.warning(f"🔍 Cache MISS - Querying database for: StateID='{state_id}', Code={code}, EndpointType='{endpoint_type}'")
    
    global db_pool
    connection = None
    try:
        # Get connection from pool
        connection = db_pool.getconn()
        
        with connection.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute("""
                SELECT require_translation
                FROM cloud.bt_transaction_workflow
                WHERE stateid = %s AND code = %s AND endpoint_type = %s
                LIMIT 1
            """, (state_id, code, endpoint_type))
            
            result = cursor.fetchone()
        
        if result:
            require_translation = result["require_translation"]
            entry = WorkflowEntry(
                stateid=state_id,
                code=code,
                endpoint_type=endpoint_type,
                require_translation=require_translation
            )
            
            # Add to cache for next time
            workflow_cache[cache_key] = entry
            
            logger.info(f"✅ Found workflow configuration: require_translation={require_translation}")
            return entry
        else:
            logger.warning(f"❌ No workflow configuration found for StateID='{state_id}', Code={code}, EndpointType='{endpoint_type}'")
        
        return None
        
    except Exception as e:
        logger.error(f"❌ Error querying workflow entry for StateID: {state_id}, Code: {code}, EndpointType: {endpoint_type}: {e}")
        return None
    finally:
        # Return connection to pool
        if connection and db_pool:
            db_pool.putconn(connection)

async def handle_workflow_message(message_body: Dict[str, Any]) -> None:
    """Handle a single workflow message"""
    global workflow_manager
    
    # Capture start time when message is received
    execution_start = datetime.now()
    
    try:
        # Extract required fields in camelCase (as set by gateway)
        uuid = message_body.get("UUID") or message_body.get("transactionFolio")
        state_id = message_body.get("stateId")  # camelCase
        code = message_body.get("code")
        endpoint_type = message_body.get("endpointType")  # camelCase
        
        # Create unique message ID for deduplication
        message_id = f"{uuid}_{state_id}_{code}_{endpoint_type}_{message_body.get('wsNo')}_{message_body.get('siteId')}"
        
        logger.info(f"📥 Request: code={code}, wsNo={message_body.get('wsNo')}, siteId={message_body.get('siteId')}, transactionFolio={uuid}, stateId={state_id}, endpointType={endpoint_type}")
        
        # Check for duplicate messages
        if message_id in processed_messages:
            logger.warning(f"⚠️ DUPLICATE MESSAGE DETECTED: {message_id} - Ignoring")
            return
        
        # Mark message as processed
        processed_messages.add(message_id)
        
        # Clean up old processed messages (keep only last 1000)
        if len(processed_messages) > 1000:
            processed_messages.clear()
            logger.info("🧹 Cleaned up processed messages cache")
        
        # Validate message (only required fields: uuid, state_id, code, endpoint_type)
        if not all([uuid, state_id, code, endpoint_type]):
            logger.warning(f"⚠️ Missing required fields: uuid={uuid}, state_id={state_id}, code={code}, endpoint_type={endpoint_type}")
            return  # Skip malformed message

        # Get workflow configuration
        workflow_entry = get_workflow_entry(state_id, code, endpoint_type)
        
        if not workflow_entry:
            # No workflow configuration found
            error_message = f"No workflow configuration found for StateID: {state_id}, Code: {code}, EndpointType: {endpoint_type}"
            logger.warning(f"⚠️ {error_message}")
            
            # Send error to state_handler
            await send_to_state_handler_rabbitmq(
                uuid, code, state_id, message_body, 
                execution_start, "error", "404", error_message
            )
            return
            
        # FIRST: Check if this is a response - evaluate if translation is needed
        if state_id == "response":
            # Get workflow configuration for response to check if translation is needed
            response_workflow_entry = get_workflow_entry(state_id, code, endpoint_type)
            
            if response_workflow_entry and response_workflow_entry.require_translation == 1:
                # Response needs translation - send to mapper
                logger.info(f"🔄 Routing RESPONSE to MAPPER: require_translation={response_workflow_entry.require_translation}")
                await workflow_manager.send_to_mapper(message_body)
                
                # Send success to state_handler
                await send_to_state_handler_rabbitmq(
                    uuid, code, state_id, message_body, 
                    execution_start, "success", "200", f"Response routed to mapper (require_translation={response_workflow_entry.require_translation})"
                )
            else:
                # Response doesn't need translation - send to gateway
                require_translation = response_workflow_entry.require_translation if response_workflow_entry else "not_found"
                logger.info(f"🔄 Routing RESPONSE to GATEWAY: require_translation={require_translation}")
                logger.info(f"📤 Sending response to GATEWAY: transactionFolio={uuid}, stateId=response")
                await workflow_manager.send_to_gateway(message_body)
                logger.info(f"✅ Response sent to GATEWAY successfully: {uuid}")
                
                # Send success to state_handler
                await send_to_state_handler_rabbitmq(
                    uuid, code, state_id, message_body, 
                    execution_start, "success", "200", f"Response routed to gateway (require_translation={require_translation})"
                )
            return
        
        # SECOND: For requests, check cardPresent routing: cardPresent=false goes to switch-link (all codes)
        card_present = None
        if "dataTransaction" in message_body and "cardPresent" in message_body["dataTransaction"]:
            card_present = message_body["dataTransaction"]["cardPresent"]
        
        # Initialize variables
        target_service = None
        require_translation = None
        
        if card_present == "false":
            # Route any request with cardPresent=false to switch-link
            target_service = "switch-link"
            require_translation = None
            logger.info(f"🔄 Routing to SWITCH-LINK: code={code}, cardPresent={card_present}, stateId={state_id}")
            await workflow_manager.send_to_switch_link(message_body)
        else:
            # Standard routing based on workflow configuration and StateID
            require_translation = workflow_entry.require_translation
            
            if require_translation == 1:
                # Needs translation - always goes to mapper
                target_service = "mapper"
                logger.info(f"🔄 Routing to MAPPER: require_translation={require_translation}")
                await workflow_manager.send_to_mapper(message_body)
            else:
                # No translation needed - route based on StateID
                if state_id == "request":
                    # Request without translation goes to link
                    target_service = "link"
                    logger.info(f"🔄 Routing to LINK: stateId={state_id}, require_translation={require_translation}")
                    await workflow_manager.send_to_link(message_body)
                else:
                    # Unknown StateID (response was already handled above)
                    error_message = f"Unknown StateID '{state_id}' for routing (expected 'request' - responses already handled)"
                    logger.error(f"❌ {error_message}")
                    
                    # Send error to state_handler
                    await send_to_state_handler_rabbitmq(
                        uuid, code, state_id, message_body, 
                        execution_start, "error", "400", error_message
                    )
                    return
        
        # Send success to state_handler
        await send_to_state_handler_rabbitmq(
            uuid, code, state_id, message_body, 
            execution_start, "success", "200", f"Message routed to {target_service} queue (StateID={state_id}, require_translation={require_translation})"
        )
        
        # Calculate execution time
        execution_time = (datetime.now() - execution_start).total_seconds() * 1000
        logger.info(f"⏱️ Execution time: {execution_time:.2f}ms")
        
    except Exception as e:
        # Handle errors and send error state
        error_message = f"Error processing workflow request: {str(e)}"
        
        # Send error to state_handler
        await send_to_state_handler_rabbitmq(
            uuid, code, state_id, message_body, 
            execution_start, "error", "500", error_message
        )
        
        logger.error(f"❌ Error processing workflow message: {e}")

async def send_to_state_handler_rabbitmq(transaction_folio: str, code: str, state_id: str, 
                                        payload: Dict[str, Any], execution_start: datetime, 
                                        status: str, response_code: str, response_message: str):
    """Send message to state_handler using workflow manager (RabbitMQ)"""
    global workflow_manager
    
    try:
        # Capture end time and calculate execution time
        execution_end = datetime.now()
        total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
        
        # Build operation_type like link/watcher does
        operation_type = f"{code}-{state_id}"
        
        # Create state handler payload (simplified for RabbitMQ)
        state_handler_payload = {
            "transaction_folio": transaction_folio,
            "operation_type": operation_type,
            "current_step": "workflow",
            "status": status,
            "payload": payload,
            "execution_start_time": execution_start.isoformat(),
            "execution_end_time": execution_end.isoformat(),
            "execution_total_time": str(int(total_execution_ms)),
            "response_code": response_code,
            "response_message": response_message
        }
        
        # Send using workflow manager (RabbitMQ)
        await workflow_manager.send_to_state_handler(state_handler_payload)
        
        logger.info(f"📤 Sent to state_handler via workflow manager")
        logger.info(f"📋 Message details - Transaction: {transaction_folio}, Operation: {operation_type}, Status: {status}")
        logger.info(f"⏱️ Execution time: {total_execution_ms:.2f}ms")
        
    except Exception as e:
        logger.error(f"Error sending to state_handler: {e}")

async def process_messages():
    """Main message processing loop (RabbitMQ)"""
    global workflow_manager
    
    try:
        # Initialize workflow manager
        workflow_manager = get_workflow_manager()
        await workflow_manager.initialize()
        logger.info("✅ Workflow manager initialized")
        
        # Initialize database connection pool
        init_db_pool()
        
        # Initialize workflow cache at startup for better performance
        load_workflow_cache()
        
        # RabbitMQ mode - start consuming messages
        await workflow_manager.start_consuming(handle_workflow_message)
        logger.info("✅ RabbitMQ mode: Started consuming workflow messages")
        
        # Keep running (RabbitMQ handles the message loop)
        while True:
            await asyncio.sleep(1)
                    
    except Exception as e:
        logger.error(f"Fatal error in process_messages: {e}")
        raise

def run_fastapi():
    """Run FastAPI server in a separate thread"""
    uvicorn.run(app, host="0.0.0.0", port=config.PORT, log_level="info")

async def main():
    """Main function to run both FastAPI and message processing"""
    # Start FastAPI in a separate thread
    fastapi_thread = threading.Thread(target=run_fastapi, daemon=True)
    fastapi_thread.start()
    
    logger.info(f"Health endpoint available at http://0.0.0.0:{config.PORT}/health")
    
    # Start message processing
    await process_messages()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    except Exception as e:
        logger.error(f"Application error: {e}")
        sys.exit(1)