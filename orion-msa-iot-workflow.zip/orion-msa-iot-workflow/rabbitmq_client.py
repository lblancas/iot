#!/usr/bin/env python3
"""
RabbitMQ Client for Orion Microservices
Optimized for Python async/await patterns
"""

import asyncio
import json
import logging
import ssl
from typing import Dict, Any, Optional, Callable, List
from datetime import datetime
from dataclasses import dataclass

import aio_pika
from aio_pika import Message, ExchangeType, DeliveryMode
from aio_pika.abc import AbstractConnection, AbstractChannel, AbstractExchange, AbstractQueue

logger = logging.getLogger(__name__)

@dataclass
class RabbitMQConfig:
    """RabbitMQ connection configuration"""
    host: str
    port: int = 5671
    username: str = "orion_admin"
    password: str = "OrionMQ2024!"
    virtual_host: str = "/"
    use_ssl: bool = True
    environment: str = "dev"
    
    @property
    def connection_url(self) -> str:
        """Generate connection URL"""
        protocol = "amqps" if self.use_ssl else "amqp"
        return f"{protocol}://{self.username}:{self.password}@{self.host}:{self.port}{self.virtual_host}"
    
    def get_queue_name(self, service: str) -> str:
        """Generate environment-specific queue name"""
        return f"sps-{self.environment}-orion-queue-{service}"
    
    def get_exchange_name(self) -> str:
        """Generate environment-specific exchange name"""
        return f"sps-{self.environment}-orion-exchange"
    
    def get_dlx_name(self) -> str:
        """Generate environment-specific DLX name"""
        return f"sps-{self.environment}-orion-dlx"

class RabbitMQClient:
    """Async RabbitMQ client optimized for Orion microservices"""
    
    def __init__(self, config: RabbitMQConfig):
        self.config = config
        self._connection: Optional[AbstractConnection] = None
        self._channel: Optional[AbstractChannel] = None
        self._exchange: Optional[AbstractExchange] = None
        self._queues: Dict[str, AbstractQueue] = {}
        self._consumers: Dict[str, Any] = {}
        self._is_connected = False
        
    async def connect(self) -> None:
        """Establish connection to RabbitMQ"""
        try:
            # Configure SSL context if needed
            ssl_context = None
            if self.config.use_ssl:
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE
            
            # Create connection
            self._connection = await aio_pika.connect_robust(
                self.config.connection_url,
                ssl_context=ssl_context,
                heartbeat=60,
                client_properties={"connection_name": "orion-microservice"}
            )
            
            # Create channel with optimal settings
            self._channel = await self._connection.channel()
            await self._channel.set_qos(prefetch_count=10)  # Optimized for microservices
            
            # Declare main exchange
            self._exchange = await self._channel.declare_exchange(
                self.config.get_exchange_name(),
                ExchangeType.TOPIC,
                durable=True
            )
            
            # Declare DLX (Dead Letter Exchange)
            await self._channel.declare_exchange(
                self.config.get_dlx_name(),
                ExchangeType.DIRECT,
                durable=True
            )
            
            self._is_connected = True
            logger.info(f"✅ Connected to RabbitMQ: {self.config.host}")
            
        except Exception as e:
            logger.error(f"❌ Failed to connect to RabbitMQ: {e}")
            raise
    
    async def disconnect(self) -> None:
        """Close RabbitMQ connection"""
        try:
            if self._connection and not self._connection.is_closed:
                await self._connection.close()
                self._is_connected = False
                logger.info("🔌 Disconnected from RabbitMQ")
        except Exception as e:
            logger.error(f"Error disconnecting: {e}")
    
    async def declare_queue(self, service: str, **queue_args) -> AbstractQueue:
        """Declare a queue for a service"""
        queue_name = self.config.get_queue_name(service)
        
        # Default queue arguments for enterprise reliability
        default_args = {
            "x-dead-letter-exchange": self.config.get_dlx_name(),
            "x-dead-letter-routing-key": service,
            "x-message-ttl": 300000,  # 5 minutes
        }
        default_args.update(queue_args)
        
        queue = await self._channel.declare_queue(
            queue_name,
            durable=True,
            arguments=default_args
        )
        
        self._queues[service] = queue
        logger.info(f"📥 Declared queue: {queue_name}")
        return queue
    
    async def declare_queue_with_name(self, queue_name: str, **queue_args) -> AbstractQueue:
        """Declare a queue with explicit name (for unique queues like gateway instances)"""
        # Extract RabbitMQ native parameters from queue_args
        auto_delete = queue_args.pop('auto_delete', False)
        exclusive = queue_args.pop('exclusive', False)
        
        # Default queue arguments for message TTL
        default_args = {
            "x-message-ttl": 300000,  # 5 minutes
        }
        default_args.update(queue_args)  # Remaining args go to arguments
        
        queue = await self._channel.declare_queue(
            queue_name,
            durable=False,        # Dynamic queues don't need to be durable
            auto_delete=auto_delete,  # Queue deleted when last consumer disconnects
            exclusive=exclusive,      # Only this connection can access
            arguments=default_args
        )
        
        logger.info(f"📥 Declared custom queue: {queue_name} (auto_delete={auto_delete}, exclusive={exclusive})")
        return queue
    
    async def bind_queue_to_topic(self, queue: AbstractQueue, routing_key: str, exchange_name: str = None) -> None:
        """Bind a queue object to a topic routing key"""
        try:
            target_exchange = self._exchange
            if exchange_name:
                target_exchange = await self._channel.get_exchange(exchange_name)
            
            # Bind queue to exchange with routing key
            await queue.bind(target_exchange, routing_key)
            
            logger.info(f"🔗 Bound queue '{queue.name}' to topic '{routing_key}' on exchange '{target_exchange.name}'")
            
        except Exception as e:
            logger.error(f"❌ Failed to bind queue {queue.name} to topic {routing_key}: {e}")
            raise
    
    async def publish_message(
        self, 
        routing_key: str, 
        message: Dict[str, Any],
        exchange: Optional[str] = None,
        delivery_mode: DeliveryMode = DeliveryMode.PERSISTENT
    ) -> None:
        """Publish message to exchange"""
        if not self._is_connected:
            raise ConnectionError("Not connected to RabbitMQ")
        
        try:
            # Add timestamp and service metadata
            enhanced_message = {
                **message
                # "_timestamp": datetime.now().isoformat(),
                # "_routing_key": routing_key,
                # "_exchange": exchange or self.config.get_exchange_name()
            }
            
            # Create message
            msg = Message(
                json.dumps(enhanced_message).encode(),
                delivery_mode=delivery_mode,
                content_type="application/json",
                headers={
                    "service": "orion-microservice",
                    "environment": self.config.environment
                }
            )
            
            # Publish to exchange
            target_exchange = self._exchange
            if exchange:
                target_exchange = await self._channel.get_exchange(exchange)
            
            await target_exchange.publish(msg, routing_key=routing_key)
            
            logger.info(f"📤 Published message: {routing_key}")
            logger.debug(f"📋 Message: {enhanced_message}")
            
        except Exception as e:
            logger.error(f"❌ Failed to publish message: {e}")
            raise
    
    async def consume_messages(
        self,
        service: str,
        callback: Callable[[Dict[str, Any]], None],
        auto_ack: bool = False
    ) -> None:
        """Start consuming messages for a service"""
        if service not in self._queues:
            await self.declare_queue(service)
        
        queue = self._queues[service]
        
        async def message_handler(message: aio_pika.IncomingMessage):
            async with message.process(requeue=True):
                try:
                    # Parse message
                    body = json.loads(message.body.decode())
                    
                    logger.info(f"📥 Received message for {service}")
                    logger.debug(f"📋 Message: {body}")
                    
                    # Process message
                    await callback(body)
                    
                    logger.info(f"✅ Processed message for {service}")
                    
                except json.JSONDecodeError as e:
                    logger.error(f"❌ Invalid JSON in message: {e}")
                    # Don't requeue malformed messages
                    raise aio_pika.exceptions.MessageProcessError() from e
                    
                except Exception as e:
                    logger.error(f"❌ Error processing message for {service}: {e}")
                    # Message will be requeued due to requeue=True
                    raise
        
        # Start consuming
        consumer = await queue.consume(message_handler, no_ack=auto_ack)
        self._consumers[service] = consumer
        
        logger.info(f"🔄 Started consuming messages for {service}")
    
    async def consume_messages_from_queue(
        self,
        queue: AbstractQueue,
        callback: Callable[[Dict[str, Any]], None],
        queue_name: str = "unknown",
        auto_ack: bool = False
    ) -> None:
        """Start consuming messages from a specific queue object"""
        
        async def message_handler(message: aio_pika.IncomingMessage):
            async with message.process(requeue=True):
                try:
                    # Parse message
                    body = json.loads(message.body.decode())
                    
                    logger.info(f"📥 Received message for {queue_name}")
                    logger.debug(f"📋 Message: {body}")
                    
                    # Process message
                    await callback(body)
                    
                    logger.info(f"✅ Processed message for {queue_name}")
                    
                except json.JSONDecodeError as e:
                    logger.error(f"❌ Failed to parse message JSON for {queue_name}: {e}")
                    # Don't requeue malformed messages
                    raise aio_pika.exceptions.MessageProcessError() from e
                    
                except Exception as e:
                    logger.error(f"❌ Error processing message for {queue_name}: {e}")
                    # Message will be requeued due to requeue=True
                    raise
        
        # Start consuming
        consumer = await queue.consume(message_handler, no_ack=auto_ack)
        logger.info(f"🔄 Started consuming messages for {queue_name}")
    
    async def stop_consuming(self, service: str) -> None:
        """Stop consuming messages for a service"""
        if service in self._consumers:
            consumer = self._consumers[service]
            await consumer.cancel()
            del self._consumers[service]
            logger.info(f"⏹️ Stopped consuming messages for {service}")
    
    async def health_check(self) -> bool:
        """Check if RabbitMQ connection is healthy"""
        try:
            if not self._is_connected or not self._connection or self._connection.is_closed:
                return False
            
            # Simple health check by declaring a temp exchange
            temp_exchange = await self._channel.declare_exchange(
                "health_check_temp",
                ExchangeType.DIRECT,
                auto_delete=True
            )
            await temp_exchange.delete()
            
            return True
            
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False

# Helper function to create client from environment
def create_rabbitmq_client(
    host: str,
    environment: str = "dev",
    username: str = "orion_admin",
    password: str = "OrionMQ2024!"
) -> RabbitMQClient:
    """Factory function to create RabbitMQ client"""
    config = RabbitMQConfig(
        host=host,
        username=username,
        password=password,
        environment=environment
    )
    return RabbitMQClient(config)