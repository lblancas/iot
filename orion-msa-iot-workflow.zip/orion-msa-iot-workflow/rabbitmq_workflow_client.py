#!/usr/bin/env python3
"""
RabbitMQ Workflow Client
Handles message consumption and publishing for Workflow service
"""

import asyncio
import json
import logging
import uuid
import os
from datetime import datetime
from typing import Dict, Any, Optional, Callable

# Import our RabbitMQ client (now local to workflow service)
from rabbitmq_client import RabbitMQClient, RabbitMQConfig

logger = logging.getLogger(__name__)

class WorkflowRabbitMQClient:
    """RabbitMQ client specifically designed for Workflow service"""
    
    def __init__(self, rabbitmq_host: str, environment: str = "dev"):
        self.config = RabbitMQConfig(
            host=rabbitmq_host,
            environment=environment
        )
        self.client = RabbitMQClient(self.config)
        self._consuming = False
        self._consumer_task: Optional[asyncio.Task] = None
        
    async def initialize(self) -> None:
        """Initialize connection and setup workflow queue"""
        try:
            # Connect to RabbitMQ
            await self.client.connect()
            
            # Declare workflow queue
            workflow_queue = await self.client.declare_queue("workflow")
            
            # Declare DLQ for workflow
            dlq_name = f"sps-{self.config.environment}-orion-dlq-workflow"
            dlq_queue = await self.client._channel.declare_queue(
                dlq_name,
                durable=True,
                arguments={"x-queue-type": "classic"}
            )
            
            # Bind DLQ to DLX exchange
            dlx_exchange = await self.client._channel.get_exchange(self.config.get_dlx_name())
            await dlq_queue.bind(dlx_exchange, "workflow")
            
            # Bind workflow queue to receive messages from watcher
            await self.client.bind_queue_to_topic(
                queue=workflow_queue,
                routing_key="orion.workflow.request"
            )
            
            logger.info("✅ Workflow RabbitMQ client initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Workflow RabbitMQ client: {e}")
            raise
    
    async def start_consuming(self, message_handler: Callable[[Dict[str, Any]], None]) -> None:
        """Start consuming messages from workflow queue"""
        try:
            await self.client.consume_messages("workflow", message_handler)
            self._consuming = True
            logger.info("🔄 Started consuming workflow messages")
            
        except Exception as e:
            logger.error(f"❌ Failed to start workflow consumer: {e}")
            raise
    
    async def send_to_mapper(self, payload: Dict[str, Any]) -> None:
        """Send message to mapper service"""
        try:
            await self.client.publish_message(
                routing_key="orion.mapper.request",
                message=payload
            )
            logger.info(f"📤 Sent message to mapper: {payload.get('transactionFolio') or payload.get('UUID', 'unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to mapper: {e}")
            raise
    
    async def send_to_link(self, payload: Dict[str, Any]) -> None:
        """Send message to link service"""
        try:
            await self.client.publish_message(
                routing_key="orion.link.request",
                message=payload
            )
            logger.info(f"📤 Sent message to link: {payload.get('transactionFolio') or payload.get('UUID', 'unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to link: {e}")
            raise
    
    async def send_to_switch_link(self, payload: Dict[str, Any]) -> None:
        """Send message to switch-link service"""
        try:
            await self.client.publish_message(
                routing_key="orion.switch-link.request",
                message=payload
            )
            logger.info(f"📤 Sent message to switch-link: {payload.get('transactionFolio') or payload.get('UUID', 'unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to switch-link: {e}")
            raise
    
    async def send_to_gateway(self, payload: Dict[str, Any]) -> None:
        """Send response message back to gateway"""
        try:
            await self.client.publish_message(
                routing_key="orion.gateway.response",
                message=payload
            )
            logger.info(f"📤 Sent response to gateway: {payload.get('transactionFolio') or payload.get('UUID', 'unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to gateway: {e}")
            raise
    
    async def send_to_state_handler(self, payload: Dict[str, Any]) -> None:
        """Send message to state handler service"""
        try:
            await self.client.publish_message(
                routing_key="orion.state-handler.update",
                message=payload
            )
            logger.info(f"📤 Sent message to state handler: {payload.get('transaction_folio', 'unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to state handler: {e}")
            raise
    
    async def health_check(self) -> bool:
        """Check if RabbitMQ connection is healthy"""
        try:
            return await self.client.health_check()
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def disconnect(self) -> None:
        """Close RabbitMQ connection"""
        try:
            # Stop consuming
            if self._consuming:
                await self.client.stop_consuming("workflow")
                self._consuming = False
            
            # Cancel consumer task
            if self._consumer_task and not self._consumer_task.done():
                self._consumer_task.cancel()
                try:
                    await self._consumer_task
                except asyncio.CancelledError:
                    pass
            
            # Disconnect client
            await self.client.disconnect()
            
            logger.info("🔌 Workflow RabbitMQ client disconnected")
            
        except Exception as e:
            logger.error(f"Error disconnecting Workflow client: {e}")

# Factory function for easier integration
def create_workflow_rabbitmq_client(rabbitmq_host: str, environment: str = "dev") -> WorkflowRabbitMQClient:
    """Create and return Workflow RabbitMQ client"""
    return WorkflowRabbitMQClient(rabbitmq_host, environment)