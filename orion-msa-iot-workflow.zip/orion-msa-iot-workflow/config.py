#!/usr/bin/env python3
"""
Configuration management for Workflow microservice
"""

import os
import json
import logging
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger("orion-workflow")

class Config:
    """Configuration class for Workflow microservice"""
    
    def __init__(self):
        self.AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
        self.AWS_SECRET_NAME = os.getenv("AWS_SECRET_NAME", "sps-dev-orion-secret-iot-workflow")
        self.ENVIRONMENT = os.getenv("ENVIRONMENT", "dev")
        self.PORT = int(os.getenv("PORT", 40084))
        
    def get_secrets(self) -> dict:
        """Get secrets from AWS Secrets Manager"""
        try:
            session = boto3.session.Session()
            client = session.client("secretsmanager", region_name=self.AWS_REGION)
            
            response = client.get_secret_value(SecretId=self.AWS_SECRET_NAME)
            secrets = json.loads(response["SecretString"])
            
            logger.info(f"Successfully loaded secrets from {self.AWS_SECRET_NAME}")
            return secrets
            
        except ClientError as e:
            logger.error(f"Error retrieving secret {self.AWS_SECRET_NAME}: {e}")
            raise e

# Global config instance
config = Config()