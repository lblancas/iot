"""
Data models for Workflow microservice
"""

from datetime import datetime
from typing import Optional, Dict, Any
from pydantic import BaseModel

class WorkflowEntry(BaseModel):
    """Workflow entry model"""
    stateid: str
    code: str  # Changed from int to str
    endpoint_type: str
    require_translation: bool
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class WorkflowRequest(BaseModel):
    """Workflow request model"""
    uuid: str
    state_id: str
    code: str  # Changed from int to str
    endpoint_type: str
    payload: Dict[str, Any]

class WorkflowResponse(BaseModel):
    """Workflow response model"""
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None
    response_code: str

class StateHandlerMessage(BaseModel):
    """Message structure for state handler communications"""
    transaction_folio: str
    operation_type: str
    current_step: str = "workflow"
    status: str  # "success" or "error"
    payload: Dict[str, Any]
    execution_start_time: datetime
    execution_end_time: datetime
    execution_total_time: str  # in milliseconds as string
    response_code: str
    response_message: str

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str = "healthy"
    service: str = "workflow"
    timestamp: datetime
    version: str = "1.0.0"