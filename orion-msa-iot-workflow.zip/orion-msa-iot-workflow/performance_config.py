"""
Performance Configuration for Workflow Microservice
Centralized configuration for performance parameters
"""

import os

class PerformanceConfig:
    """Performance configuration for workflow microservice"""
    
    # RabbitMQ Configuration - Optimized for low latency
    RABBITMQ_CONNECTION_TIMEOUT = int(os.getenv("RABBITMQ_CONNECTION_TIMEOUT", "30"))
    RABBITMQ_HEARTBEAT = int(os.getenv("RABBITMQ_HEARTBEAT", "60"))
    RABBITMQ_BLOCKED_CONNECTION_TIMEOUT = int(os.getenv("RABBITMQ_BLOCKED_CONNECTION_TIMEOUT", "300"))
    
    # Cache Configuration
    CACHE_TTL_SECONDS = int(os.getenv("CACHE_TTL_SECONDS", "300"))  # 5 minutes
    
    # Logging Configuration
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    
    @classmethod
    def get_rabbitmq_config(cls):
        """Get RabbitMQ client configuration"""
        return {
            "connection_timeout": cls.RABBITMQ_CONNECTION_TIMEOUT,
            "heartbeat": cls.RABBITMQ_HEARTBEAT,
            "blocked_connection_timeout": cls.RABBITMQ_BLOCKED_CONNECTION_TIMEOUT
        }
    
    @classmethod
    def log_configuration(cls):
        """Log current performance configuration"""
        return f"""
🔧 Workflow Performance Configuration:
   RabbitMQ Connection Timeout: {cls.RABBITMQ_CONNECTION_TIMEOUT}s
   RabbitMQ Heartbeat: {cls.RABBITMQ_HEARTBEAT}s
   RabbitMQ Blocked Connection Timeout: {cls.RABBITMQ_BLOCKED_CONNECTION_TIMEOUT}s
   Cache TTL: {cls.CACHE_TTL_SECONDS}s
   Log Level: {cls.LOG_LEVEL}
        """.strip()
