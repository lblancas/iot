"""
Data models for State Handler microservice
"""

from datetime import datetime
from typing import Optional, Any, Dict
from pydantic import BaseModel

class TransactionExecutionMessage(BaseModel):
    """Message structure for transaction execution state tracking"""
    transaction_folio: str
    operation_type: str
    current_step: Optional[str] = None
    status: str  # "success", "error", "pending", etc.
    payload: Optional[Dict[str, Any]] = None
    execution_start_time: Optional[str] = None  # ISO format string
    execution_end_time: Optional[str] = None    # ISO format string
    execution_total_time: Optional[str] = None  # Total execution time in milliseconds
    response_code: Optional[str] = None
    response_message: Optional[str] = None

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str = "healthy"
    service: str = "state-handler"
    timestamp: datetime
    version: str = "1.0.0"
    database_connected: bool = False
    queue_accessible: bool = False

class DatabaseConfig(BaseModel):
    """Database connection configuration"""
    host: str
    port: str
    dbname: str
    username: str
    password: str