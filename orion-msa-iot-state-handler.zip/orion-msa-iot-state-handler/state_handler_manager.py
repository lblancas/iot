#!/usr/bin/env python3
"""
State Handler Manager - Handles RabbitMQ connections and operations
"""

import logging
from typing import Dict, Any, Optional, Callable
from config import config

from rabbitmq_state_handler_client import StateHandlerRabbitMQClient

logger = logging.getLogger(__name__)

class StateHandlerManager:
    """
    Manages RabbitMQ connections and operations for State Handler
    """
    
    def __init__(self):
        self.rabbitmq_client: Optional[StateHandlerRabbitMQClient] = None
        logger.info("🔧 State Handler Manager initialized with RabbitMQ")
    
    async def initialize(self) -> None:
        """Initialize RabbitMQ client"""
        try:
            secrets = config.get_secrets()
            
            # Initialize RabbitMQ client with secrets
            rabbitmq_host = secrets.get("rabbitmq_host")
            rabbitmq_env = secrets.get("rabbitmq_environment", "dev")
            
            if not rabbitmq_host:
                raise ValueError("rabbitmq_host not found in secrets")
            
            self.rabbitmq_client = StateHandlerRabbitMQClient(
                rabbitmq_host=rabbitmq_host,
                environment=rabbitmq_env
            )
            await self.rabbitmq_client.initialize()
            logger.info("✅ RabbitMQ client initialized")
                
        except Exception as e:
            logger.error(f"❌ Failed to initialize State Handler Manager: {e}")
            raise
    
    async def start_consuming(self, message_handler: Callable[[Dict[str, Any]], None]) -> None:
        """Start consuming messages from state handler queue"""
        await self.rabbitmq_client.start_consuming(message_handler)
    
    async def stop_consuming(self) -> None:
        """Stop consuming messages"""
        if self.rabbitmq_client:
            await self.rabbitmq_client.stop_consuming()
    
    async def health_check(self) -> bool:
        """Check RabbitMQ health"""
        try:
            return await self.rabbitmq_client.health_check()
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def send_to_exception_handler(self, message_body: Dict[str, Any], error_message: str) -> None:
        """Send error messages to exception handler via RabbitMQ"""
        try:
            if self.rabbitmq_client:
                await self.rabbitmq_client.send_to_exception_handler(message_body, error_message)
            else:
                logger.error("❌ RabbitMQ client not initialized for exception handler")
                
        except Exception as e:
            logger.error(f"❌ Error sending to exception handler via manager: {e}")

    async def disconnect(self) -> None:
        """Disconnect from RabbitMQ"""
        try:
            if self.rabbitmq_client:
                await self.rabbitmq_client.disconnect()
                
            logger.info("🔌 RabbitMQ client disconnected")
            
        except Exception as e:
            logger.error(f"Error disconnecting from RabbitMQ: {e}")

# Global state handler manager instance
state_handler_manager: Optional[StateHandlerManager] = None

def get_state_handler_manager() -> StateHandlerManager:
    """Get or create state handler manager singleton"""
    global state_handler_manager
    if state_handler_manager is None:
        state_handler_manager = StateHandlerManager()
    return state_handler_manager

