-- State Handler Database Schema
-- Creates the bt_transaction_executions table for transaction state tracking

-- Connect to the nxt_dev database
\c nxt_dev;

-- Create cloud schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS cloud;

-- Set search path to cloud schema
SET search_path TO cloud, public;

-- ============================================================================
-- STATE HANDLER TABLES
-- ============================================================================

-- Transaction executions table (for state tracking)
CREATE TABLE IF NOT EXISTS cloud.bt_transaction_executions (
    id SERIAL PRIMARY KEY,
    transaction_folio VARCHAR(255) NOT NULL,
    operation_type VARCHAR(100) NOT NULL,
    current_step VARCHAR(100),
    status VARCHAR(50) NOT NULL,
    payload JSONB,
    execution_start_time TIMESTAMP,
    execution_end_time TIMESTAMP,
    execution_total_time VARCHAR(50), -- Total execution time in milliseconds as string
    response_code VARCHAR(10),
    response_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- INDEXES
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_bt_transaction_executions_folio ON cloud.bt_transaction_executions(transaction_folio);
CREATE INDEX IF NOT EXISTS idx_bt_transaction_executions_operation ON cloud.bt_transaction_executions(operation_type);
CREATE INDEX IF NOT EXISTS idx_bt_transaction_executions_status ON cloud.bt_transaction_executions(status);
CREATE INDEX IF NOT EXISTS idx_bt_transaction_executions_step ON cloud.bt_transaction_executions(current_step);
CREATE INDEX IF NOT EXISTS idx_bt_transaction_executions_created ON cloud.bt_transaction_executions(created_at);

-- ============================================================================
-- TRIGGERS AND FUNCTIONS
-- ============================================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger for bt_transaction_executions
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_bt_transaction_executions_updated_at') THEN
        CREATE TRIGGER update_bt_transaction_executions_updated_at 
            BEFORE UPDATE ON cloud.bt_transaction_executions 
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
END $$;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

\echo ''
\echo '============================================================================'
\echo 'State Handler Database Schema Creation Complete'
\echo '============================================================================'
\echo ''

-- Show table info
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_schema = 'cloud' 
  AND table_name = 'bt_transaction_executions'
ORDER BY ordinal_position;

\echo ''
\echo 'bt_transaction_executions table ready for State Handler microservice!'
\echo '';