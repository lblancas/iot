"""
Configuration management for State Handler microservice
"""

import os
import json
import boto3
import logging
from typing import Dict, Any
from pydantic import BaseModel
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

class BaseConfig(BaseModel):
    """Base configuration model"""
    class Config:
        extra = "allow"
    
    # Environment
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "local")
    AWS_REGION: str = os.getenv("AWS_REGION", "us-east-1")
    
    # Service configuration
    PORT: int = int(os.getenv("PORT", "40083"))
    
    # AWS Secrets Manager
    SECRETS_MANAGER_SECRET_NAME: str = os.getenv("SECRETS_MANAGER_SECRET_NAME", "sps-dev-orion-secret-iot-state-handler")
    AWS_SECRET_NAME: str = os.getenv("AWS_SECRET_NAME", "sps-dev-orion-secret-iot-state-handler")
    
    # Database Configuration (for local environment)
    DB_HOST: str = os.getenv("DB_HOST", "localhost")
    DB_PORT: str = os.getenv("DB_PORT", "5432")
    DB_NAME: str = os.getenv("DB_NAME", "orion")
    DB_USER: str = os.getenv("DB_USER", "postgres")
    DB_PASSWORD: str = os.getenv("DB_PASSWORD", "password")
    
    # RabbitMQ configuration
    RABBITMQ_HOST: str = os.getenv("RABBITMQ_HOST", "")
    RABBITMQ_USERNAME: str = os.getenv("RABBITMQ_USERNAME", "")
    RABBITMQ_PASSWORD: str = os.getenv("RABBITMQ_PASSWORD", "")
    RABBITMQ_ENVIRONMENT: str = os.getenv("RABBITMQ_ENVIRONMENT", "dev")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._secrets_cache = None

    def get_secrets(self) -> Dict[str, Any]:
        """Get configuration from AWS Secrets Manager or environment variables"""
        if self._secrets_cache is not None:
            return self._secrets_cache

        if self.ENVIRONMENT == "local":
            # Use environment variables for local development
            self._secrets_cache = {
                "host": self.DB_HOST,
                "port": self.DB_PORT,
                "dbname": self.DB_NAME,
                "username": self.DB_USER,
                "password": self.DB_PASSWORD,
                # RabbitMQ config from environment (local dev)
                "rabbitmq_host": self.RABBITMQ_HOST,
                "rabbitmq_username": self.RABBITMQ_USERNAME,
                "rabbitmq_password": self.RABBITMQ_PASSWORD,
                "rabbitmq_environment": self.RABBITMQ_ENVIRONMENT
            }
        else:
            # Use AWS Secrets Manager for cloud environments
            try:
                session = boto3.session.Session()
                client = session.client(
                    service_name="secretsmanager", 
                    region_name=self.AWS_REGION
                )
                
                response = client.get_secret_value(SecretId=self.AWS_SECRET_NAME)
                self._secrets_cache = json.loads(response["SecretString"])
                
                logger.info(f"Successfully loaded secrets from {self.AWS_SECRET_NAME}")
                
            except ClientError as e:
                logger.error(f"Error retrieving secrets from {self.AWS_SECRET_NAME}: {e}")
                raise e
            except Exception as e:
                logger.error(f"Unexpected error loading secrets: {e}")
                raise e

        return self._secrets_cache

# Global configuration instance
config = BaseConfig()