#!/usr/bin/env python3
"""
RabbitMQ State Handler Client
Handles message consumption and publishing for State Handler service
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional, Callable

# Import our RabbitMQ client
from rabbitmq_client import RabbitMQClient, RabbitMQConfig

logger = logging.getLogger(__name__)

class StateHandlerRabbitMQClient:
    """RabbitMQ client specifically designed for State Handler service"""
    
    def __init__(self, rabbitmq_host: str, environment: str = "dev"):
        self.config = RabbitMQConfig(
            host=rabbitmq_host,
            environment=environment
        )
        self.client = RabbitMQClient(self.config)
        self._consuming = False
        self._message_handler: Optional[Callable] = None
        
    async def initialize(self) -> None:
        """Initialize connection and setup state handler queue"""
        try:
            # Connect to RabbitMQ
            await self.client.connect()
            
            # Declare state handler queue
            queue = await self.client.declare_queue("state-handler")
            
            # Declare DLQ for state-handler
            dlq_name = f"sps-{self.config.environment}-orion-dlq-state-handler"
            dlq_queue = await self.client._channel.declare_queue(
                dlq_name,
                durable=True,
                arguments={"x-queue-type": "classic"}
            )
            
            # Bind DLQ to DLX exchange
            dlx_exchange = await self.client._channel.get_exchange(self.config.get_dlx_name())
            await dlq_queue.bind(dlx_exchange, "state-handler")
            
            # Bind queue to exchange with routing key
            await self.client.bind_queue_to_topic(
                queue, 
                "orion.state-handler.update", 
                self.client.config.get_exchange_name()
            )
            
            logger.info("✅ State Handler RabbitMQ client initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize State Handler RabbitMQ client: {e}")
            raise
    
    async def start_consuming(self, message_handler: Callable[[Dict[str, Any]], None]) -> None:
        """Start consuming messages from state handler queue"""
        try:
            self._message_handler = message_handler
            
            await self.client.consume_messages(
                "state-handler",
                self._handle_state_handler_message
            )
            
            self._consuming = True
            logger.info("🔄 Started consuming messages for State Handler")
            
        except Exception as e:
            logger.error(f"❌ Failed to start consuming: {e}")
            raise
    
    async def _handle_state_handler_message(self, message: Dict[str, Any]) -> None:
        """Handle incoming messages for state handler"""
        try:
            # Extract message details
            transaction_folio = message.get("transaction_folio")
            operation_type = message.get("operation_type")
            current_step = message.get("current_step")
            status = message.get("status")
            
            logger.info(f"📥 State Handler received: transactionFolio={transaction_folio}, operation={operation_type}, step={current_step}, status={status}")
            
            # Call the original message handler
            if self._message_handler:
                await self._message_handler(message)
                
        except Exception as e:
            logger.error(f"❌ Error handling state handler message: {e}")
            # Don't raise - let RabbitMQ handle retry logic
    
    async def stop_consuming(self) -> None:
        """Stop consuming messages"""
        try:
            if self._consuming:
                await self.client.stop_consuming("state-handler")
                self._consuming = False
                logger.info("⏹️ Stopped consuming messages for State Handler")
                
        except Exception as e:
            logger.error(f"Error stopping consumer: {e}")
    
    async def health_check(self) -> bool:
        """Check if RabbitMQ connection is healthy"""
        try:
            return await self.client.health_check()
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def send_to_exception_handler(self, message_body: Dict[str, Any], error_message: str) -> None:
        """Send error messages to exception handler queue"""
        try:
            # Create enhanced error payload for exception handler
            error_payload = message_body.copy()
            error_payload["status"] = "error"  # Force status to error since this is going to exception handler
            error_payload["error_details"] = error_message
            error_payload["source_service"] = "state-handler"
            error_payload["error_timestamp"] = datetime.now().isoformat()
            
            # Send message to exception-handler queue via RabbitMQ
            await self.client.publish_message(
                message=error_payload,
                routing_key="orion.exception-handler.notification",
                exchange=self.client.config.get_exchange_name()
            )
            
            logger.info(f"📤 RabbitMQ Sent error to exception-handler queue: {message_body.get('transaction_folio', 'unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Error sending to exception handler via RabbitMQ: {e}")

    async def disconnect(self) -> None:
        """Close RabbitMQ connection"""
        try:
            # Stop consuming first
            await self.stop_consuming()
            
            # Disconnect client
            await self.client.disconnect()
            
            logger.info("🔌 State Handler RabbitMQ client disconnected")
            
        except Exception as e:
            logger.error(f"Error disconnecting State Handler client: {e}")

# Factory function for easier integration
def create_state_handler_rabbitmq_client(rabbitmq_host: str, environment: str = "dev") -> StateHandlerRabbitMQClient:
    """Create and return State Handler RabbitMQ client"""
    return StateHandlerRabbitMQClient(rabbitmq_host, environment)
