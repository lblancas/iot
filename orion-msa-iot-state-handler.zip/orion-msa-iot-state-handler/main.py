import os
import sys
import json
import asyncio
import logging
import threading
from datetime import datetime
from typing import Dict, Any, List, Optional
import boto3
import asyncpg
import uvloop
from fastapi import FastAPI
import uvicorn

from config import config
from models import TransactionExecutionMessage, HealthResponse, DatabaseConfig
from state_handler_manager import get_state_handler_manager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("orion-state-handler")

# Global connection pool for high-performance database operations
db_pool: asyncpg.Pool = None

# FastAPI app for health endpoint
app = FastAPI(title="State Handler Microservice", version="1.0.0")

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    database_connected = False
    queue_accessible = False
    
    try:
        # Test asyncpg connection pool
        global db_pool
        if db_pool:
            async with db_pool.acquire() as connection:
                # Execute simple test query
                result = await connection.fetchval("SELECT 1")
                if result == 1:
                    database_connected = True
                    logger.debug("✅ Database health check passed")
        else:
            logger.warning("⚠️ Database pool not initialized")
    except Exception as e:
        logger.warning(f"Database health check failed: {e}")
    
    try:
        # Test RabbitMQ connection
        state_handler_manager = get_state_handler_manager()
        await state_handler_manager.initialize()
        queue_accessible = await state_handler_manager.health_check()
        await state_handler_manager.disconnect()
    except Exception as e:
        logger.warning(f"Message broker health check failed: {e}")
    
    overall_status = "healthy" if database_connected and queue_accessible else "degraded"
    
    return HealthResponse(
        status=overall_status,
        service="state-handler",
        timestamp=datetime.now(),
        version="1.0.0",
        database_connected=database_connected,
        queue_accessible=queue_accessible
    )

def validate_payload(data: dict):
    """Validate incoming message payload"""
    required_fields = ["transaction_folio", "operation_type", "status"]
    for field in required_fields:
        if field not in data:
            raise ValueError(f"Missing required field: {field}")

    for time_field in ["execution_start_time", "execution_end_time"]:
        if time_field in data and data[time_field]:
            try:
                datetime.fromisoformat(data[time_field].replace("Z", "+00:00"))
            except Exception:
                raise ValueError(f"Invalid timestamp format in field: {time_field}")

def convert_iso_to_datetime(iso_string: Any) -> Optional[datetime]:
    """Convert various datetime formats to datetime object for asyncpg strict type checking"""
    if not iso_string:
        return None
    
    # If it's already a datetime object, return as-is
    if isinstance(iso_string, datetime):
        return iso_string
    
    # If it's not a string, return None
    if not isinstance(iso_string, str):
        logger.warning(f"⚠️ Unexpected datetime type: {type(iso_string)} = {iso_string}")
        return None
    
    try:
        # Handle various ISO formats
        iso_str = iso_string.strip()
        
        # Handle microsecond precision (from microservices like "2025-09-13T01:22:07.442961")
        # First try direct fromisoformat parsing
        try:
            return datetime.fromisoformat(iso_str)
        except ValueError:
            pass
        
        # Remove 'Z' suffix and replace with +00:00
        if iso_str.endswith('Z'):
            iso_str = iso_str[:-1] + '+00:00'
            try:
                return datetime.fromisoformat(iso_str)
            except ValueError:
                pass
        
        # If no timezone, assume UTC
        if '+' not in iso_str and '-' not in iso_str[-6:] and 'T' in iso_str:
            iso_str = iso_str + '+00:00'
            try:
                return datetime.fromisoformat(iso_str)
            except ValueError:
                pass
        
        # Try manual parsing for microseconds format
        if 'T' in iso_str:
            # Split on T to get date and time parts
            date_part, time_part = iso_str.split('T', 1)
            
            # Remove timezone info for parsing
            clean_time = time_part.split('+')[0].split('-')[0].split('Z')[0]
            
            # Try different time formats
            time_formats = [
                '%H:%M:%S.%f',  # With microseconds
                '%H:%M:%S',     # Without microseconds
            ]
            
            for time_fmt in time_formats:
                try:
                    dt_str = f"{date_part}T{clean_time}"
                    return datetime.strptime(dt_str, f'%Y-%m-%dT{time_fmt}')
                except ValueError:
                    continue
        
        logger.warning(f"⚠️ Could not parse datetime '{iso_string}' with any known format")
        return None
        
    except Exception as e:
        logger.warning(f"⚠️ Could not parse datetime '{iso_string}': {e}")
        return None

async def batch_insert_messages(messages: List[Dict[str, Any]]) -> int:
    """Ultra-fast batch insert using asyncpg connection pool"""
    global db_pool
    
    if not messages:
        logger.info("📦 No messages to insert")
        return 0
    
    if not db_pool:
        logger.error("❌ Database pool not initialized")
        raise RuntimeError("Database pool not initialized")
    
    try:
        logger.info(f"🔄 Starting ultra-fast batch insert for {len(messages)} messages...")
        
        # Get connection from pool
        async with db_pool.acquire() as connection:
            logger.info("✅ Connection acquired from pool")
            
            # Prepare data for asyncpg executemany (much faster than individual inserts)
            records = []
            for msg in messages:
                # asyncpg handles JSON natively, no need for Json() wrapper
                payload_data = msg.get("payload")
                
                # Convert datetime strings to datetime objects for asyncpg
                start_time = convert_iso_to_datetime(msg.get("execution_start_time"))
                end_time = convert_iso_to_datetime(msg.get("execution_end_time"))
                
                records.append((
                    msg["transaction_folio"],
                    msg["operation_type"], 
                    msg.get("current_step"),
                    msg["status"],
                    json.dumps(payload_data) if payload_data is not None else None,  # Convert to JSON string
                    start_time,  # Convert to datetime object for asyncpg
                    end_time,    # Convert to datetime object for asyncpg
                    msg.get("execution_total_time"),
                    msg.get("response_code"),
                    msg.get("response_message")
                ))
            
            logger.info(f"🔄 Executing ultra-fast batch insert with {len(records)} records...")
            
            # Use asyncpg's COPY for ultra-fast bulk insert (bypasses type validation)
            # This is the fastest method and handles string->timestamp conversion automatically
            async with connection.transaction():
                await connection.copy_records_to_table(
                    'bt_transaction_executions',
                    schema_name='cloud',
                    records=records,
                    columns=[
                        'transaction_folio', 'operation_type', 'current_step', 
                        'status', 'payload', 'execution_start_time', 
                        'execution_end_time', 'execution_total_time',
                        'response_code', 'response_message'
                    ]
                )
                
            logger.info(f"✅ Ultra-fast batch inserted {len(messages)} messages via asyncpg pool")
            return len(messages)
            
    except Exception as e:
        logger.error(f"❌ Ultra-fast batch insert failed: {e}")
        import traceback
        logger.error(f"🔍 Batch insert error traceback: {traceback.format_exc()}")
        raise

async def initialize_db_pool() -> None:
    """Initialize high-performance asyncpg connection pool"""
    global db_pool
    try:
        secrets = config.get_secrets()
        
        # Create asyncpg connection pool with optimized settings
        db_pool = await asyncpg.create_pool(
            host=secrets["host"],
            port=int(secrets["port"]),
            database=secrets["dbname"],
            user=secrets["username"],
            password=secrets["password"],
            min_size=5,              # Minimum 5 connections always ready
            max_size=20,             # Maximum 20 concurrent connections
            command_timeout=3,       # Fast timeout for quick processing
            server_settings={
                'application_name': 'state-handler-service-asyncpg'
            }
        )
        
        logger.info("✅ High-performance asyncpg connection pool initialized (5-20 connections)")
        
    except Exception as e:
        logger.error(f"❌ Error creating asyncpg connection pool: {e}")
        raise

async def close_db_pool() -> None:
    """Close the database connection pool gracefully"""
    global db_pool
    if db_pool:
        await db_pool.close()
        logger.info("🔌 Database connection pool closed")
            
def get_db_connection(cfg: dict):
    """Create database connection via RDS Proxy (no local pooling needed)"""
    try:
        conn = psycopg2.connect(
            host=cfg["host"],
            port=cfg["port"],
            dbname=cfg["dbname"],
            user=cfg["username"],
            password=cfg["password"],
            connect_timeout=3,  # Fast timeout for quick processing
            application_name="state-handler-service"
        )
        return conn
    except Exception as e:
        logger.error(f"Error connecting to database: {e}")
        raise


# Global batch processing variables (optimized for ultra-high performance)
_message_batch = []
_batch_lock = asyncio.Lock()  # Initialize lock immediately to avoid race conditions
_batch_size = 2000  # Process 2000 messages at once (optimized for ultra-high performance with asyncpg)
_batch_timeout = 0.1  # Max 100ms to collect batch (ultra-high performance with uvloop)

def get_batch_lock():
    """Get the batch lock"""
    global _batch_lock
    return _batch_lock

async def handle_state_handler_message(message_body: Dict[str, Any]) -> None:
    """Handle a single state handler message from RabbitMQ"""
    try:
        # Log received message with full details
        transaction_folio = message_body.get('transaction_folio', message_body.get('transactionFolio', message_body.get('UUID', 'unknown')))
        operation = message_body.get('operation_type', message_body.get('operation', 'unknown'))
        status = message_body.get('status', 'unknown')
        
        logger.info(f"📥 State Handler Message: transaction_folio={transaction_folio}, operation_type={operation}, status={status}")
        logger.debug(f"📋 Full message body: {message_body}")
        
        # Validate payload
        logger.info("🔍 Validating payload...")
        validate_payload(message_body)
        logger.info("✅ Payload validation passed")
        
        # Check if this is an error message and forward to exception handler
        if message_body.get("status") == "error":
            logger.debug(f"🔄 Error message queued for exception handler: {message_body.get('transaction_folio', 'unknown')}")
            # Send to exception handler via manager
            state_handler_manager = get_state_handler_manager()
            await state_handler_manager.send_to_exception_handler(message_body, message_body.get("response_message", "No error message provided"))
        
        # Add to batch for processing
        try:
            await add_to_batch(message_body)
            logger.info(f"✅ State Handler queued: transaction_folio={transaction_folio}, operation_type={operation}")
        except Exception as batch_error:
            logger.error(f"❌ Error adding to batch: {batch_error}")
            import traceback
            logger.error(f"🔍 Batch add error traceback: {traceback.format_exc()}")
            # Fallback: process message individually
            logger.info("🔄 Fallback: processing message individually...")
            await process_single_message(message_body)
        
    except Exception as e:
        logger.error(f"❌ Error processing state handler message: {e}")
        logger.error(f"📋 Message that failed: {message_body}")
        import traceback
        logger.error(f"🔍 Traceback: {traceback.format_exc()}")

async def add_to_batch(message_body: Dict[str, Any]) -> None:
    """Add message to batch and process if batch is full"""
    global _message_batch, _batch_size
    
    logger.info("🔄 Entering add_to_batch...")
    batch_lock = get_batch_lock()
    logger.info("🔄 Got batch lock...")
    
    should_process = False
    
    async with batch_lock:
        logger.info("🔄 Inside batch lock...")
        _message_batch.append(message_body)
        logger.info(f"📦 Added to batch: {len(_message_batch)}/{_batch_size} messages")
        
        # Check if batch is full but DON'T process inside the lock to avoid deadlock
        if len(_message_batch) >= _batch_size:
            should_process = True
            logger.info(f"🚀 Batch is full ({_batch_size} messages), will process outside lock...")
    
    # Process OUTSIDE the lock to avoid deadlock
    if should_process:
        logger.info("🔄 Processing batch outside lock...")
        await process_batch()
    
    logger.info("🔄 Exited add_to_batch...")

async def process_batch() -> None:
    """Process the current batch of messages"""
    global _message_batch
    
    batch_lock = get_batch_lock()
    async with batch_lock:
        if not _message_batch:
            return  # Silent return for empty batch
            
        # Copy and clear the batch
        current_batch = _message_batch.copy()
        batch_size = len(current_batch)
        _message_batch.clear()
        logger.info(f"🔄 Processing batch of {batch_size} messages...")
    
    # Process the batch
    try:
        inserted_count = await batch_insert_messages(current_batch)
        logger.info(f"📝 Batch processed: {inserted_count} messages inserted")
    except Exception as e:
        logger.error(f"❌ Error processing batch: {e}")
        import traceback
        logger.error(f"🔍 Batch error traceback: {traceback.format_exc()}")
        # Re-add messages to batch for retry (optional)
        # async with batch_lock:
        #     _message_batch.extend(current_batch)

async def batch_timer() -> None:
    """Timer task to process remaining messages in batch after timeout"""
    global _batch_timeout
    
    while True:
        try:
            await asyncio.sleep(_batch_timeout)
            await process_batch()
        except asyncio.CancelledError:
            logger.info("🛑 Batch timer cancelled")
            break
        except Exception as e:
            logger.error(f"❌ Error in batch timer: {e}")

async def process_single_message(message_body: Dict[str, Any]) -> None:
    """Process a single message and insert it into the database"""
    try:
        logger.info("🔄 Starting database insert...")
        
        # Convert single message to batch format
        messages = [message_body]
        logger.info(f"📦 Prepared {len(messages)} message(s) for insert")
        
        # Insert into database
        logger.info("🔄 Calling batch_insert_messages...")
        inserted_count = await batch_insert_messages(messages)
        logger.info(f"📝 batch_insert_messages returned: {inserted_count}")
        
        if inserted_count > 0:
            logger.info(f"✅ Database insert successful: {inserted_count} message(s)")
        else:
            logger.warning("⚠️ No messages were inserted into database")
            
    except Exception as e:
        logger.error(f"❌ Error processing single message: {e}")
        import traceback
        logger.error(f"🔍 Single message error traceback: {traceback.format_exc()}")
        raise

async def process_messages():
    """Main message processing loop with RabbitMQ"""
    try:
        # Initialize state handler manager
        state_handler_manager = get_state_handler_manager()
        await state_handler_manager.initialize()
        
        logger.info("✅ RabbitMQ mode: Direct messaging enabled")
        
        # Start consuming from RabbitMQ
        await state_handler_manager.start_consuming(handle_state_handler_message)
        logger.info("🔄 Started consuming messages from RabbitMQ")
        
        # Start batch timer task for high-load processing
        batch_timer_task = asyncio.create_task(batch_timer())
        logger.info("🔄 Batch timer started for high-load processing")
        
        # Keep running (RabbitMQ handles the message loop)
        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            logger.info("🛑 Shutting down...")
            batch_timer_task.cancel()
            await state_handler_manager.disconnect()
            
    except Exception as e:
        logger.error(f"Fatal error in process_messages: {e}")
        raise

def run_fastapi():
    """Run FastAPI server in a separate thread"""
    uvicorn.run(app, host="0.0.0.0", port=config.PORT, log_level="info")

async def main():
    """Main function to run both FastAPI and message processing with high-performance optimizations"""
    try:
        # Initialize high-performance database connection pool
        logger.info("🚀 Initializing high-performance database connection pool...")
        await initialize_db_pool()
        
        # Start FastAPI in a separate thread
        fastapi_thread = threading.Thread(target=run_fastapi, daemon=True)
        fastapi_thread.start()
        
        logger.info(f"Health endpoint available at http://0.0.0.0:{config.PORT}/health")
        
        # Start message processing
        await process_messages()
        
    except Exception as e:
        logger.error(f"Fatal error in main: {e}")
        raise
    finally:
        # Ensure clean shutdown of database pool
        logger.info("🔄 Shutting down database connection pool...")
        await close_db_pool()

if __name__ == "__main__":
    try:
        # Configure uvloop for ultra-high performance async I/O (2-4x faster)
        logger.info("🚀 Configuring uvloop for ultra-high performance...")
        asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
        logger.info("✅ uvloop configured - async operations will be 2-4x faster")
        
        # Run main application with high-performance event loop
        asyncio.run(main())
        
    except KeyboardInterrupt:
        logger.info("🛑 Graceful shutdown initiated...")
    except Exception as e:
        logger.error(f"❌ Application error: {e}")
        sys.exit(1)