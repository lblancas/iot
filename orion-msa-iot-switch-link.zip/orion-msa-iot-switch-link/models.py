"""
Pydantic models for Switch-Link microservice
"""

from pydantic import BaseModel
from datetime import datetime
from typing import Dict, Any, Optional

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str
    service: str
    timestamp: datetime
    version: str

class StateHandlerMessage(BaseModel):
    """State handler message model"""
    transaction_folio: str
    operation_type: str
    current_step: str
    status: str
    payload: Dict[str, Any]
    execution_start_time: datetime
    execution_end_time: datetime
    execution_total_time: str
    response_code: str
    response_message: str

class SwitchLinkRequest(BaseModel):
    """Switch-link request model"""
    UUID: Optional[str] = None
    transaction_folio: Optional[str] = None
    StateID: str
    code: str
    endpoint_type: Optional[str] = None
    dataTransaction: Optional[Dict[str, Any]] = None

class SwitchLinkResponse(BaseModel):
    """Switch-link response model"""
    stateId: str
    UUID: Optional[str] = None
    transaction_folio: Optional[str] = None
    code: str
    success: bool
    response_code: str
    response_message: str
    dataTransaction: Optional[Dict[str, Any]] = None