#!/usr/bin/env python3
"""
Switch-Link Microservice
Optimized simulator for cardPresent=false transactions using JSON templates
High-performance hybrid boto3/aiobotocore implementation
"""

import os
import sys
import json
import asyncio
import logging
import threading
from datetime import datetime
from typing import Dict, Any, Optional
from collections import deque
import boto3
from botocore.exceptions import ClientError
from fastapi import FastAPI
import uvicorn

from config import config
from models import HealthResponse, StateHandlerMessage  # This imports from models.py file
from templates.template_engine import TemplateEngine
from performance_config import PerformanceConfig
from switchlink_manager import get_switchlink_manager

# Configure logging with timestamps
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger("orion-switch-link")

# FastAPI app for health endpoint
app = FastAPI(title="Switch-Link Microservice", version="1.0.0")

# Template engine for dynamic responses
template_engine = TemplateEngine()

# Track processed messages to prevent duplicates - using deque with maxlen for automatic cleanup
processed_messages = deque(maxlen=1000)  # Automatically removes oldest when full

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        service="switch-link", 
        timestamp=datetime.now(),
        version="1.0.0"
    )

def generate_response(request_body: Dict[str, Any]) -> Dict[str, Any]:
    """Generate response using template engine"""
    try:
        response = template_engine.generate_response(request_body)
        if response:
            return response
        
        # Fallback simple response if template not found
        return {
            "stateId": "response",
            "transactionFolio": request_body.get("UUID") or request_body.get("transactionFolio"),
            "endpointType": "transaction",
            "code": str(request_body.get("code", "unknown")),
            "success": True,
            "response_code": "00",
            "response_message": "Processed by switch-link simulator"
        }
        
    except Exception as e:
        logger.error(f"❌ Error generating response: {e}")
        # Fallback simple response
        return {
            "stateId": "response",
            "transactionFolio": request_body.get("UUID") or request_body.get("transactionFolio"),
            "endpointType": "transaction",
            "code": str(request_body.get("code", "unknown")),
            "success": True,
            "response_code": "00",
            "response_message": "Processed by switch-link simulator"
        }

async def send_to_state_handler_sync(sqs_client, state_handler_url: str, transaction_folio: str, 
                                   code: str, state_id: str, payload: Dict[str, Any], 
                                   execution_start: datetime, status: str, response_code: str, 
                                   response_message: str):
    """Send to state handler using sync boto3 for maximum speed"""
    try:
        # Use sync boto3 for fastest response times
        execution_end = datetime.now()
        total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
        
        operation_type = f"{code}-{state_id}"
        
        state_msg = StateHandlerMessage(
            transaction_folio=transaction_folio,
            operation_type=operation_type,
            current_step="switch-link",
            status=status,
            payload=payload,
            execution_start_time=execution_start,
            execution_end_time=execution_end,
            execution_total_time=str(int(total_execution_ms)),
            response_code=response_code,
            response_message=response_message
        )
        
        state_handler_payload = state_msg.model_dump_json()
        sqs_client.send_message(
            QueueUrl=state_handler_url, 
            MessageBody=state_handler_payload
        )
        
        logger.info("📤 SQS Sent to state_handler queue")
        logger.info(f"⏱️ Execution time: {total_execution_ms:.2f}ms")
        
    except Exception as e:
        logger.error(f"Error sending to state_handler: {e}")

async def handle_switchlink_message(message_body: Dict[str, Any]) -> None:
    """Handle a single switch-link message from RabbitMQ"""
    
    # Capture start time when message is received
    execution_start = datetime.now()
    
    try:
        # Extract required fields
        uuid = message_body.get("UUID") or message_body.get("transactionFolio")
        state_id = message_body.get("stateId")
        code = message_body.get("code")
        
        # Create unique message ID for deduplication
        message_id = f"{uuid}_{state_id}_{code}_{message_body.get('wsNo')}_{message_body.get('siteId')}"
        
        logger.info(f"📥 Switch-Link Request: code={code}, wsNo={message_body.get('wsNo')}, siteId={message_body.get('siteId')}, folio={uuid}")

        # Check for duplicate messages (O(n) but with maxlen=1000 is acceptable)
        if message_id in processed_messages:
            logger.warning(f"⚠️ DUPLICATE MESSAGE DETECTED: {message_id} - Ignoring")
            return
        
        # Mark message as processed (automatic cleanup when deque is full)
        processed_messages.append(message_id)

        if state_id == "request":
            try:
                # Generate response using template engine
                response_data = generate_response(message_body)
                
                # Send response back to workflow via switchlink_manager
                switchlink_manager = get_switchlink_manager()
                logger.info(f"🔄 Sending response to WORKFLOW: folio={uuid}")
                await switchlink_manager.send_to_workflow(response_data)
                logger.info(f"✅ Response sent successfully: {uuid}")
                
                # Capture end time and calculate execution time
                execution_end = datetime.now()
                total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
                
                # Send success state to state_handler via switchlink_manager
                await send_to_state_handler_rabbitmq(
                    uuid, code, "request", message_body, 
                    execution_start, "success", "200", "Switch-Link response generated successfully"
                )
                
                logger.info(f"⏱️ Execution time: {total_execution_ms:.2f}ms")
                
            except Exception as e:
                # Handle errors
                execution_end = datetime.now()
                total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
                
                # Send error to state_handler
                await send_to_state_handler_rabbitmq(
                    uuid, code, "request", message_body, 
                    execution_start, "error", "500", f"Switch-Link error: {str(e)}"
                )
                
                logger.error(f"❌ Switch-Link error for {uuid}: {e}")
        else:
            logger.warning(f"⚠️ Invalid message: stateId={state_id}")
                
    except Exception as e:
        logger.error(f"❌ Error processing switch-link message: {e}")

async def send_to_state_handler_rabbitmq(transaction_folio: str, code: str, state_id: str, 
                                        payload: Dict[str, Any], execution_start: datetime, 
                                        status: str, response_code: str, response_message: str):
    """Send message to state_handler using switchlink manager (RabbitMQ preferred)"""
    
    try:
        # Capture end time and calculate execution time
        execution_end = datetime.now()
        total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
        
        # Build operation_type like other services
        operation_type = f"{code}-{state_id}"
        
        # Create state handler payload (simplified for RabbitMQ)
        state_handler_payload = {
            "transaction_folio": transaction_folio,
            "operation_type": operation_type,
            "current_step": "switch-link",
            "status": status,
            "payload": payload,
            "execution_start_time": execution_start.isoformat(),
            "execution_end_time": execution_end.isoformat(),
            "execution_total_time": str(int(total_execution_ms)),
            "response_code": response_code,
            "response_message": response_message
        }
        
        # Send using switchlink manager (will use RabbitMQ or SQS based on broker_type)
        switchlink_manager = get_switchlink_manager()
        await switchlink_manager.send_to_state_handler(state_handler_payload)
        
        logger.info(f"📤 Sent to state_handler: {transaction_folio}, {operation_type}, {status}, {total_execution_ms:.1f}ms")
        
    except Exception as e:
        logger.error(f"Error sending to state_handler: {e}")

async def process_messages():
    """Message processing with RabbitMQ support"""
    try:
        # Initialize switchlink manager
        switchlink_manager = get_switchlink_manager()
        await switchlink_manager.initialize()
        logger.info("✅ Switch-Link manager initialized")
        
        # Get configuration
        secrets = config.get_secrets()
        broker_mode = secrets.get("message_broker", "rabbitmq")
        logger.info(f"🔧 Switch-Link running in {broker_mode.upper()} mode")
        
        # Only use RabbitMQ mode
        if broker_mode.lower() != "rabbitmq":
            raise ValueError(f"Unsupported broker mode: {broker_mode}")
            
        logger.info("🚀 Starting message processing loop...")
        logger.info(PerformanceConfig.log_configuration())
        
        # Template engine is ready
        logger.info("✅ Template engine initialized")

        # RabbitMQ mode - start consuming messages
        # Create async wrapper for handle_switchlink_message
        async def message_wrapper(message: Dict[str, Any]) -> None:
            await handle_switchlink_message(message)
        
        logger.info("🔄 Starting RabbitMQ message consumption...")
        await switchlink_manager.start_consuming(message_wrapper)
        logger.info("✅ RabbitMQ mode: Started consuming switch-link messages")
        
        # Keep running (RabbitMQ handles the message loop)
        while True:
            await asyncio.sleep(1)
            
    except Exception as e:
        logger.error(f"Fatal error in process_messages: {e}")
        raise

def run_fastapi():
    """Run FastAPI server in a separate thread"""
    uvicorn.run(app, host="0.0.0.0", port=config.PORT, log_level="info")

async def main():
    """Main function to run both FastAPI and message processing"""
    # Start FastAPI in a separate thread
    fastapi_thread = threading.Thread(target=run_fastapi, daemon=True)
    fastapi_thread.start()
    
    logger.info(f"Health endpoint available at http://0.0.0.0:{config.PORT}/health")
    
    # Start message processing
    await process_messages()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    except Exception as e:
        logger.error(f"Application error: {e}")
        sys.exit(1)