#!/usr/bin/env python3
"""
RabbitMQ Switch-Link Client
Handles message consumption and publishing for Switch-Link service
"""

import asyncio
import json
import logging
import uuid
import os
from datetime import datetime
from typing import Dict, Any, Optional, Callable

# Import our RabbitMQ client (now local to switch-link service)
from rabbitmq_client import RabbitMQClient, RabbitMQConfig

logger = logging.getLogger(__name__)

class SwitchLinkRabbitMQClient:
    """RabbitMQ client specifically designed for Switch-Link service"""
    
    def __init__(self, rabbitmq_host: str, environment: str = "dev"):
        self.config = RabbitMQConfig(
            host=rabbitmq_host,
            environment=environment
        )
        self.client = RabbitMQClient(self.config)
        self._consuming = False
        self._consumer_task: Optional[asyncio.Task] = None
        
    async def initialize(self) -> None:
        """Initialize connection and setup switch-link queue"""
        try:
            # Connect to RabbitMQ
            await self.client.connect()
            
            # Declare switch-link queue
            switch_link_queue = await self.client.declare_queue("switch-link")
            
            # Declare DLQ for switch-link
            dlq_name = f"sps-{self.config.environment}-orion-dlq-switch-link"
            dlq_queue = await self.client._channel.declare_queue(
                dlq_name,
                durable=True,
                arguments={"x-queue-type": "classic"}
            )
            
            # Bind DLQ to DLX exchange
            dlx_exchange = await self.client._channel.get_exchange(self.config.get_dlx_name())
            await dlq_queue.bind(dlx_exchange, "switch-link")
            
            # Bind switch-link queue to receive messages from workflow
            await self.client.bind_queue_to_topic(
                queue=switch_link_queue,
                routing_key="orion.switch-link.request"
            )
            
            logger.info("✅ Switch-Link RabbitMQ client initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Switch-Link RabbitMQ client: {e}")
            raise
    
    async def start_consuming(self, message_handler: Callable[[Dict[str, Any]], None]) -> None:
        """Start consuming messages from switch-link queue"""
        try:
            logger.info("🔄 About to start consuming messages...")
            await self.client.consume_messages("switch-link", message_handler)
            self._consuming = True
            logger.info("🔄 Started consuming switch-link messages")
            
        except Exception as e:
            logger.error(f"❌ Failed to start switch-link consumer: {e}")
            raise
    
    async def send_to_workflow(self, payload: Dict[str, Any]) -> None:
        """Send response message back to workflow"""
        try:
            await self.client.publish_message(
                routing_key="orion.workflow.response",
                message=payload
            )
            logger.info(f"📤 Sent response to workflow: {payload.get('transactionFolio') or payload.get('UUID', 'unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to workflow: {e}")
            raise
    
    async def send_to_state_handler(self, payload: Dict[str, Any]) -> None:
        """Send message to state handler service"""
        try:
            await self.client.publish_message(
                routing_key="orion.state-handler.update",
                message=payload
            )
            logger.info(f"📤 Sent message to state handler: {payload.get('transaction_folio', 'unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to state handler: {e}")
            raise
    
    async def health_check(self) -> bool:
        """Check if RabbitMQ connection is healthy"""
        try:
            return await self.client.health_check()
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def disconnect(self) -> None:
        """Close RabbitMQ connection"""
        try:
            # Stop consuming
            if self._consuming:
                await self.client.stop_consuming("switch-link")
                self._consuming = False
            
            # Cancel consumer task
            if self._consumer_task and not self._consumer_task.done():
                self._consumer_task.cancel()
                try:
                    await self._consumer_task
                except asyncio.CancelledError:
                    pass
            
            # Disconnect client
            await self.client.disconnect()
            
            logger.info("🔌 Switch-Link RabbitMQ client disconnected")
            
        except Exception as e:
            logger.error(f"Error disconnecting Switch-Link client: {e}")

# Factory function for easier integration
def create_switchlink_rabbitmq_client(rabbitmq_host: str, environment: str = "dev") -> SwitchLinkRabbitMQClient:
    """Create and return Switch-Link RabbitMQ client"""
    return SwitchLinkRabbitMQClient(rabbitmq_host, environment)