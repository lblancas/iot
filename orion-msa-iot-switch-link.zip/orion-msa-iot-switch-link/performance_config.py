"""
Performance Configuration for Switch-Link Microservice
Centralized configuration for performance parameters
"""

import os

class PerformanceConfig:
    """Performance configuration for switch-link microservice"""
    
    # SQS Configuration - Optimized for low latency
    SQS_LONG_POLLING_SECONDS = int(os.getenv("SQS_LONG_POLLING_SECONDS", "1"))  # Reduced to 5s for low latency
    SQS_MAX_MESSAGES = int(os.getenv("SQS_MAX_MESSAGES", "10"))
    SQS_VISIBILITY_TIMEOUT = int(os.getenv("SQS_VISIBILITY_TIMEOUT", "30"))
    SQS_CONNECT_TIMEOUT = int(os.getenv("SQS_CONNECT_TIMEOUT", "5"))
    SQS_READ_TIMEOUT = int(os.getenv("SQS_READ_TIMEOUT", "30"))
    SQS_MAX_RETRIES = int(os.getenv("SQS_MAX_RETRIES", "3"))
    
    # Logging Configuration
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    
    @classmethod
    def get_sqs_config(cls):
        """Get SQS client configuration"""
        return {
            "connect_timeout": cls.SQS_CONNECT_TIMEOUT,
            "read_timeout": cls.SQS_READ_TIMEOUT,
            "retries": {"max_attempts": cls.SQS_MAX_RETRIES}
        }
    
    @classmethod
    def log_configuration(cls):
        """Log current performance configuration"""
        return f"""
🔧 Switch-Link Performance Configuration:
   SQS Long Polling: {cls.SQS_LONG_POLLING_SECONDS}s
   SQS Max Messages: {cls.SQS_MAX_MESSAGES}
   SQS Visibility Timeout: {cls.SQS_VISIBILITY_TIMEOUT}s
   SQS Connect Timeout: {cls.SQS_CONNECT_TIMEOUT}s
   SQS Read Timeout: {cls.SQS_READ_TIMEOUT}s
   SQS Max Retries: {cls.SQS_MAX_RETRIES}
   Log Level: {cls.LOG_LEVEL}
        """.strip()
