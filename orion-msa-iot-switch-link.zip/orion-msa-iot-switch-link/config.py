"""
Configuration management for Switch-Link microservice
"""

import os
import json
import boto3
import logging
from typing import Dict, Any
from pydantic import BaseModel
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

class BaseConfig(BaseModel):
    """Base configuration model"""
    class Config:
        extra = "allow"
    
    # Environment
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "local")
    AWS_REGION: str = os.getenv("AWS_REGION", "us-east-1")
    
    # Service configuration
    PORT: int = int(os.getenv("PORT", "40032"))
    
    # AWS Secrets Manager  
    SECRETS_MANAGER_SECRET_NAME: str = os.getenv("SECRETS_MANAGER_SECRET_NAME", "sps-dev-orion-secret-iot-switch-link")
    AWS_SECRET_NAME: str = os.getenv("AWS_SECRET_NAME", "sps-dev-orion-secret-iot-switch-link")
    
    # SQS Configuration (for local environment)
    SWITCH_LINK_QUEUE_URL: str = os.getenv("SWITCH_LINK_QUEUE_URL", "")
    WORKFLOW_QUEUE_URL: str = os.getenv("WORKFLOW_QUEUE_URL", "")
    STATE_HANDLER_QUEUE_URL: str = os.getenv("STATE_HANDLER_QUEUE_URL", "")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._secrets_cache = None

    def get_secrets(self) -> Dict[str, Any]:
        """Get configuration from AWS Secrets Manager or environment variables"""
        if self._secrets_cache is not None:
            return self._secrets_cache

        if self.ENVIRONMENT == "local":
            # Use environment variables for local development
            self._secrets_cache = {
                "switch_link_queue": self.SWITCH_LINK_QUEUE_URL,
                "workflow_queue": self.WORKFLOW_QUEUE_URL,
                "state_handler_queue": self.STATE_HANDLER_QUEUE_URL
            }
        else:
            # Use AWS Secrets Manager for cloud environments
            try:
                session = boto3.session.Session()
                client = session.client(
                    service_name="secretsmanager", 
                    region_name=self.AWS_REGION
                )
                
                response = client.get_secret_value(SecretId=self.AWS_SECRET_NAME)
                self._secrets_cache = json.loads(response["SecretString"])
                
                logger.info(f"Successfully loaded secrets from {self.AWS_SECRET_NAME}")
                logger.info(f"Secret keys available: {list(self._secrets_cache.keys())}")
                logger.info(f"Looking for key 'switch_link_queue': {'switch_link_queue' in self._secrets_cache}")
                if 'switch_link_queue' in self._secrets_cache:
                    logger.info(f"switch_link_queue value: {self._secrets_cache['switch_link_queue']}")
                
            except ClientError as e:
                logger.error(f"Error retrieving secrets from {self.AWS_SECRET_NAME}: {e}")
                raise e
            except Exception as e:
                logger.error(f"Unexpected error loading secrets: {e}")
                raise e

        return self._secrets_cache

# Global configuration instance
config = BaseConfig()