"""
Models package for Switch-Link Microservice
Contains response templates and data models
"""
