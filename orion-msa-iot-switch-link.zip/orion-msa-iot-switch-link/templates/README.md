# Switch-Link Template Engine

Este directorio contiene el motor de plantillas para el microservicio Switch-Link, que genera respuestas dinámicas basadas en el código de transacción recibido.

## Estructura de Directorios

```
templates/
├── __init__.py
├── README.md
├── template_engine.py
└── response_templates/
    ├── default.json          # Template por defecto
    ├── 0002.json             # Template para código 0002
    ├── 1001.json             # Template para código 1001
    ├── 1004.json             # Template para código 1004
    ├── 1005.json             # Template para código 1005
    └── 9501.json             # Template para código 9501
```

## Funcionalidad

El motor de plantillas permite:

- **Respuestas dinámicas** basadas en el código de transacción
- **Sustitución de variables** en tiempo real
- **Formateo de fechas** y timestamps
- **Fallback automático** al template por defecto

## Uso

```python
from templates.template_engine import TemplateEngine

# Inicializar el motor
engine = TemplateEngine()

# Generar respuesta
request = {
    "code": "1001",
    "UUID": "12345",
    "dataTransaction": {
        "transAmount": "100.00",
        "transCurrency": "484"
    }
}

response = engine.generate_response(request)
```

## Variables Disponibles

### Variables Principales
- `[code]` - Código de transacción
- `[UUID]` - Identificador único
- `[transactionFolio]` - Folio de transacción
- `[stateId]` - ID del estado
- `[endpointType]` - Tipo de endpoint
- `[siteId]` - ID del sitio
- `[wsNo]` - Número de workstation
- `[posInfo]` - Información del POS
- `[sequenceNo]` - Número de secuencia
- `[thingId]` - ID del dispositivo IoT

### Variables de Transacción
- `[dataTransaction.transAmount]` - Monto de la transacción
- `[dataTransaction.transCurrency]` - Moneda de la transacción
- `[dataTransaction.tipAmount]` - Propina
- `[dataTransaction.cardPresent]` - Tarjeta presente

### Variables de Tiempo
- `[timestamp:iso]` - Timestamp en formato ISO
- `[timestamp:date:DDMMYY]` - Fecha en formato DDMMYY
- `[timestamp:time:HHMMSS]` - Hora en formato HHMMSS

## Ejemplo de Request

```json
{
  "code": "1001",
  "UUID": "6fd43f40-dbdd-4234-9f61-72baa22ccbc9",
  "transactionFolio": "6fd43f40-dbdd-4234-9f61-72baa22ccbc9",
  "stateId": "request",
  "endpointType": "transaction",
  "siteId": "comercio|suc001",
  "wsNo": "POS000002",
  "posInfo": "POS-01",
  "sequenceNo": "87654321",
  "thingId": "dev_73e1e45a-9fa1-48b9-b108-4dac3db04e80_1080",
  "dataTransaction": {
    "transAmount": "500.00",
    "tipAmount": "0.00",
    "tipOnPinpad": "true",
    "promoOnPinpad": "true",
    "transCurrency": "484",
    "cardPresent": "false"
  }
}
```

### Template 1001.json:

```json
{
  "code": "[code]",
  "stateId": "response",
  "endpointType": "[endpointType]",
  "transactionFolio": "[transactionFolio]",
  "siteId": "[siteId]",
  "wsNo": "[wsNo]",
  "posInfo": "[posInfo]",
  "sequenceNo": "[sequenceNo]",
  "thingId": "[thingId]",
  "dataCommand": {
    "responseCode": "00",
    "responseMessage": "Aprobada",
    "amount": "[dataTransaction.transAmount]",
    "currencyCode": "[dataTransaction.transCurrency]",
    "txnDate": "[timestamp:date:DDMMYY]",
    "txnTime": "[timestamp:time:HHMMSS]"
  },
  "status": "SUCCESS",
  "responseCode": 200,
  "responseMessage": "Successful transaction",
  "timestamp": "[timestamp:iso]"
}
```

### Template 1004.json:

```json
{
  "code": "[code]",
  "stateId": "response",
  "endpointType": "[endpointType]",
  "transactionFolio": "[transactionFolio]",
  "siteId": "[siteId]",
  "wsNo": "[wsNo]",
  "posInfo": "[posInfo]",
  "sequenceNo": "[sequenceNo]",
  "thingId": "[thingId]",
  "dataCommand": {
    "responseCode": "00",
    "responseMessage": "Aprobada",
    "posId": "POSCFE11",
    "tag9b": "0000",
    "tag9f26": "D7D272C26AC18CB4",
    "sgReferenceFolio": "252230520793",
    "cardType": "1",
    "mnemoName": "Vi",
    "terminalId": "POSCFE11",
    "appLabel": "VISA DEBITO",
    "tag50": "VISA DEBITO",
    "tag95": "0000000000",
    "currencyCode": "[dataTransaction.transCurrency]",
    "cardHolderName": "PAYWAVE/VISA",
    "billable": "true",
    "amount": "[dataTransaction.transAmount]",
    "preferredName": "VISA DEBITO",
    "appVersion": "2.0.1.0.ag",
    "accountNumber": "4189143011229518",
    "aid": "A0000000031010",
    "signatureFlag": "1",
    "arqc": "D7D272C26AC18CB4",
    "txnName": "VENTA EN LINEA",
    "serviceName": "BBVA_8D_NEW",
    "txnTime": "[timestamp:time:HHMMSS]",
    "tag9f12": "VISA DEBITO",
    "txnApprovalCode": "SBT8C1",
    "tag9f34": "1E0000",
    "cardName": "Visa",
    "statusFlagTxn": "2",
    "transactionType": "1",
    "tsn": "[timestamp:time:HHMMSS]",
    "expirationDate": "2512",
    "entryMode": "07",
    "brandName": "VISA",
    "tag5f2a": "0484",
    "txnDate": "[timestamp:date:DDMMYY]",
    "controles": "{\"data\":[]}",
    "sgReference": "000038053465",
    "bankName": "BBVA",
    "merchantId": "123456"
  },
  "status": "SUCCESS",
  "responseCode": 200,
  "responseMessage": "Successful transaction",
  "timestamp": "[timestamp:iso]"
}
```

### Template 1005.json:

```json
{
  "code": "[code]",
  "stateId": "response",
  "endpointType": "[endpointType]",
  "transactionFolio": "[transactionFolio]",
  "siteId": "[siteId]",
  "wsNo": "[wsNo]",
  "posInfo": "[posInfo]",
  "sequenceNo": "[sequenceNo]",
  "thingId": "[thingId]",
  "dataCommand": {
    "responseCode": "00",
    "responseMessage": "Aprobada",
    "posId": "POSCFE11",
    "tag9b": "0000",
    "tag9f26": "D7D272C26AC18CB4",
    "sgReferenceFolio": "252230520793",
    "cardType": "1",
    "mnemoName": "Vi",
    "terminalId": "POSCFE11",
    "appLabel": "VISA DEBITO",
    "tag50": "VISA DEBITO",
    "tag95": "0000000000",
    "currencyCode": "[dataTransaction.transCurrency]",
    "cardHolderName": "PAYWAVE/VISA",
    "billable": "true",
    "amount": "[dataTransaction.transAmount]",
    "preferredName": "VISA DEBITO",
    "appVersion": "2.0.1.0.ag",
    "accountNumber": "4189143011229518",
    "aid": "A0000000031010",
    "signatureFlag": "1",
    "arqc": "D7D272C26AC18CB4",
    "txnName": "VENTA EN LINEA",
    "serviceName": "BBVA_8D_NEW",
    "txnTime": "[timestamp:time:HHMMSS]",
    "tag9f12": "VISA DEBITO",
    "txnApprovalCode": "SBT8C1",
    "tag9f34": "1E0000",
    "cardName": "Visa",
    "statusFlagTxn": "2",
    "transactionType": "1",
    "tsn": "[timestamp:time:HHMMSS]",
    "expirationDate": "2512",
    "entryMode": "07",
    "brandName": "VISA",
    "tag5f2a": "0484",
    "txnDate": "[timestamp:date:DDMMYY]",
    "controles": "{\"data\":[]}",
    "sgReference": "000038053465",
    "bankName": "BBVA",
    "merchantId": "123456"
  },
  "status": "SUCCESS",
  "responseCode": 200,
  "responseMessage": "Successful transaction",
  "timestamp": "[timestamp:iso]"
}
```

### Template 0002.json:

```json
{
  "code": "[code]",
  "stateId": "response",
  "endpointType": "[endpointType]",
  "transactionFolio": "[transactionFolio]",
  "siteId": "[siteId]",
  "wsNo": "[wsNo]",
  "posInfo": "[posInfo]",
  "sequenceNo": "[sequenceNo]",
  "thingId": "[thingId]",
  "dataCommand": {
    "responseCode": "00",
    "responseMessage": "Aprobada",
    "posId": "POSCFE11",
    "tag9b": "0000",
    "tag9f26": "D7D272C26AC18CB4",
    "sgReferenceFolio": "252230520793",
    "cardType": "1",
    "mnemoName": "Vi",
    "terminalId": "POSCFE11",
    "appLabel": "VISA DEBITO",
    "tag50": "VISA DEBITO",
    "tag95": "0000000000",
    "currencyCode": "[dataTransaction.transCurrency]",
    "cardHolderName": "PAYWAVE/VISA",
    "billable": "true",
    "amount": "[dataTransaction.transAmount]",
    "preferredName": "VISA DEBITO",
    "appVersion": "2.0.1.0.ag",
    "accountNumber": "4189143011229518",
    "aid": "A0000000031010",
    "signatureFlag": "1",
    "arqc": "D7D272C26AC18CB4",
    "txnName": "VENTA EN LINEA",
    "serviceName": "BBVA_8D_NEW",
    "txnTime": "[timestamp:time:HHMMSS]",
    "tag9f12": "VISA DEBITO",
    "txnApprovalCode": "SBT8C1",
    "tag9f34": "1E0000",
    "cardName": "Visa",
    "statusFlagTxn": "2",
    "transactionType": "1",
    "tsn": "[timestamp:time:HHMMSS]",
    "expirationDate": "2512",
    "entryMode": "07",
    "brandName": "VISA",
    "tag5f2a": "0484",
    "txnDate": "[timestamp:date:DDMMYY]",
    "controles": "{\"data\":[]}",
    "sgReference": "000038053465",
    "bankName": "BBVA",
    "merchantId": "123456"
  },
  "status": "SUCCESS",
  "responseCode": 200,
  "responseMessage": "Successful transaction",
  "timestamp": "[timestamp:iso]"
}
```

## Configuración

El motor de plantillas se configura automáticamente al inicializarse y carga todos los templates disponibles en el directorio `response_templates/`.

## Testing

Para probar el motor de plantillas:

```bash
python3 test_template_engine.py
```

Esto ejecutará una serie de pruebas para verificar:
- Carga correcta de templates
- Generación de respuestas
- Sustitución de variables
- Formateo de timestamps
