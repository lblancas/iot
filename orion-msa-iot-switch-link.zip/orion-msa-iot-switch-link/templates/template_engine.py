"""
Template Engine for Switch-Link Microservice
Processes JSON templates with field echoing and timestamp formatting
"""

import json
import os
import re
from datetime import datetime
from typing import Dict, Any, Optional
from collections import OrderedDict

class TemplateEngine:
    """Engine to process JSON templates with dynamic field replacement"""
    
    def __init__(self, templates_dir: str = "templates/response_templates", max_cache_size: int = 50):
        self.templates_dir = templates_dir
        self.template_cache = OrderedDict()  # LRU cache
        self.max_cache_size = max_cache_size
    
    def load_template(self, code: str, amount: str = None) -> Optional[Dict[str, Any]]:
        """Load template for specific code and amount from JSON file"""
        cache_key = f"{code}-{amount}" if amount else code
        
        if cache_key in self.template_cache:
            # Move to end (most recently used)
            self.template_cache.move_to_end(cache_key)
            return self.template_cache[cache_key]
        
        # Try to load specific code-amount template
        if amount:
            template_path = os.path.join(self.templates_dir, code, f"{amount}.json")
            if os.path.exists(template_path):
                try:
                    with open(template_path, 'r', encoding='utf-8') as f:
                        template = json.load(f)
                        self._add_to_cache(cache_key, template)
                        return template
                except Exception as e:
                    print(f"Error loading template for code {code}, amount {amount}: {e}")
        
        # If amount-specific template not found, fallback to approved.json for unknown amounts
        if amount:
            approved_path = os.path.join(self.templates_dir, code, "approved.json")
            if os.path.exists(approved_path):
                try:
                    with open(approved_path, 'r', encoding='utf-8') as f:
                        template = json.load(f)
                        self._add_to_cache(cache_key, template)
                        return template
                except Exception as e:
                    print(f"Error loading approved template for code {code}: {e}")
        
        # Try to load specific code template (fallback)
        template_path = os.path.join(self.templates_dir, f"{code}.json")
        if os.path.exists(template_path):
            try:
                with open(template_path, 'r', encoding='utf-8') as f:
                    template = json.load(f)
                    self._add_to_cache(cache_key, template)
                    return template
            except Exception as e:
                print(f"Error loading template for code {code}: {e}")
        
        # Final fallback to default template
        default_path = os.path.join(self.templates_dir, "default.json")
        if os.path.exists(default_path):
            try:
                with open(default_path, 'r', encoding='utf-8') as f:
                    template = json.load(f)
                    self._add_to_cache(cache_key, template)
                    return template
            except Exception as e:
                print(f"Error loading default template: {e}")
        
        return None
    
    def _add_to_cache(self, cache_key: str, template: Dict[str, Any]) -> None:
        """Add template to LRU cache with size limit"""
        if cache_key in self.template_cache:
            self.template_cache.move_to_end(cache_key)
        else:
            self.template_cache[cache_key] = template
            # Remove oldest if cache is full
            if len(self.template_cache) > self.max_cache_size:
                self.template_cache.popitem(last=False)  # Remove oldest
    
    def process_template(self, template: Dict[str, Any], request_body: Dict[str, Any]) -> Dict[str, Any]:
        """Process template with field echoing and timestamp formatting"""
        # Convert template to string for processing
        template_str = json.dumps(template)
        
        # Process field echoing
        processed_str = self._process_field_echoing(template_str, request_body)
        
        # Process timestamp formatting
        processed_str = self._process_timestamps(processed_str)
        
        # Convert back to dict
        return json.loads(processed_str)
    
    def _process_field_echoing(self, template_str: str, request_body: Dict[str, Any]) -> str:
        """Process field echoing patterns like [field] or [nested.field]"""
        
        def replace_field(match):
            field_path = match.group(1)
            
            # Skip timestamp patterns - they will be processed separately
            if field_path.startswith('timestamp:'):
                return match.group(0)  # Keep original pattern
            
            # Handle nested fields like dataTransaction.transAmount
            if '.' in field_path:
                parts = field_path.split('.')
                value = request_body
                for part in parts:
                    if isinstance(value, dict) and part in value:
                        value = value[part]
                    else:
                        return "null"  # Field not found
                return str(value) if value is not None else "null"
            
            # Handle simple fields
            if field_path in request_body:
                value = request_body[field_path]
                return str(value) if value is not None else "null"
            
            return "null"  # Field not found
        
        # Replace all [field] patterns, but skip timestamp patterns
        return re.sub(r'\[([^\]]+)\]', replace_field, template_str)
    
    def _process_timestamps(self, template_str: str) -> str:
        """Process timestamp formatting patterns"""
        now = datetime.now()
        
        def replace_timestamp(match):
            timestamp_type = match.group(1)
            format_spec = match.group(2) if match.group(2) else ""
            
            if timestamp_type == "iso":
                return now.isoformat() + "Z"
            elif timestamp_type == "date":
                if format_spec == "DDMMYY":
                    return now.strftime("%d%m%y")
                else:
                    return now.strftime("%Y-%m-%d")
            elif timestamp_type == "time":
                if format_spec == "HHMMSS":
                    return now.strftime("%H%M%S")
                else:
                    return now.strftime("%H:%M:%S")
            
            return now.isoformat()
        
        # Replace timestamp patterns like [timestamp:iso] or [timestamp:date:DDMMYY]
        # Use a more specific pattern to avoid capturing nested brackets
        return re.sub(r'\[timestamp:([^:\]]+)(?::([^\]]+))?\]', replace_timestamp, template_str)
    
    def generate_response(self, request_body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Generate response using template engine with code-amount logic"""
        try:
            code = str(request_body.get("code", "default"))
            
            # Extract amount from request (support both direct and nested paths)
            amount = None
            if "amount" in request_body:
                amount = str(request_body["amount"])
            elif "dataTransaction" in request_body and "transAmount" in request_body["dataTransaction"]:
                amount = str(request_body["dataTransaction"]["transAmount"])
            
            # Load template based on code and amount
            template = self.load_template(code, amount)
            if not template:
                return None
            
            # Process template
            response = self.process_template(template, request_body)
            
            return response
            
        except Exception as e:
            print(f"Error generating response: {e}")
            return None
