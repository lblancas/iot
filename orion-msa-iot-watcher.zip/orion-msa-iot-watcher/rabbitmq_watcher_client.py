#!/usr/bin/env python3
"""
RabbitMQ Watcher Client
Handles message consumption and publishing for Watcher service
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional, Callable

# Import our RabbitMQ client (now local to watcher service)
from rabbitmq_client import RabbitMQClient, RabbitMQConfig

logger = logging.getLogger(__name__)

class WatcherRabbitMQClient:
    """RabbitMQ client specifically designed for Watcher service"""
    
    def __init__(self, rabbitmq_host: str, environment: str = "dev"):
        self.config = RabbitMQConfig(
            host=rabbitmq_host,
            environment=environment
        )
        self.client = RabbitMQClient(self.config)
        self._consuming = False
        self._message_handler: Optional[Callable] = None
        
    async def initialize(self) -> None:
        """Initialize connection and setup watcher queue"""
        try:
            # Connect to RabbitMQ
            await self.client.connect()
            
            # Declare watcher queue
            watcher_queue = await self.client.declare_queue("watcher")
            
            # Declare DLQ for watcher
            dlq_name = f"sps-{self.config.environment}-orion-dlq-watcher"
            dlq_queue = await self.client._channel.declare_queue(
                dlq_name,
                durable=True,
                arguments={"x-queue-type": "classic"}
            )
            
            # Bind DLQ to DLX exchange
            dlx_exchange = await self.client._channel.get_exchange(self.config.get_dlx_name())
            await dlq_queue.bind(dlx_exchange, "watcher")
            
            logger.info("✅ Watcher RabbitMQ client initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Watcher RabbitMQ client: {e}")
            raise
    
    async def start_consuming(self, message_handler: Callable[[Dict[str, Any]], None]) -> None:
        """Start consuming messages from watcher queue"""
        try:
            self._message_handler = message_handler
            
            await self.client.consume_messages(
                "watcher",
                self._handle_watcher_message
            )
            
            self._consuming = True
            logger.info("🔄 Started consuming messages for Watcher")
            
        except Exception as e:
            logger.error(f"❌ Failed to start consuming: {e}")
            raise
    
    async def _handle_watcher_message(self, message: Dict[str, Any]) -> None:
        """Handle incoming messages for watcher"""
        try:
            # Extract message details
            transaction_folio = message.get("transactionFolio")
            state_id = message.get("stateId")
            code = message.get("code", "unknown")
            ws_no = message.get("wsNo")
            site_id = message.get("siteId")
            
            logger.info(f"📥 Watcher received: code={code}, wsNo={ws_no}, siteId={site_id}, transactionFolio={transaction_folio}, stateId={state_id}")
            
            # Validate message - same logic as original
            if not all([transaction_folio, ws_no, site_id, state_id]):
                missing_fields = []
                if not transaction_folio: missing_fields.append("transactionFolio")
                if not ws_no: missing_fields.append("wsNo") 
                if not site_id: missing_fields.append("siteId")
                if not state_id: missing_fields.append("stateId")
                
                logger.warning(f"❌ Missing required fields: {missing_fields} - Ignoring malformed message")
                return
            
            if state_id != "request":
                logger.debug(f"Ignoring message with stateId: {state_id}")
                return
            
            # Call the original message handler
            if self._message_handler:
                await self._message_handler(message)
                
        except Exception as e:
            logger.error(f"❌ Error handling watcher message: {e}")
            # Don't raise - let RabbitMQ handle retry logic
    
    async def send_to_workflow(self, payload: Dict[str, Any]) -> None:
        """Send message to workflow service"""
        try:
            await self.client.publish_message(
                routing_key="orion.workflow.request",
                message=payload
            )
            
            transaction_folio = payload.get("transactionFolio", "unknown")
            thing_id = payload.get("thingId", "unknown")
            logger.info(f"📤 Sent to WORKFLOW: transactionFolio={transaction_folio}, thingId={thing_id}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to workflow: {e}")
            raise
    
    async def send_to_state_handler(self, payload: Dict[str, Any]) -> None:
        """Send message to state handler service"""
        try:
            await self.client.publish_message(
                routing_key="orion.state-handler.update",
                message=payload
            )
            
            transaction_folio = payload.get("transaction_folio", "unknown")
            logger.info(f"📤 Sent to state_handler: transactionFolio={transaction_folio}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to state handler: {e}")
            raise
    
    async def send_error_to_gateway(self, payload: Dict[str, Any]) -> None:
        """Send error response back to gateway"""
        try:
            await self.client.publish_message(
                routing_key="orion.gateway.response",
                message=payload
            )
            
            transaction_folio = payload.get("transactionFolio", "unknown")
            logger.info(f"📤 Sent error to gateway: transactionFolio={transaction_folio}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send error to gateway: {e}")
            raise
    
    async def stop_consuming(self) -> None:
        """Stop consuming messages"""
        try:
            if self._consuming:
                await self.client.stop_consuming("watcher")
                self._consuming = False
                logger.info("⏹️ Stopped consuming messages for Watcher")
                
        except Exception as e:
            logger.error(f"Error stopping consumer: {e}")
    
    async def health_check(self) -> bool:
        """Check if RabbitMQ connection is healthy"""
        try:
            return await self.client.health_check()
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def disconnect(self) -> None:
        """Close RabbitMQ connection"""
        try:
            # Stop consuming first
            await self.stop_consuming()
            
            # Disconnect client
            await self.client.disconnect()
            
            logger.info("🔌 Watcher RabbitMQ client disconnected")
            
        except Exception as e:
            logger.error(f"Error disconnecting Watcher client: {e}")

# Factory function for easier integration
def create_watcher_rabbitmq_client(rabbitmq_host: str, environment: str = "dev") -> WatcherRabbitMQClient:
    """Create and return Watcher RabbitMQ client"""
    return WatcherRabbitMQClient(rabbitmq_host, environment)