"""
Device Manager for Watcher microservice
Handles database operations for device status and WSNo -> ClientID mapping
"""

import logging
from datetime import datetime
from typing import Dict, Any, Optional, List
import asyncpg
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy import select, update, insert, text
from database import DeviceStatusTable, DeviceMappingTable, Base
from models import DeviceStatus, DeviceMapping

logger = logging.getLogger(__name__)

class DeviceManager:
    """Manages device status and database operations"""
    
    def __init__(self, config):
        self.config = config
        self.engine_rw = None
        self.engine_ro = None
        self.async_session_rw = None
        self.async_session_ro = None
    
    async def initialize(self):
        """Initialize database connections (RW and RO)"""
        try:
            # Get optimized pool configuration
            pool_config = self.config.get_db_pool_config()
            connection_timeout = self.config.DB_CONNECTION_TIMEOUT
            
            # Create async engine for Read-Write operations
            database_url_rw = self.config.get_async_database_url(read_only=False)
            self.engine_rw = create_async_engine(
                database_url_rw,
                echo=False,
                pool_size=pool_config['maxconn'],
                max_overflow=2,  # Small overflow for peak load
                pool_pre_ping=True,  # Validate connections
                pool_timeout=connection_timeout,
                connect_args={
                    "command_timeout": self.config.DB_QUERY_TIMEOUT,
                    "server_settings": {
                        "application_name": "watcher-device-manager"
                    }
                }
            )
            
            # Create async engine for Read-Only operations  
            database_url_ro = self.config.get_async_database_url(read_only=True)
            self.engine_ro = create_async_engine(
                database_url_ro,
                echo=False,
                pool_size=pool_config['maxconn'],
                max_overflow=2,  # Small overflow for peak load
                pool_pre_ping=True,  # Validate connections
                pool_timeout=connection_timeout,
                connect_args={
                    "command_timeout": self.config.DB_QUERY_TIMEOUT,
                    "server_settings": {
                        "application_name": "watcher-device-manager"
                    }
                }
            )
            
            # Create async session factories
            self.async_session_rw = sessionmaker(
                self.engine_rw,
                class_=AsyncSession,
                expire_on_commit=False
            )
            
            self.async_session_ro = sessionmaker(
                self.engine_ro,
                class_=AsyncSession,
                expire_on_commit=False
            )
            
            # Prewarm connection pools to avoid cold start delays
            await self._prewarm_pools()
            
            logger.info("✅ Device manager initialized successfully with warmed RO/RW pools")
            
        except Exception as e:
            logger.error(f"Failed to initialize device manager: {e}")
            raise
    
    async def _prewarm_pools(self):
        """Prewarm database connection pools to avoid cold start delays"""
        try:
            # Test RW connection
            async with self.engine_rw.begin() as rw_conn:
                await rw_conn.execute("SELECT 1 as test_rw")
            logger.debug("🔥 RW pool prewarmed")
            
            # Test RO connection  
            async with self.engine_ro.begin() as ro_conn:
                await ro_conn.execute("SELECT 1 as test_ro")
            logger.debug("🔥 RO pool prewarmed")
            
            logger.info("🚀 Database pools prewarmed successfully")
            
        except Exception as e:
            logger.warning(f"⚠️ Pool prewarming failed (not critical): {e}")
            # Don't raise - prewarming failure shouldn't stop initialization
    
    async def get_device_status(self, ws_no: str) -> Optional[DeviceStatus]:
        """Get device status by WSNo with optimized single query"""
        try:
            # Try optimized single query first
            status = await self._get_device_status_optimized(ws_no)
            if status:
                return status
                
            # Fallback to original logic if optimized query fails
            logger.debug(f"Falling back to original query logic for {ws_no}")
            return await self._get_device_status_original(ws_no)
                
        except Exception as e:
            logger.error(f"Error getting device status for {ws_no}: {e}")
            return None
    
    async def _get_device_status_optimized(self, ws_no: str) -> Optional[DeviceStatus]:
        """Optimized single-query approach"""
        try:
            async with self.async_session_ro() as session:
                # Single JOIN query to get mapping + status in one go
                query = text("""
                SELECT 
                    m.thing_name,
                    m."SiteId" as site_id,
                    s.is_online,
                    s.last_seen,
                    s.connection_status,
                    s.metadata_json
                FROM cloud.bt_thing_mapping m
                LEFT JOIN cloud.bt_device_status s ON m.thing_name = s.client_id  
                WHERE m."WSNo" = :ws_no
                LIMIT 1
                """)
                
                result = await session.execute(query, {"ws_no": ws_no})
                row = result.fetchone()
                
                if not row or not row.thing_name:
                    return None  # No mapping found
                
                # If we have mapping but no status, create default status
                if row.is_online is None:
                    await self._create_default_status(row.thing_name, ws_no)
                    # Return minimal status object for immediate use
                    status = DeviceStatusTable(
                        client_id=row.thing_name,
                        is_online=False,
                        last_seen=datetime.now(),
                        connection_status="unknown"
                    )
                    return status
                
                # Build status object from joined data
                status = DeviceStatusTable(
                    client_id=row.thing_name,
                    is_online=row.is_online,
                    last_seen=row.last_seen,
                    connection_status=row.connection_status,
                    metadata_json=row.metadata_json
                )
                
                return status
                
        except Exception as e:
            logger.debug(f"Optimized query failed for {ws_no}: {e}")
            return None  # Fallback to original method
    
    async def _get_device_status_original(self, ws_no: str) -> Optional[DeviceStatus]:
        """Original two-query approach as fallback"""
        try:
            async with self.async_session_ro() as session:
                # First get the ClientID mapping
                result = await session.execute(
                    select(DeviceMappingTable).where(DeviceMappingTable.ws_no == ws_no)
                )
                mapping = result.scalar_one_or_none()
                
                if not mapping:
                    logger.warning(f"No mapping found for WSNo: {ws_no}")
                    return None
                
                # Get current device status
                result = await session.execute(
                    select(DeviceStatusTable).where(DeviceStatusTable.client_id == mapping.thing_name)
                )
                status = result.scalar_one_or_none()
                
                if not status:
                    await self._create_default_status(mapping.thing_name, ws_no)
                    # Return minimal status for immediate use
                    status = DeviceStatusTable(
                        client_id=mapping.thing_name,
                        is_online=False,
                        last_seen=datetime.now(),
                        connection_status="unknown"
                    )
                
                return status
                
        except Exception as e:
            logger.error(f"Original query failed for {ws_no}: {e}")
            return None
    
    async def _create_default_status(self, client_id: str, ws_no: str):
        """Create default device status in separate RW transaction"""
        try:
            async with self.async_session_rw() as rw_session:
                status = DeviceStatusTable(
                    client_id=client_id,
                    is_online=False,
                    last_seen=datetime.now(),
                    connection_status="unknown"
                )
                rw_session.add(status)
                await rw_session.commit()
                logger.info(f"✅ Created default status for {ws_no} -> {client_id}")
                
        except Exception as e:
            logger.warning(f"⚠️ Failed to create default status for {ws_no}: {e}")
            # Don't raise - the caller can still work with a minimal status object
    
    async def update_device_status(self, client_id: str, is_online: bool, connection_status: str = None):
        """Update device status (READ-WRITE operation)"""
        try:
            async with self.async_session_rw() as session:
                # Update or create device status
                result = await session.execute(
                    select(DeviceStatusTable).where(DeviceStatusTable.client_id == client_id)
                )
                status = result.scalar_one_or_none()
                
                if status:
                    # Update existing status
                    status.is_online = is_online
                    status.last_seen = datetime.utcnow()
                    if connection_status:
                        status.connection_status = connection_status
                else:
                    # Create new status
                    status = DeviceStatusTable(
                        client_id=client_id,
                        is_online=is_online,
                        last_seen=datetime.utcnow(),
                        connection_status=connection_status or ("online" if is_online else "offline")
                    )
                    session.add(status)
                
                await session.commit()
                
                status_text = "online" if is_online else "offline"
                logger.info(f"Updated device {client_id} status to {status_text}")
                
        except Exception as e:
            logger.error(f"Error updating device status for {client_id}: {e}")
    
    async def get_all_device_mappings(self) -> List[DeviceMapping]:
        """Get all device mappings (READ-ONLY operation)"""
        try:
            async with self.async_session_ro() as session:
                result = await session.execute(select(DeviceMappingTable))
                mappings = result.scalars().all()
                return list(mappings)
                
        except Exception as e:
            logger.error(f"Error getting device mappings: {e}")
            return []
    
    async def create_device_mapping(self, ws_no: str, client_id: str) -> bool:
        """Create or update device mapping (READ-WRITE operation)"""
        try:
            async with self.async_session_rw() as session:
                # Check if mapping exists
                result = await session.execute(
                    select(DeviceMappingTable).where(DeviceMappingTable.ws_no == ws_no)
                )
                existing = result.scalar_one_or_none()
                
                if existing:
                    # Update existing mapping
                    existing.thing_name = client_id
                    existing.updated_at = datetime.utcnow()
                else:
                    # Create new mapping
                    mapping = DeviceMappingTable(
                        ws_no=ws_no,
                        thing_name=client_id,
                        site_id="default"  # Default site ID
                    )
                    session.add(mapping)
                
                await session.commit()
                logger.info(f"Created/updated mapping: {ws_no} -> {client_id}")
                return True
                
        except Exception as e:
            logger.error(f"Error creating device mapping {ws_no} -> {client_id}: {e}")
            return False
    
    async def get_device_statistics(self) -> Dict[str, Any]:
        """Get device statistics (READ-ONLY operation)"""
        try:
            async with self.async_session_ro() as session:
                # Count total devices
                total_result = await session.execute(select(DeviceMappingTable))
                total_devices = len(total_result.scalars().all())
                
                # Count online devices
                online_result = await session.execute(
                    select(DeviceStatusTable).where(DeviceStatusTable.is_online == True)
                )
                online_devices = len(online_result.scalars().all())
                
                # Count offline devices
                offline_result = await session.execute(
                    select(DeviceStatusTable).where(DeviceStatusTable.is_online == False)
                )
                offline_devices = len(offline_result.scalars().all())
                
                return {
                    "total_devices": total_devices,
                    "online_devices": online_devices,
                    "offline_devices": offline_devices,
                    "unmapped_devices": total_devices - (online_devices + offline_devices),
                    "last_updated": datetime.utcnow().isoformat()
                }
                
        except Exception as e:
            logger.error(f"Error getting device statistics: {e}")
            return {
                "total_devices": 0,
                "online_devices": 0,
                "offline_devices": 0,
                "unmapped_devices": 0,
                "error": str(e)
            }
    
    async def cleanup_old_statuses(self, hours: int = 24):
        """Clean up old device statuses (READ-WRITE operation)"""
        try:
            from datetime import timedelta
            cutoff_time = datetime.utcnow() - timedelta(hours=hours)
            
            async with self.async_session_rw() as session:
                # Update devices that haven't been seen recently to offline
                await session.execute(
                    update(DeviceStatusTable)
                    .where(DeviceStatusTable.last_seen < cutoff_time)
                    .where(DeviceStatusTable.is_online == True)
                    .values(is_online=False, connection_status="timeout")
                )
                
                await session.commit()
                logger.info(f"Cleaned up devices not seen in {hours} hours")
                
        except Exception as e:
            logger.error(f"Error cleaning up old statuses: {e}")
    
    async def close(self):
        """Close database connections"""
        if self.engine_rw:
            await self.engine_rw.dispose()
        if self.engine_ro:
            await self.engine_ro.dispose()
        logger.info("Device manager closed")