"""
Data models for Watcher microservice
"""

from datetime import datetime
from typing import Optional, Dict, Any
from pydantic import BaseModel

class DeviceMapping(BaseModel):
    """Device mapping model"""
    ws_no: str
    client_id: str
    created_at: datetime
    updated_at: datetime

class DeviceStatus(BaseModel):
    WSNo: str
    SiteID: str
    ClientID: str  # thing_name from mapping table
    is_online: bool
    last_seen: datetime
    connection_status: str

class StateHandlerMessage(BaseModel):
    """Message structure for state handler communications"""
    transaction_folio: str
    operation_type: str
    current_step: str = "watcher"
    status: str  # "success" or "error"
    payload: Dict[str, Any]
    execution_start_time: str  # ISO format datetime string
    execution_end_time: str    # ISO format datetime string
    execution_total_time: str  # in milliseconds as string
    response_code: str
    response_message: str

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str = "healthy"
    service: str = "watcher"
    timestamp: datetime
    version: str = "1.0.0"