"""
IoT Monitor for Watcher microservice
Orchestrates IoT connection and message handling
"""

import asyncio
import logging
import threading
from typing import Optional
from iot_connection import IoTConnection
from iot_message_handler import IoTMessageHandler

logger = logging.getLogger("orion-watcher")

class IoTMonitor:
    """Orchestrates IoT connection and message handling"""
    
    def __init__(self, config, device_manager, watcher_manager):
        self.config = config
        self.device_manager = device_manager
        self.watcher_manager = watcher_manager
        self.connection_event = threading.Event()
        self.connection: Optional[IoTConnection] = None
        self.message_handler: Optional[IoTMessageHandler] = None
        self.running = False
    
    async def initialize(self):
        """Initialize IoT components"""
        logger.info("🚀 STARTING IOT MONITOR INITIALIZATION...")
        try:
            # Initialize IoT connection
            self.connection = IoTConnection(self.config, self.connection_event)
            self.connection.initialize()
            
            # Initialize message handler with event loop and config
            loop = asyncio.get_event_loop()
            self.message_handler = IoTMessageHandler(self.device_manager, self.watcher_manager, self.config, loop)
            
            # Set message handler
            self.connection.set_message_handler(self.message_handler.create_message_handler())
            
            logger.info("✅ IoT Monitor initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize IoT Monitor: {e}")
            raise
    
    async def start(self):
        """Start IoT monitoring"""
        if not self.connection:
            raise RuntimeError("IoT Monitor not initialized")
        
        self.running = True
        self.connection.start()
        logger.info("🔄 IoT Monitor started")
    
    async def stop(self):
        """Stop IoT monitoring"""
        self.running = False
        if self.connection:
            self.connection.stop()
        logger.info("⏹️ IoT Monitor stopped")
    
    def is_connected(self) -> bool:
        """Check if IoT connection is active"""
        return self.connection_event.is_set() if self.connection_event else False