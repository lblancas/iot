"""
IoT Connection for Watcher microservice
Handles MQTT connection to AWS IoT Core
"""

import ssl
import logging
import threading
import time
from typing import Optional
import paho.mqtt.client as mqtt

logger = logging.getLogger("orion-watcher")

class IoTConnection:
    """Handles MQTT connection to AWS IoT Core"""
    
    def __init__(self, config, connection_event: threading.Event):
        self.config = config
        self.connection_event = connection_event
        self.client: Optional[mqtt.Client] = None
        self.running = False
        self.connected = False
        self.subscribed = False
    
    def initialize(self) -> None:
        """Initialize IoT MQTT client"""
        logger.info("🚀 STARTING IOT CONNECTION INITIALIZATION...")
        
        try:
            # Get thing name from config
            thing_name = self.config.get_thing_name()
            if not thing_name:
                raise ValueError("Thing name not configured in secrets")
            
            # Get IoT endpoint for diagnostics
            iot_endpoint = self.config.get_iot_endpoint()
            if not iot_endpoint:
                raise ValueError("IoT endpoint not configured in secrets")
            
            logger.info(f"🔗 IoT Endpoint: {iot_endpoint}")
            logger.info(f"🆔 Creating MQTT client with ID: {thing_name}")
            
            # Create MQTT client with Thing Name as Client ID
            self.client = mqtt.Client(
                client_id=thing_name,
                protocol=mqtt.MQTTv311,
                clean_session=True
            )
            
            # Configure SSL context
            ssl_context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            # Load certificates
            cert_paths = self.config.get_cert_paths()
            logger.info(f"📜 Certificate paths: {cert_paths}")
            
            # Verify certificate files exist
            import os
            for cert_type, cert_path in cert_paths.items():
                if not os.path.exists(cert_path):
                    logger.error(f"❌ Certificate file not found: {cert_type} at {cert_path}")
                    raise FileNotFoundError(f"Certificate file not found: {cert_path}")
                else:
                    logger.info(f"✅ Certificate file exists: {cert_type} at {cert_path}")
            
            ssl_context.load_cert_chain(cert_paths['cert_file'], cert_paths['key_file'])
            ssl_context.load_verify_locations(cert_paths['ca_cert'])
            
            # Set SSL context
            self.client.tls_set_context(ssl_context)
            
            # Set callbacks
            self.client.on_connect = self._on_connect
            self.client.on_disconnect = self._on_disconnect
            self.client.on_message = self._on_message
            
            # Set connection parameters with retry logic
            self.client.connect_async(
                self.config.get_iot_endpoint(),
                port=8883,
                keepalive=self.config.IOT_MONITOR_KEEPALIVE
            )
            
            logger.info("✅ IoT connection initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize IoT connection: {e}")
            raise
    
    def start(self) -> None:
        """Start the IoT connection"""
        if not self.client:
            raise RuntimeError("IoT client not initialized")
        
        self.running = True
        self.client.loop_start()
        logger.info("🔄 IoT connection started")
    
    def stop(self) -> None:
        """Stop the IoT connection"""
        self.running = False
        if self.client:
            self.client.loop_stop()
            self.client.disconnect()
        logger.info("⏹️ IoT connection stopped")
    
    def _on_connect(self, client, userdata, flags, rc):
        """Handle MQTT connection"""
        if rc == 0:
            logger.info("✅ Connected to AWS IoT Core")
            
            # Reset all counters on successful connection
            self.reconnect_attempts = 0
            self.consecutive_failures = 0
            self.last_successful_connection = time.time()
            
            # Subscribe to presence topics
            self._subscribe_to_presence_topics()
            
            self.connection_event.set()
        else:
            logger.error(f"❌ Failed to connect to AWS IoT Core: {rc}")
            self.connection_event.clear()
    
    def _subscribe_to_presence_topics(self):
        """Subscribe to IoT presence topics"""
        try:
            presence_topic_pattern = self.config.get_presence_topic_pattern()
            if presence_topic_pattern:
                # Subscribe to presence topics
                self.client.subscribe(presence_topic_pattern, qos=1)
                logger.info(f"📡 Subscribed to presence topics: {presence_topic_pattern}")
            else:
                logger.warning("⚠️ No presence topic pattern configured")
        except Exception as e:
            logger.error(f"❌ Failed to subscribe to presence topics: {e}")
    
    def _on_disconnect(self, client, userdata, rc):
        """Handle MQTT disconnection"""
        if rc != 0:
            self.consecutive_failures += 1
            
            # Provide detailed error information
            error_messages = {
                1: "Connection refused - incorrect protocol version",
                2: "Connection refused - invalid client identifier", 
                3: "Connection refused - server unavailable",
                4: "Connection refused - bad username or password",
                5: "Connection refused - not authorised",
                7: "Connection lost - likely due to existing connection with same client_id (normal during pod restarts)"
            }
            
            error_msg = error_messages.get(rc, f"Unknown error code: {rc}")
            logger.warning(f"⚠️ Unexpected disconnection from AWS IoT Core: {rc} - {error_msg} (consecutive failures: {self.consecutive_failures})")
            
            # For code 7 (duplicate connection), provide specific diagnostics
            if rc == 7:
                logger.warning("🔍 DUPLICATE CONNECTION DETECTED:")
                logger.warning(f"   - Thing Name: {self.config.get_thing_name()}")
                logger.warning(f"   - This is normal during pod restarts or scaling")
                logger.warning("   - AWS IoT Core will automatically clean up the old session")
                logger.warning("   - Will retry connection after a delay...")
            
            # For code 7 (duplicate connection), be more tolerant
            if rc == 7:
                # Don't count code 7 as a "failure" - it's expected during restarts
                self.consecutive_failures = max(0, self.consecutive_failures - 1)
                logger.info("ℹ️ Code 7 is expected during pod restarts - not counting as failure")
            
            # Check if we should stop trying to reconnect (only for real failures)
            if self.consecutive_failures >= self.max_consecutive_failures:
                logger.error(f"❌ Too many consecutive failures ({self.consecutive_failures}). Stopping reconnection attempts.")
                self.running = False
                self.connection_event.clear()
                return
            
            # Only attempt reconnection if we're still running and haven't exceeded max attempts
            if self.running and self.reconnect_attempts < self.max_reconnect_attempts:
                self.reconnect_attempts += 1
                logger.info(f"🔄 Attempting to reconnect to AWS IoT Core... (attempt {self.reconnect_attempts}/{self.max_reconnect_attempts})")
                
                # Use exponential backoff with longer delays
                delay = min(self.reconnect_delay * (2 ** (self.reconnect_attempts - 1)), self.max_reconnect_delay)
                
                # For code 7, add extra delay to allow AWS IoT Core to clean up the old session
                if rc == 7:
                    delay = max(delay, 15)  # Minimum 15 seconds for code 7
                    logger.info(f"⏳ Code 7 detected - waiting {delay} seconds for AWS IoT Core to clean up old session...")
                else:
                    logger.info(f"⏳ Waiting {delay} seconds before reconnection...")
                
                # Schedule reconnection in a separate thread to avoid blocking
                def delayed_reconnect():
                    time.sleep(delay)
                    if self.running:
                        try:
                            client.reconnect()
                        except Exception as e:
                            logger.error(f"❌ Failed to reconnect: {e}")
                
                reconnect_thread = threading.Thread(target=delayed_reconnect, daemon=True)
                reconnect_thread.start()
            elif self.reconnect_attempts >= self.max_reconnect_attempts:
                logger.error(f"❌ Max reconnection attempts ({self.max_reconnect_attempts}) exceeded. Stopping IoT connection.")
                self.running = False
        else:
            logger.info("🔌 Disconnected from AWS IoT Core")
            # Reset counters on clean disconnect
            self.reconnect_attempts = 0
            self.consecutive_failures = 0
        self.connection_event.clear()
    
    def _on_message(self, client, userdata, message):
        """Handle incoming MQTT messages"""
        # This will be overridden by the message handler
        pass
    
    def set_message_handler(self, handler):
        """Set the message handler callback"""
        self.client.on_message = handler
    
    def get_connection_status(self) -> dict:
        """Get current connection status for diagnostics"""
        return {
            "running": self.running,
            "reconnect_attempts": self.reconnect_attempts,
            "consecutive_failures": self.consecutive_failures,
            "last_successful_connection": self.last_successful_connection,
            "is_connected": self.connection_event.is_set()
        }
