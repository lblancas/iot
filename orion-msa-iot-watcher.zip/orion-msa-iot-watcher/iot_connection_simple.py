import ssl
import logging
import threading
import time
from typing import Optional
import paho.mqtt.client as mqtt

logger = logging.getLogger("orion-watcher")

class IoTConnection:
    """Handles MQTT connection to AWS IoT Core with simple logic"""
    
    def __init__(self, config, connection_event: threading.Event):
        self.config = config
        self.connection_event = connection_event
        self.client: Optional[mqtt.Client] = None
        self.running = False
        self.connected = False
        self.subscribed = False
    
    def initialize(self) -> None:
        """Initialize IoT MQTT client"""
        logger.info("🚀 STARTING IOT CONNECTION INITIALIZATION...")
        try:
            thing_name = self.config.get_thing_name()
            if not thing_name:
                raise ValueError("Thing name not configured in secrets")
            
            logger.info(f"🆔 Creating MQTT client with ID: {thing_name}")
            self.client = mqtt.Client(
                client_id=thing_name,
                protocol=mqtt.MQTTv311,
                clean_session=True
            )
            
            # Configure SSL context
            ssl_context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            cert_paths = self.config.get_cert_paths()
            ssl_context.load_cert_chain(cert_paths['cert_file'], cert_paths['key_file'])
            ssl_context.load_verify_locations(cert_paths['ca_cert'])
            
            self.client.tls_set_context(ssl_context)
            
            # Set callbacks
            self.client.on_connect = self._on_connect
            self.client.on_disconnect = self._on_disconnect
            self.client.on_message = self._on_message
            
            logger.info("✅ IoT connection initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize IoT connection: {e}")
            raise
    
    def start(self) -> None:
        """Start IoT connection with simple logic"""
        logger.info("🔄 Starting IoT connection...")
        self.running = True
        
        # Try to connect
        self._connect()
        
        # Start the loop
        if self.client:
            self.client.loop_start()
    
    def stop(self) -> None:
        """Stop IoT connection"""
        logger.info("🛑 Stopping IoT connection...")
        self.running = False
        self.connected = False
        self.subscribed = False
        
        if self.client:
            self.client.loop_stop()
            self.client.disconnect()
    
    def _connect(self) -> None:
        """Connect to AWS IoT Core"""
        if not self.client:
            return
        
        try:
            logger.info("🔗 Connecting to AWS IoT Core...")
            self.client.connect(
                self.config.get_iot_endpoint(),
                port=8883,
                keepalive=self.config.IOT_MONITOR_KEEPALIVE
            )
        except Exception as e:
            logger.error(f"❌ Failed to connect to AWS IoT Core: {e}")
            self._schedule_reconnect()
    
    def _schedule_reconnect(self) -> None:
        """Schedule a reconnection attempt"""
        if not self.running:
            return
        
        logger.info("⏳ Scheduling reconnection in 10 seconds...")
        def reconnect():
            time.sleep(10)
            if self.running:
                self._connect()
        
        reconnect_thread = threading.Thread(target=reconnect, daemon=True)
        reconnect_thread.start()
    
    def _on_connect(self, client, userdata, flags, rc):
        """Handle connection callback"""
        if rc == 0:
            logger.info("✅ Connected to AWS IoT Core")
            self.connected = True
            self.connection_event.set()
            self._subscribe_to_presence_topics()
        else:
            logger.error(f"❌ Failed to connect to AWS IoT Core: {rc}")
            self.connected = False
            self.connection_event.clear()
            self._schedule_reconnect()
    
    def _on_disconnect(self, client, userdata, rc):
        """Handle disconnection callback"""
        logger.info(f"🔌 Disconnected from AWS IoT Core: {rc}")
        self.connected = False
        self.subscribed = False
        self.connection_event.clear()
        
        if self.running:
            self._schedule_reconnect()
    
    def _on_message(self, client, userdata, message):
        """Handle incoming messages"""
        # This will be set by the message handler
        pass
    
    def _subscribe_to_presence_topics(self) -> None:
        """Subscribe to presence topics"""
        if not self.connected or not self.client:
            return
        
        try:
            topic_pattern = self.config.get_presence_topic_pattern()
            result = self.client.subscribe(topic_pattern)
            
            if result[0] == mqtt.MQTT_ERR_SUCCESS:
                logger.info(f"📡 Subscribed to presence topics: {topic_pattern}")
                self.subscribed = True
            else:
                logger.error(f"❌ Failed to subscribe to presence topics: {result[0]}")
                self.subscribed = False
                
        except Exception as e:
            logger.error(f"❌ Error subscribing to presence topics: {e}")
            self.subscribed = False
    
    def set_message_handler(self, handler):
        """Set the message handler callback"""
        if self.client:
            self.client.on_message = handler
    
    def get_connection_status(self) -> dict:
        """Get current connection status"""
        return {
            "running": self.running,
            "connected": self.connected,
            "subscribed": self.subscribed
        }
