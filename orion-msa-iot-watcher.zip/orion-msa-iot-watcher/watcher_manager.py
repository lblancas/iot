#!/usr/bin/env python3
"""
Watcher Manager - RabbitMQ Integration
"""

import logging
from typing import Dict, Any, Optional, Callable
from config import config

# Import RabbitMQ client
from rabbitmq_watcher_client import WatcherRabbitMQClient

logger = logging.getLogger(__name__)

class WatcherManager:
    """
    Manages RabbitMQ connections and operations for Watcher
    """
    
    def __init__(self):
        self.rabbitmq_client: Optional[WatcherRabbitMQClient] = None
        logger.info("🔧 Watcher Manager initialized with RabbitMQ")
    
    async def initialize(self) -> None:
        """Initialize RabbitMQ client"""
        try:
            secrets = config.get_secrets()
            
            # Initialize RabbitMQ client with secrets
            rabbitmq_host = secrets.get("rabbitmq_host")
            rabbitmq_env = secrets.get("rabbitmq_environment", "dev")
            
            if not rabbitmq_host:
                raise ValueError("rabbitmq_host not found in secrets")
            
            self.rabbitmq_client = WatcherRabbitMQClient(
                rabbitmq_host=rabbitmq_host,
                environment=rabbitmq_env
            )
            await self.rabbitmq_client.initialize()
            logger.info("✅ RabbitMQ client initialized")
                
        except Exception as e:
            logger.error(f"❌ Failed to initialize Watcher Manager: {e}")
            raise
    
    async def start_consuming(self, message_handler: Callable[[Dict[str, Any]], None]) -> None:
        """Start consuming messages from watcher queue"""
        await self.rabbitmq_client.start_consuming(message_handler)
    
    async def send_to_workflow(self, payload: Dict[str, Any]) -> None:
        """Send message to workflow service"""
        await self.rabbitmq_client.send_to_workflow(payload)
    
    async def send_to_state_handler(self, payload: Dict[str, Any]) -> None:
        """Send message to state handler service"""
        await self.rabbitmq_client.send_to_state_handler(payload)
    
    async def send_error_to_gateway(self, payload: Dict[str, Any]) -> None:
        """Send error response back to gateway"""
        await self.rabbitmq_client.send_error_to_gateway(payload)
    
    async def stop_consuming(self) -> None:
        """Stop consuming messages"""
        if self.rabbitmq_client:
            await self.rabbitmq_client.stop_consuming()
    
    async def health_check(self) -> bool:
        """Check broker health"""
        try:
            return await self.rabbitmq_client.health_check()
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def disconnect(self) -> None:
        """Disconnect from message broker"""
        try:
            if self.rabbitmq_client:
                await self.rabbitmq_client.disconnect()
                
            logger.info("🔌 RabbitMQ client disconnected")
            
        except Exception as e:
            logger.error(f"Error disconnecting from RabbitMQ: {e}")

# Global watcher manager instance
watcher_manager: Optional[WatcherManager] = None

def get_watcher_manager() -> WatcherManager:
    """Get or create watcher manager singleton"""
    global watcher_manager
    if watcher_manager is None:
        watcher_manager = WatcherManager()
    return watcher_manager