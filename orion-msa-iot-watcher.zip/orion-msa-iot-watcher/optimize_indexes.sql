-- Optimización de índices para el microservicio watcher
-- Ejecutar este script en la base de datos para mejorar el rendimiento

-- 1. Índice compuesto para bt_thing_mapping (WSNo, SiteId)
-- Este es el índice más importante para las consultas del watcher
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bt_thing_mapping_wsno_siteid 
ON cloud.bt_thing_mapping ("WSNo", "SiteId");

-- 2. Índice para bt_device_status (client_id)
-- Optimiza el JOIN entre las tablas
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bt_device_status_client_id 
ON cloud.bt_device_status (client_id);

-- 3. Índice para bt_device_status (is_online)
-- Útil para filtrar dispositivos online/offline
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bt_device_status_is_online 
ON cloud.bt_device_status (is_online);

-- 4. Índice para bt_device_status (last_seen)
-- Útil para consultas de dispositivos recientes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bt_device_status_last_seen 
ON cloud.bt_device_status (last_seen);

-- 5. Índice parcial para dispositivos online
-- Optimiza consultas que solo buscan dispositivos online
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bt_device_status_online_only 
ON cloud.bt_device_status (client_id) 
WHERE is_online = true;

-- 6. Estadísticas actualizadas
-- Ejecutar después de crear los índices
ANALYZE cloud.bt_thing_mapping;
ANALYZE cloud.bt_device_status;

-- 7. Verificar índices creados
SELECT 
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes 
WHERE schemaname = 'cloud' 
AND tablename IN ('bt_thing_mapping', 'bt_device_status')
ORDER BY tablename, indexname;

-- 8. Verificar estadísticas de uso de índices
SELECT 
    schemaname,
    tablename,
    indexname,
    idx_scan,
    idx_tup_read,
    idx_tup_fetch
FROM pg_stat_user_indexes 
WHERE schemaname = 'cloud' 
AND tablename IN ('bt_thing_mapping', 'bt_device_status')
ORDER BY idx_scan DESC;