"""
Configuration management for Watcher microservice
"""

import os
import json
import boto3
import logging
import asyncio
import concurrent.futures
from typing import Dict, Any
from pydantic import BaseModel
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

class BaseConfig(BaseModel):
    """Base configuration model"""
    class Config:
        extra = "allow"
    
    # Environment
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "local")
    AWS_REGION: str = os.getenv("AWS_REGION", "us-east-1")
    
    # Service configuration
    PORT: int = int(os.getenv("PORT", "40081"))
    
    # AWS Secrets Manager
    SECRETS_MANAGER_SECRET_NAME: str = os.getenv("SECRETS_MANAGER_SECRET_NAME", "sps-dev-orion-secret-iot-watcher")
    AWS_SECRET_NAME: str = os.getenv("AWS_SECRET_NAME", "sps-dev-orion-secret-iot-watcher")
    
    # RabbitMQ configuration
    RABBITMQ_HOST: str = os.getenv("RABBITMQ_HOST", "")
    RABBITMQ_USERNAME: str = os.getenv("RABBITMQ_USERNAME", "")
    RABBITMQ_PASSWORD: str = os.getenv("RABBITMQ_PASSWORD", "")
    RABBITMQ_ENVIRONMENT: str = os.getenv("RABBITMQ_ENVIRONMENT", "dev")
    
    # Performance configuration
    RABBITMQ_CONNECTION_TIMEOUT: int = int(os.getenv("RABBITMQ_CONNECTION_TIMEOUT", "30"))
    RABBITMQ_HEARTBEAT: int = int(os.getenv("RABBITMQ_HEARTBEAT", "30"))
    RABBITMQ_BLOCKED_CONNECTION_TIMEOUT: int = int(os.getenv("RABBITMQ_BLOCKED_CONNECTION_TIMEOUT", "300"))
    
    # Database configuration
    DB_POOL_MIN_CONN: int = int(os.getenv("DB_POOL_MIN_CONN", "1"))
    DB_POOL_MAX_CONN: int = int(os.getenv("DB_POOL_MAX_CONN", "3"))
    DB_CONNECTION_TIMEOUT: int = int(os.getenv("DB_CONNECTION_TIMEOUT", "5"))
    DB_QUERY_TIMEOUT: int = int(os.getenv("DB_QUERY_TIMEOUT", "10"))
    
    # Processing configuration
    MAX_CONCURRENT_MESSAGES: int = int(os.getenv("MAX_CONCURRENT_MESSAGES", "10"))
    MESSAGE_PROCESSING_TIMEOUT: int = int(os.getenv("MESSAGE_PROCESSING_TIMEOUT", "30"))
    
    # Logging configuration
    LOG_EMPTY_POLLS_INTERVAL: int = int(os.getenv("LOG_EMPTY_POLLS_INTERVAL", "100"))
    
    # IoT Monitor configuration
    IOT_MONITOR_TIMEOUT: int = int(os.getenv("IOT_MONITOR_TIMEOUT", "30"))
    IOT_MONITOR_KEEPALIVE: int = int(os.getenv("IOT_MONITOR_KEEPALIVE", "60"))

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._secrets_cache = None

    def get_secrets(self) -> Dict[str, Any]:
        """Get configuration from AWS Secrets Manager or environment variables"""
        if self._secrets_cache is not None:
            return self._secrets_cache

        if self.ENVIRONMENT == "local":
            # Use environment variables for local development
            self._secrets_cache = {
                # RabbitMQ config from environment (local dev)
                "rabbitmq_host": self.RABBITMQ_HOST,
                "rabbitmq_username": self.RABBITMQ_USERNAME,
                "rabbitmq_password": self.RABBITMQ_PASSWORD,
                "rabbitmq_environment": self.RABBITMQ_ENVIRONMENT
            }
        else:
            # Use AWS Secrets Manager for cloud environments
            try:
                session = boto3.session.Session()
                client = session.client(
                    service_name="secretsmanager", 
                    region_name=self.AWS_REGION
                )
                
                response = client.get_secret_value(SecretId=self.AWS_SECRET_NAME)
                self._secrets_cache = json.loads(response["SecretString"])
                
                logger.info(f"Successfully loaded secrets from {self.AWS_SECRET_NAME}")
                logger.info("🔧 Message broker mode: RabbitMQ")
                
            except ClientError as e:
                logger.error(f"Error retrieving secrets from {self.AWS_SECRET_NAME}: {e}")
                raise e
            except Exception as e:
                logger.error(f"Unexpected error loading secrets: {e}")
                raise e

        return self._secrets_cache
    
    def get_rabbitmq_config(self) -> Dict[str, int]:
        """Get optimized RabbitMQ configuration"""
        return {
            'connection_timeout': self.RABBITMQ_CONNECTION_TIMEOUT,
            'heartbeat': self.RABBITMQ_HEARTBEAT,
            'blocked_connection_timeout': self.RABBITMQ_BLOCKED_CONNECTION_TIMEOUT
        }
    
    def get_db_pool_config(self) -> Dict[str, int]:
        """Get optimized database pool configuration"""
        return {
            'minconn': self.DB_POOL_MIN_CONN,
            'maxconn': self.DB_POOL_MAX_CONN
        }
    
    def optimize_event_loop(self) -> None:
        """Optimize event loop for better performance"""
        try:
            # Configure event loop for better performance
            loop = asyncio.get_event_loop()
            
            # Configure concurrency limits
            if hasattr(loop, 'set_default_executor'):
                executor = concurrent.futures.ThreadPoolExecutor(
                    max_workers=self.MAX_CONCURRENT_MESSAGES
                )
                loop.set_default_executor(executor)
            
            logger.info("✅ Event loop optimized for performance")
            
        except Exception as e:
            logger.warning(f"⚠️ Could not optimize event loop: {e}")
    
    def get_optimized_query(self) -> str:
        """Get optimized SQL query for asyncpg (uses $1, $2 parameter syntax)"""
        return """
            SELECT 
                mapping.thing_name,
                status.is_online,
                status.last_seen,
                status.connection_status
            FROM cloud.bt_thing_mapping mapping
            INNER JOIN cloud.bt_device_status status ON mapping.thing_name = status.client_id
            WHERE mapping."WSNo" = $1 AND mapping."SiteId" = $2
            LIMIT 1
        """
    
    def log_performance_metrics(self, poll_count: int, poll_ms: float, message_count: int) -> None:
        """Log performance metrics"""
        if message_count > 0:
            logger.info(f"🔍 Poll #{poll_count}: Found {message_count} messages in {poll_ms:.1f}ms")
        elif poll_count % self.LOG_EMPTY_POLLS_INTERVAL == 0:
            logger.debug(f"🔍 Poll #{poll_count}: Empty poll in {poll_ms:.1f}ms")
    
    def get_async_database_url(self, read_only: bool = False) -> str:
        """Get async database URL for SQLAlchemy"""
        secrets = self.get_secrets()
        
        # Use read-only endpoint if available and requested
        if read_only and "read_only_host" in secrets:
            host = secrets["read_only_host"]
            port = secrets.get("read_only_port", secrets.get("port", 5432))
        else:
            host = secrets["host"]
            port = secrets.get("port", 5432)
        
        # Build async PostgreSQL URL
        database_url = f"postgresql+asyncpg://{secrets['username']}:{secrets['password']}@{host}:{port}/{secrets['dbname']}"
        
        return database_url
    
    def get_cert_paths(self) -> Dict[str, str]:
        """Get certificate paths for IoT connection"""
        secrets = self.get_secrets()
        
        # Get certificate directory from secrets or use default
        cert_dir = secrets.get("cert_dir", "/app/certs")
        
        # Handle relative paths
        if cert_dir.startswith('./'):
            cert_dir = cert_dir.replace('./', '/app/')
        
        # Get environment
        environment = self.ENVIRONMENT
        
        # Build certificate paths
        cert_paths = {
            'ca_cert': f"{cert_dir}/common/root-CA.crt",
            'cert_file': f"{cert_dir}/{environment}/orion-watcher-{environment}-certificate.pem.crt",
            'key_file': f"{cert_dir}/{environment}/orion-watcher-{environment}-private.pem.key"
        }
        
        return cert_paths
    
    def get_iot_endpoint(self) -> str:
        """Get IoT endpoint from secrets"""
        secrets = self.get_secrets()
        return secrets.get("iot_endpoint", "")
    
    def get_thing_name(self) -> str:
        """Get thing name from secrets"""
        secrets = self.get_secrets()
        return secrets.get("thing_name", "")
    
    def get_presence_topic_pattern(self) -> str:
        """Get presence topic pattern from secrets"""
        secrets = self.get_secrets()
        return secrets.get("presence_topic_pattern", "")

# Global configuration instance
config = BaseConfig()