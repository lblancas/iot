#!/usr/bin/env python3
"""
Watcher Microservice - Simple RabbitMQ Integration
Monitors device status and routes messages based on device connectivity
"""

import os
import sys
import json
import asyncio
import logging
import threading
import asyncpg
import uvloop
from datetime import datetime
from typing import Dict, Any, Optional
import boto3
from botocore.exceptions import ClientError
from fastapi import FastAPI
import uvicorn

from config import config
from models import HealthResponse, DeviceStatus, StateHandlerMessage
from iot_monitor import IoTMonitor
from device_manager import DeviceManager
# Performance config now integrated in config.py
from watcher_manager import get_watcher_manager

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("orion-watcher")

# FastAPI app for health endpoint
app = FastAPI(title="Watcher Microservice", version="1.0.0")

# High-performance asyncpg connection pool
db_pool: asyncpg.Pool = None
watcher_manager = None

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        service="watcher", 
        timestamp=datetime.now(),
        version="1.0.0"
    )

async def init_db_pool():
    """Initialize high-performance asyncpg connection pool"""
    global db_pool
    try:
        secrets = config.get_secrets()
        
        # Create high-performance asyncpg connection pool
        db_pool = await asyncpg.create_pool(
            host=secrets["host"],
            port=int(secrets.get("port", 5432)),
            database=secrets["dbname"],
            user=secrets["username"],
            password=secrets["password"],
            min_size=config.DB_POOL_MIN_CONN,
            max_size=config.DB_POOL_MAX_CONN,
            command_timeout=3,
            server_settings={
                'application_name': 'watcher-service-asyncpg'
            }
        )
        
        logger.info(f"✅ High-performance asyncpg connection pool initialized: {config.DB_POOL_MIN_CONN}-{config.DB_POOL_MAX_CONN} connections")
        
    except Exception as e:
        logger.error(f"❌ Error creating asyncpg connection pool: {e}")
        raise

async def close_db_pool():
    """Close the database connection pool gracefully"""
    global db_pool
    if db_pool:
        await db_pool.close()
        logger.info("🔌 Database connection pool closed")

async def get_device_status(ws_no: str, site_id: str) -> Optional[DeviceStatus]:
    """Get device status using high-performance asyncpg connection pool"""
    global db_pool
    
    if not db_pool:
        logger.error("❌ Database pool not initialized")
        return None
    
    try:
        # Get connection from asyncpg pool
        async with db_pool.acquire() as connection:
            # Execute query with asyncpg (returns dict-like Row objects)
            result = await connection.fetchrow(config.get_optimized_query(), ws_no, site_id)
            
            if result:
                return DeviceStatus(
                    WSNo=ws_no,
                    SiteID=site_id, 
                    ClientID=result["thing_name"],  # thing_name from mapping
                    is_online=result["is_online"],
                    last_seen=result["last_seen"],
                    connection_status=result["connection_status"]
                )
        
        return None
        
    except Exception as e:
        logger.error(f"❌ Error querying device status for wsNo: {ws_no}, siteId: {site_id}: {e}")
        return None

async def process_single_message(message_data: Dict[str, Any]):
    """Process a single message from RabbitMQ"""
    global watcher_manager
    
    try:
        # Capture start time
        execution_start = datetime.now()
        
        # Extract required fields
        transaction_folio = message_data.get("transactionFolio")
        state_id = message_data.get("stateId")
        code = message_data.get("code", "unknown")
        
        # Extract wsNo and siteId
        ws_no = message_data.get("wsNo")
        site_id = message_data.get("siteId")
        
        if not ws_no and "dataTransaction" in message_data:
            ws_no = message_data["dataTransaction"].get("wsNo")
        if not site_id and "dataTransaction" in message_data:
            site_id = message_data["dataTransaction"].get("siteId")
        
        logger.info(f"📥 Request: code={code}, wsNo={ws_no}, siteId={site_id}, transactionFolio={transaction_folio}, stateId={state_id}")
        
        # Validate message
        if not all([transaction_folio, ws_no, site_id, state_id]):
            missing_fields = []
            if not transaction_folio: missing_fields.append("transactionFolio")
            if not ws_no: missing_fields.append("wsNo") 
            if not site_id: missing_fields.append("siteId")
            if not state_id: missing_fields.append("stateId")
            
            logger.warning(f"❌ Missing required fields: {missing_fields} - Ignoring message")
            return

        if state_id != "request":
            logger.debug(f"Ignoring message with stateId: {state_id}")
            return

        # Check device status
        logger.info(f"🔍 Checking device: wsNo={ws_no}, siteId={site_id}")
        device_status = await get_device_status(ws_no, site_id)
        
        if not device_status:
            # Device not found
            logger.warning(f"❌ Device not found: wsNo: {ws_no}, siteId: {site_id}")
            
            # Send error to state_handler and gateway
            await send_error_response(transaction_folio, code, message_data, execution_start, "DEVICE_NOT_FOUND", "Device not found in database", "404")
            
        elif not device_status.is_online:
            # Device offline
            logger.warning(f"🔴 Device offline: wsNo: {ws_no}, siteId: {site_id}, thingId: {device_status.ClientID}")
            
            # Send error to state_handler and gateway
            await send_error_response(transaction_folio, code, message_data, execution_start, "DEVICE_OFFLINE", "Device is currently offline", "503")
            
        else:
            # Device online - forward to workflow
            logger.info(f"🟢 Device online, routing to WORKFLOW: thingId={device_status.ClientID}")
            
            # Add thingId and send to workflow
            modified_body = message_data.copy()
            modified_body["thingId"] = device_status.ClientID
            
            await watcher_manager.send_to_workflow(modified_body)
            
            # Send success to state_handler
            await send_success_response(transaction_folio, code, modified_body, execution_start, f"Device online, forwarded to workflow with thingId: {device_status.ClientID}")

    except Exception as e:
        logger.error(f"❌ Error processing message: {e}")

async def send_error_response(transaction_folio: str, code: str, original_request: Dict[str, Any], 
                            execution_start: datetime, error_code: str, error_message: str, response_code: str):
    """Send error response to state_handler and gateway"""
    global watcher_manager
    
    try:
        # Send to state_handler
        execution_end = datetime.now()
        total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
        
        state_msg = StateHandlerMessage(
            transaction_folio=transaction_folio,
            operation_type=f"{code}-response",
            current_step="watcher",
            status="error",
            payload=original_request,
            execution_start_time=execution_start.isoformat(),
            execution_end_time=execution_end.isoformat(),
            execution_total_time=str(int(total_execution_ms)),
            response_code=response_code,
            response_message=error_message
        )
        
        await watcher_manager.send_to_state_handler(state_msg.model_dump())
        
        # Send error to gateway
        error_response = {
            "stateId": "response",
            "transactionFolio": transaction_folio,
            "code": original_request.get("code", "unknown"),
            "sequenceNo": original_request.get("sequenceNo", "unknown"),
            "endpointType": original_request.get("endpointType", "unknown"),
            "siteId": original_request.get("siteId", "unknown"),
            "wsNo": original_request.get("wsNo", "unknown"),
            "requestStatus": "ERROR",
            "transactionStatus": "NOT_PROCESSED",
            "timestamp": datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
            "responseCode": "99",
            "responseMessage": "Failed Process",
            "errorCode": "990003",
            "errorMessage": error_message
        }
        
        await watcher_manager.send_error_to_gateway(error_response)
        
        logger.info(f"📤 Sent error response for {transaction_folio}")
        
    except Exception as e:
        logger.error(f"Error sending error response: {e}")

async def send_success_response(transaction_folio: str, code: str, payload: Dict[str, Any], 
                              execution_start: datetime, message: str):
    """Send success response to state_handler"""
    global watcher_manager
    
    try:
        execution_end = datetime.now()
        total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
        
        state_msg = StateHandlerMessage(
            transaction_folio=transaction_folio,
            operation_type=f"{code}-request",
            current_step="watcher",
            status="success",
            payload=payload,
            execution_start_time=execution_start.isoformat(),
            execution_end_time=execution_end.isoformat(),
            execution_total_time=str(int(total_execution_ms)),
            response_code="200",
            response_message=message
        )
        
        await watcher_manager.send_to_state_handler(state_msg.model_dump())
        
        logger.info(f"📤 Sent success response for {transaction_folio}")
        
    except Exception as e:
        logger.error(f"Error sending success response: {e}")

async def process_messages():
    """Main message processing loop with RabbitMQ support"""
    global watcher_manager
    
    try:
        # Initialize watcher manager
        watcher_manager = get_watcher_manager()
        await watcher_manager.initialize()
        
        # Start consuming from RabbitMQ
        logger.info("✅ RabbitMQ mode: Direct messaging enabled")
        await watcher_manager.start_consuming(process_single_message)
        logger.info("🔄 Started consuming messages from RabbitMQ")
        
        # Keep running
        while True:
            await asyncio.sleep(1)
            
    except Exception as e:
        logger.error(f"Fatal error in process_messages: {e}")
        raise

def run_fastapi():
    """Run FastAPI server in a separate thread"""
    uvicorn.run(app, host="0.0.0.0", port=config.PORT, log_level="info")

async def main():
    """Main function to run both FastAPI and message processing"""
    # Optimize event loop for performance
    config.optimize_event_loop()
    
    # Start FastAPI in a separate thread
    fastapi_thread = threading.Thread(target=run_fastapi, daemon=True)
    fastapi_thread.start()
    
    logger.info(f"Health endpoint available at http://0.0.0.0:{config.PORT}/health")
    
    # Initialize high-performance database connection pool
    await init_db_pool()
    
    # Initialize and start IoT Monitor if not local
    logger.info(f"🔍 Current environment: {config.ENVIRONMENT}")
    iot_monitor = None
    if config.ENVIRONMENT != "local":
        logger.info("✅ Environment is not 'local' - IoT Monitor will be started")
        try:
            # Initialize device manager
            device_manager = DeviceManager(config)
            await device_manager.initialize()
            
            # Get watcher manager
            watcher_manager = get_watcher_manager()
            
            # Initialize IoT Monitor with dependencies
            iot_monitor = IoTMonitor(config, device_manager, watcher_manager)
            await iot_monitor.initialize()
            
            # Start IoT Monitor in separate thread
            def run_iot_monitor():
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    loop.run_until_complete(iot_monitor.start())
                except Exception as e:
                    logger.error(f"❌ IoT Monitor thread error: {e}")
            
            iot_thread = threading.Thread(target=run_iot_monitor, daemon=True)
            iot_thread.start()
            logger.info("✅ IOT MONITOR STARTED SUCCESSFULLY in separate thread")
        except Exception as e:
            logger.error(f"❌ FAILED TO START IOT MONITOR: {e} - Continuing without IoT monitoring")
    else:
        logger.info("ℹ️ Local environment - IoT Monitor will not be started")
    
    try:
        # Start message processing
        await process_messages()
    finally:
        # Clean up
        if iot_monitor:
            await iot_monitor.stop()
        
        global db_pool
        if db_pool:
            db_pool.closeall()
            logger.info("🗑️ DB connection pool closed")

if __name__ == "__main__":
    try:
        # Configure uvloop for ultra-high performance async I/O (3-4x faster DB operations)
        logger.info("🚀 Configuring uvloop for ultra-high performance Watcher...")
        asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
        logger.info("✅ uvloop configured - Database and RabbitMQ operations will be 3-4x faster")
        
        # Run main with high-performance event loop
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("🛑 Watcher shutting down...")
    except Exception as e:
        logger.error(f"❌ Application error: {e}")
        sys.exit(1)