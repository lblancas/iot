"""
IoT Message Handler for Watcher microservice
Handles processing of IoT presence messages
"""

import json
import logging
import asyncio
from datetime import datetime
from typing import Dict, Any, Optional
import paho.mqtt.client as mqtt

logger = logging.getLogger("orion-watcher")

class IoTMessageHandler:
    """Handles processing of IoT presence messages"""
    
    def __init__(self, device_manager, watcher_manager, config, event_loop=None):
        self.device_manager = device_manager
        self.watcher_manager = watcher_manager
        self.config = config
        self.event_loop = event_loop or asyncio.get_event_loop()
    
    def create_message_handler(self):
        """Create the message handler callback"""
        def on_message(client, userdata, message):
            try:
                # Parse message
                payload = json.loads(message.payload.decode())
                
                # Process the message
                self._process_presence_message(payload)
                
            except json.JSONDecodeError as e:
                logger.error(f"❌ Invalid JSON in IoT message: {e}")
            except Exception as e:
                logger.error(f"❌ Error processing IoT message: {e}")
        
        return on_message
    
    def _process_presence_message(self, payload: Dict[str, Any]) -> None:
        """Process IoT presence message"""
        try:
            # Extract message details
            client_id = payload.get("clientId")
            event_type = payload.get("eventType")
            timestamp = payload.get("timestamp")
            
            if not client_id or not event_type:
                logger.warning("⚠️ Invalid IoT message format - missing clientId or eventType")
                return
            
            # Filter devices by environment - only process devices that match the environment pattern
            if not self._is_device_for_this_environment(client_id):
                logger.debug(f"🔍 Ignoring device {client_id} - not for this environment")
                return
            
            # Update device status based on event type
            if event_type == "connected":
                self._handle_device_connected(client_id, timestamp)
            elif event_type == "disconnected":
                self._handle_device_disconnected(client_id, timestamp)
            else:
                logger.warning(f"⚠️ Unknown event type: {event_type}")
                
        except Exception as e:
            logger.error(f"❌ Error processing presence message: {e}")
    
    def _is_device_for_this_environment(self, client_id: str) -> bool:
        """Check if device belongs to this environment"""
        try:
            environment = self.config.ENVIRONMENT
            
            # Pattern: {env}_nombre (e.g., dev_terminal_test, qa_terminal_test, prod_terminal_test)
            expected_prefix = f"{environment}_"
            
            if client_id.startswith(expected_prefix):
                logger.debug(f"✅ Device {client_id} matches environment {environment}")
                return True
            else:
                logger.debug(f"❌ Device {client_id} does not match environment {environment} (expected prefix: {expected_prefix})")
                return False
                
        except Exception as e:
            logger.error(f"❌ Error checking device environment: {e}")
            return False
    
    def _handle_device_connected(self, client_id: str, timestamp: str) -> None:
        """Handle device connected event"""
        try:
            # Update device status to online (async call from sync context)
            future = asyncio.run_coroutine_threadsafe(
                self.device_manager.update_device_status(
                    client_id=client_id,
                    is_online=True,
                    connection_status="connected"
                ),
                self.event_loop
            )
            
            # Wait for the async operation to complete
            future.result(timeout=5.0)
            
            logger.info(f"🟢 Device {client_id} connected")
            
        except Exception as e:
            logger.error(f"❌ Error handling device connected: {e}")
    
    def _handle_device_disconnected(self, client_id: str, timestamp: str) -> None:
        """Handle device disconnected event"""
        try:
            # Update device status to offline (async call from sync context)
            future = asyncio.run_coroutine_threadsafe(
                self.device_manager.update_device_status(
                    client_id=client_id,
                    is_online=False,
                    connection_status="disconnected"
                ),
                self.event_loop
            )
            
            # Wait for the async operation to complete
            future.result(timeout=5.0)
            
            logger.info(f"🔴 Device {client_id} disconnected")
            
        except Exception as e:
            logger.error(f"❌ Error handling device disconnected: {e}")
