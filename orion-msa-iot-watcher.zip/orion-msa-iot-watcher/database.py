"""
Database models for Watcher microservice
"""

from datetime import datetime
from sqlalchemy import Column, String, Boolean, DateTime, Text, Index, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

# Create metadata with cloud schema
metadata = MetaData(schema="cloud")
Base = declarative_base(metadata=metadata)

class DeviceMappingTable(Base):
    """Mapping between WSNo and ClientID"""
    __tablename__ = "bt_thing_mapping"
    
    ws_no = Column("WSNo", String(50), primary_key=True, nullable=False)
    thing_name = Column("thing_name", String(100), nullable=False)
    created_at = Column("created_at", DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column("updated_at", DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    site_id = Column("SiteId", String(50), nullable=False)
    
    # Add indexes for better performance
    __table_args__ = (
        Index('idx_device_mapping_thing_name', 'thing_name'),
        Index('idx_device_mapping_ws_no', 'WSNo'),
    )

class DeviceStatusTable(Base):
    """Current status of IoT devices"""
    __tablename__ = "bt_device_status"
    
    client_id = Column("client_id", String(100), primary_key=True, nullable=False)
    is_online = Column("is_online", Boolean, default=False, nullable=False)
    last_seen = Column("last_seen", DateTime, default=datetime.utcnow, nullable=False)
    connection_status = Column("connection_status", String(20), default="offline", nullable=False)
    last_presence_event = Column("last_presence_event", String(20), nullable=True)
    metadata_json = Column("metadata_json", Text, nullable=True)
    
    # Add indexes for better performance
    __table_args__ = (
        Index('idx_device_status_client_id', 'client_id'),
        Index('idx_device_status_is_online', 'is_online'),
        Index('idx_device_status_last_seen', 'last_seen'),
    )

class DeviceStatusHistory(Base):
    """Historical device status changes"""
    __tablename__ = "device_status_history"
    
    id = Column(String(36), primary_key=True)  # UUID
    client_id = Column(String(100), nullable=False)
    ws_no = Column(String(50), nullable=False)
    event_type = Column(String(20), nullable=False)  # "connected", "disconnected", "timeout"
    timestamp = Column(DateTime, default=datetime.now, nullable=False)
    metadata_json = Column(Text, nullable=True)
    
    # Add indexes for better performance
    __table_args__ = (
        Index('idx_status_history_client_id', 'client_id'),
        Index('idx_status_history_timestamp', 'timestamp'),
        Index('idx_status_history_ws_no_timestamp', 'ws_no', 'timestamp'),
    )