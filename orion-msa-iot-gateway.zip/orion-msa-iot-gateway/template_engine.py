"""
Simple Template Engine for Gateway Microservice
Generates timeout responses using existing templates
"""

import json
import os
from datetime import datetime
from typing import Dict, Any, Optional

class GatewayTemplateEngine:
    """Simple template engine for gateway timeout responses"""
    
    def __init__(self, templates_dir: str = "./templates"):
        self.templates_dir = templates_dir
        self.template_cache = {}
    
    def generate_timeout_response(self, request_body: Dict[str, Any], endpoint_type: str) -> Dict[str, Any]:
        """Generate timeout response using template structure"""
        try:
            # Extract code from request
            code = str(request_body.get("code", "default"))
            
            # Try to find a timeout template
            timeout_template = self._load_template("timeout")
            
            if timeout_template:
                # Process the template with request data
                response = self._process_template(timeout_template, request_body, endpoint_type)
                return response
            else:
                # Fallback to generic timeout response
                return self._generate_generic_timeout_response(request_body, endpoint_type)
                
        except Exception as e:
            print(f"Error generating timeout response: {e}")
            return self._generate_generic_timeout_response(request_body, endpoint_type)
    
    def generate_error_response(self, request_body: Dict[str, Any], endpoint_type: str, error_message: str = None) -> Dict[str, Any]:
        """Generate error response using template structure"""
        try:
            # Extract code from request
            code = str(request_body.get("code", "default"))
            
            # Try to find an error template
            error_template = self._load_template("error")
            
            if error_template:
                # Process the template with request data
                response = self._process_template(error_template, request_body, endpoint_type)
                
                # Override error message if provided
                if error_message:
                    response["dataCommand"]["errorMessage"] = error_message
                
                return response
            else:
                # Fallback to generic error response
                return self._generate_generic_error_response(request_body, endpoint_type, error_message)
                
        except Exception as e:
            print(f"Error generating error response: {e}")
            return self._generate_generic_error_response(request_body, endpoint_type, error_message)
    
    def _load_template(self, template_type: str) -> Optional[Dict[str, Any]]:
        """Load template for specific type (timeout, error, or default)"""
        cache_key = f"{template_type}"
        
        if cache_key in self.template_cache:
            return self.template_cache[cache_key]
        
        # Try to find a template in gateway's own template directory
        template_path = os.path.join(self.templates_dir, f"{template_type}.json")
        
        if os.path.exists(template_path):
            try:
                with open(template_path, 'r', encoding='utf-8') as f:
                    template = json.load(f)
                    self.template_cache[cache_key] = template
                    return template
            except Exception as e:
                print(f"Error loading template {template_path}: {e}")
        
        return None
    
    def _process_template(self, template: Dict[str, Any], request_body: Dict[str, Any], endpoint_type: str) -> Dict[str, Any]:
        """Process template with request data"""
        # Convert template to string for processing
        template_str = json.dumps(template)
        
        # Process field echoing
        processed_str = self._process_field_echoing(template_str, request_body)
        
        # Process timestamp formatting
        processed_str = self._process_timestamps(processed_str)
        
        # Convert back to dict
        response = json.loads(processed_str)
        
        # Ensure proper field names based on endpoint type
        if endpoint_type == "opi":
            if "transactionFolio" in response:
                response["UUID"] = response.pop("transactionFolio")
        else:
            if "UUID" in response:
                response["transactionFolio"] = response.pop("UUID")
        
        return response
    
    def _process_field_echoing(self, template_str: str, request_body: Dict[str, Any]) -> str:
        """Process field echoing patterns like [field] or [nested.field]"""
        import re
        
        def replace_field(match):
            field_path = match.group(1)
            
            # Skip timestamp patterns
            if field_path.startswith('timestamp:'):
                return match.group(0)
            
            # Handle nested fields
            if '.' in field_path:
                parts = field_path.split('.')
                value = request_body
                for part in parts:
                    if isinstance(value, dict) and part in value:
                        value = value[part]
                    else:
                        return "null"
                return str(value) if value is not None else "null"
            
            # Handle simple fields
            if field_path in request_body:
                value = request_body[field_path]
                return str(value) if value is not None else "null"
            
            return "null"
        
        return re.sub(r'\[([^\]]+)\]', replace_field, template_str)
    
    def _process_timestamps(self, template_str: str) -> str:
        """Process timestamp formatting patterns"""
        import re
        
        now = datetime.now()
        
        def replace_timestamp(match):
            timestamp_type = match.group(1)
            format_spec = match.group(2) if match.group(2) else ""
            
            if timestamp_type == "iso":
                return now.isoformat() + "Z"
            elif timestamp_type == "date":
                if format_spec == "DDMMYY":
                    return now.strftime("%d%m%y")
                else:
                    return now.strftime("%Y-%m-%d")
            elif timestamp_type == "time":
                if format_spec == "HHMMSS":
                    return now.strftime("%H%M%S")
                else:
                    return now.strftime("%H:%M:%S")
            
            return now.isoformat()
        
        return re.sub(r'\[timestamp:([^:\]]+)(?::([^\]]+))?\]', replace_timestamp, template_str)
    
    def _generate_generic_timeout_response(self, request_body: Dict[str, Any], endpoint_type: str) -> Dict[str, Any]:
        """Generate generic timeout response if no template is found"""
        response = {
            "code": request_body.get("code", "unknown"),
            "stateId": "response",
            "endpointType": request_body.get("endpointType", "transaction"),
            "requestStatus": "ERROR",
            "transactionStatus": "NOT_PROCESSED",
            "timestamp": datetime.now().isoformat() + "Z",
            "dataCommand": {
                "responseCode": "99",
                "responseMessage": "Proceso fallido",
                "errorCode": "990016",
                "errorMessage": "Tiempo de espera agotado",
                "suggestQuery": True
            }
        }
        
        # Add proper ID field based on endpoint type
        if endpoint_type == "opi":
            response["UUID"] = request_body.get("UUID") or request_body.get("transactionFolio")
        else:
            response["transactionFolio"] = request_body.get("transactionFolio") or request_body.get("UUID")
        
        # Add other fields if available
        for field in ["siteId", "wsNo", "posInfo", "sequenceNo", "thingId"]:
            if field in request_body:
                response[field] = request_body[field]
        
        return response
    
    def _generate_generic_error_response(self, request_body: Dict[str, Any], endpoint_type: str, error_message: str = None) -> Dict[str, Any]:
        """Generate generic error response if no template is found"""
        response = {
            "code": request_body.get("code", "unknown"),
            "stateId": "response",
            "endpointType": request_body.get("endpointType", "transaction"),
            "requestStatus": "ERROR",
            "transactionStatus": "NOT_PROCESSED",
            "timestamp": datetime.now().isoformat() + "Z",
            "dataCommand": {
                "responseCode": "99",
                "responseMessage": "Proceso fallido",
                "errorCode": "990017",
                "errorMessage": error_message or "Error interno del sistema",
                "suggestQuery": True
            }
        }
        
        # Add proper ID field based on endpoint type
        if endpoint_type == "opi":
            response["UUID"] = request_body.get("UUID") or request_body.get("transactionFolio")
        else:
            response["transactionFolio"] = request_body.get("transactionFolio") or request_body.get("UUID")
        
        # Add other fields if available
        for field in ["siteId", "wsNo", "posInfo", "sequenceNo", "thingId"]:
            if field in request_body:
                response[field] = request_body[field]
        
        return response
