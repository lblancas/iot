#!/usr/bin/env python3
"""
Gateway Manager - Handles RabbitMQ connections and operations
"""

import logging
from typing import Dict, Any, Optional
from config import config

# Import RabbitMQ client
from rabbitmq_gateway_client import GatewayRabbitMQClient

logger = logging.getLogger(__name__)

class GatewayManager:
    """
    Manages RabbitMQ connections and operations
    """
    
    def __init__(self):
        self.rabbitmq_client: Optional[GatewayRabbitMQClient] = None
        logger.info("🔧 Gateway Manager initialized with RabbitMQ")
    
    async def initialize(self) -> None:
        """Initialize RabbitMQ client"""
        try:
            secrets = config.get_secrets()
            
            # Initialize RabbitMQ client with secrets
            rabbitmq_host = secrets.get("rabbitmq_host")
            rabbitmq_env = secrets.get("rabbitmq_environment", "dev")
            
            if not rabbitmq_host:
                raise ValueError("rabbitmq_host not found in secrets")
            
            self.rabbitmq_client = GatewayRabbitMQClient(
                rabbitmq_host=rabbitmq_host,
                environment=rabbitmq_env
            )
            await self.rabbitmq_client.initialize()
            logger.info("✅ RabbitMQ client initialized")
                
        except Exception as e:
            logger.error(f"❌ Failed to initialize Gateway Manager: {e}")
            raise
    
    async def send_to_watcher(self, payload: Dict[str, Any]) -> None:
        """Send message to watcher service"""
        await self.rabbitmq_client.send_to_watcher(payload)
    
    async def send_to_workflow(self, payload: Dict[str, Any]) -> None:
        """Send message directly to workflow service"""
        await self.rabbitmq_client.send_to_workflow(payload)
    
    async def send_to_state_handler(self, payload: Dict[str, Any]) -> None:
        """Send message to state handler service"""
        await self.rabbitmq_client.send_to_state_handler(payload)
    
    async def wait_for_response(
        self, 
        transaction_folio: str, 
        timeout_seconds: Optional[int] = None,
        card_present: bool = False
    ) -> Optional[Dict[str, Any]]:
        """Wait for response from RabbitMQ"""
        return await self.rabbitmq_client.wait_for_response(
            transaction_folio, 
            timeout_seconds or (90 if card_present else 30),
            card_present
        )
    
    async def handle_late_response(self, transaction_folio: str, response: Dict[str, Any]) -> None:
        """Handle late responses"""
        await self.rabbitmq_client.handle_late_response(transaction_folio, response)
    
    async def health_check(self) -> bool:
        """Check RabbitMQ health"""
        try:
            return await self.rabbitmq_client.health_check()
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def disconnect(self) -> None:
        """Disconnect from RabbitMQ"""
        try:
            if self.rabbitmq_client:
                await self.rabbitmq_client.disconnect()
            logger.info("🔌 RabbitMQ client disconnected")
            
        except Exception as e:
            logger.error(f"Error disconnecting from RabbitMQ: {e}")

# Global gateway manager instance
gateway_manager: Optional[GatewayManager] = None

def get_gateway_manager() -> GatewayManager:
    """Get or create gateway manager singleton"""
    global gateway_manager
    if gateway_manager is None:
        gateway_manager = GatewayManager()
    return gateway_manager