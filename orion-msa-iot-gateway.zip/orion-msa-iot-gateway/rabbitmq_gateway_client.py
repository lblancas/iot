#!/usr/bin/env python3
"""
RabbitMQ Gateway Client
Handles message publishing and response waiting for Gateway service
"""

import asyncio
import json
import logging
import uuid
import os
from datetime import datetime
from typing import Dict, Any, Optional, Callable
import threading

# Import our RabbitMQ client (now local to gateway service)
from rabbitmq_client import RabbitMQClient, RabbitMQConfig

logger = logging.getLogger(__name__)

class GatewayRabbitMQClient:
    """RabbitMQ client specifically designed for Gateway service"""
    
    def __init__(self, rabbitmq_host: str, environment: str = "dev"):
        self.config = RabbitMQConfig(
            host=rabbitmq_host,
            environment=environment
        )
        self.client = RabbitMQClient(self.config)
        self._response_handlers: Dict[str, asyncio.Future] = {}
        self._consuming = False
        self._consumer_task: Optional[asyncio.Task] = None
        
        # Generate unique queue name for this gateway instance (for horizontal scaling)
        pod_name = os.getenv("HOSTNAME", f"gateway-{uuid.uuid4().hex[:8]}")
        self._unique_queue_name = f"sps-{environment}-orion-queue-gateway-{pod_name}"
        
    async def initialize(self) -> None:
        """Initialize connection and setup unique response queue for this gateway instance"""
        try:
            # Connect to RabbitMQ
            await self.client.connect()
            
            # Declare unique response queue for this gateway instance
            # Queue is auto-delete and exclusive to this connection for horizontal scaling
            self._response_queue = await self.client.declare_queue_with_name(
                self._unique_queue_name, 
                auto_delete=True,  # Queue deleted when connection closes
                exclusive=True     # Only this connection can access the queue
            )
            
            # Bind this unique queue to the gateway response topic
            # All gateway instances subscribe to same topic but have unique queues
            await self.client.bind_queue_to_topic(
                queue=self._response_queue,
                routing_key="orion.gateway.response"
            )
            
            # Start consuming responses from unique queue
            await self._start_response_consumer()
            
            logger.info(f"✅ Gateway RabbitMQ client initialized with unique queue: {self._unique_queue_name}")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Gateway RabbitMQ client: {e}")
            raise
    
    async def _start_response_consumer(self) -> None:
        """Start consuming response messages from unique queue"""
        try:
            # Use the queue object directly instead of service name to avoid duplicate declaration
            await self.client.consume_messages_from_queue(
                self._response_queue, 
                self._handle_response_message,
                queue_name=self._unique_queue_name,  # For logging purposes
                auto_ack=True  # Auto-acknowledge response messages to prevent infinite redelivery
            )
            self._consuming = True
            logger.info(f"🔄 Started consuming response messages from unique queue: {self._unique_queue_name}")
            
        except Exception as e:
            logger.error(f"❌ Failed to start response consumer: {e}")
            raise
    
    async def _handle_response_message(self, message: Dict[str, Any]) -> None:
        """Handle incoming response messages"""
        try:
            # Extract transaction identifier
            transaction_folio = message.get("transactionFolio") or message.get("UUID")
            
            if not transaction_folio:
                logger.warning("⚠️ Response message missing transaction identifier")
                return
            
            logger.info(f"📥 Received response for transaction: {transaction_folio}")
            
            # Find waiting handler
            if transaction_folio in self._response_handlers:
                future = self._response_handlers[transaction_folio]
                if not future.done():
                    future.set_result(message)
                    logger.info(f"✅ Delivered response for: {transaction_folio}")
                
                # Cleanup
                del self._response_handlers[transaction_folio]
            else:
                logger.warning(f"⚠️ No handler waiting for transaction: {transaction_folio}")
                
        except Exception as e:
            logger.error(f"❌ Error handling response message: {e}")
    
    async def send_to_watcher(self, payload: Dict[str, Any]) -> None:
        """Send message to watcher service"""
        try:
            await self.client.publish_message(
                routing_key="orion.watcher.request",
                message=payload
            )
            logger.info(f"📤 Sent message to watcher: {payload.get('transactionFolio', 'unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to watcher: {e}")
            raise
    
    async def send_to_workflow(self, payload: Dict[str, Any]) -> None:
        """Send message directly to workflow service"""
        try:
            await self.client.publish_message(
                routing_key="orion.workflow.request",
                message=payload
            )
            logger.info(f"📤 Sent message to workflow: {payload.get('transactionFolio', 'unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to workflow: {e}")
            raise
    
    async def send_to_state_handler(self, payload: Dict[str, Any]) -> None:
        """Send message to state handler service"""
        try:
            await self.client.publish_message(
                routing_key="orion.state-handler.update",
                message=payload
            )
            logger.info(f"📤 Sent message to state handler: {payload.get('transaction_folio', 'unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send to state handler: {e}")
            raise
    
    async def wait_for_response(
        self, 
        transaction_folio: str, 
        timeout_seconds: int = 30,
        card_present: bool = False
    ) -> Optional[Dict[str, Any]]:
        """
        Wait for response message with adaptive timeout
        """
        try:
            # Determine timeout based on card presence (like original SQS implementation)
            if timeout_seconds is None:
                timeout_seconds = 90 if card_present else 30
            
            logger.info(f"⏳ Waiting for response: {transaction_folio} (timeout: {timeout_seconds}s)")
            
            # Create future for this transaction
            future = asyncio.get_running_loop().create_future()
            self._response_handlers[transaction_folio] = future
            
            try:
                # Wait for response with timeout
                response = await asyncio.wait_for(future, timeout=timeout_seconds)
                logger.info(f"✅ Received response for: {transaction_folio}")
                return response
                
            except asyncio.TimeoutError:
                logger.error(f"⏱️ Timeout waiting for response: {transaction_folio}")
                return None
                
        except Exception as e:
            logger.error(f"❌ Error waiting for response {transaction_folio}: {e}")
            return None
            
        finally:
            # Cleanup handler
            if transaction_folio in self._response_handlers:
                del self._response_handlers[transaction_folio]
    
    async def handle_late_response(self, transaction_folio: str, response: Dict[str, Any]) -> None:
        """Handle responses that arrive after timeout (like original)"""
        try:
            logger.info(f"🕐 Processing late response for {transaction_folio}")
            
            # Send late response notification to state handler
            late_response_payload = {
                "transaction_folio": transaction_folio,
                "operation_type": "late-response",
                "current_step": "gateway",
                "status": "error", 
                "error_type": "LATE_RESPONSE",
                "original_response": response,
                "timestamp": datetime.now().isoformat()
            }
            
            await self.send_to_state_handler(late_response_payload)
            
        except Exception as e:
            logger.error(f"❌ Error handling late response for {transaction_folio}: {e}")
    
    async def health_check(self) -> bool:
        """Check if RabbitMQ connection is healthy"""
        try:
            return await self.client.health_check()
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def disconnect(self) -> None:
        """Close RabbitMQ connection"""
        try:
            # Stop consuming
            if self._consuming:
                await self.client.stop_consuming(self._unique_queue_name)
                self._consuming = False
            
            # Cancel consumer task
            if self._consumer_task and not self._consumer_task.done():
                self._consumer_task.cancel()
                try:
                    await self._consumer_task
                except asyncio.CancelledError:
                    pass
            
            # Disconnect client
            await self.client.disconnect()
            
            logger.info("🔌 Gateway RabbitMQ client disconnected")
            
        except Exception as e:
            logger.error(f"Error disconnecting Gateway client: {e}")

# Factory function for easier integration
def create_gateway_rabbitmq_client(rabbitmq_host: str, environment: str = "dev") -> GatewayRabbitMQClient:
    """Create and return Gateway RabbitMQ client"""
    return GatewayRabbitMQClient(rabbitmq_host, environment)