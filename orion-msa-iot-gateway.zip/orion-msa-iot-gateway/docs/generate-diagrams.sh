#!/bin/bash

# Script to generate SVG images from Mermaid diagrams

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}Starting diagram generation...${NC}"

# Create img directory if it doesn't exist
mkdir -p docs/img

# Generate SVG for each mermaid file
for file in docs/mmd/*.mmd; do
    if [ -f "$file" ]; then
        filename=$(basename "$file" .mmd)
        echo -e "${GREEN}Generating SVG for $filename...${NC}"
        mmdc -i "$file" -o "docs/img/${filename}.svg" -c docs/mermaid-config.json -b white
    fi
done

echo -e "${BLUE}All diagrams generated successfully!${NC}"
echo -e "${GREEN}SVG files are located in: docs/img/${NC}"