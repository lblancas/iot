# Gateway Templates

Este directorio contiene los templates de respuesta para el microservicio Gateway.

## Estructura

```
templates/
├── README.md
├── timeout.json          # Template de timeout
├── error.json            # Template de error
└── default.json          # Template por defecto
```

**Nota**: Gateway solo maneja 3 tipos de respuestas: timeout, error y default. No hay templates específicos por código.

## Tipos de Templates

### 1. Timeout Templates
- **Propósito**: Respuestas cuando se agota el tiempo de espera
- **Error Code**: `990016`
- **Error Message**: "Tiempo de espera agotado"

### 2. Error Templates
- **Propósito**: Respuestas cuando ocurre un error interno
- **Error Code**: `990017`
- **Error Message**: "Error interno del sistema"

### 3. Default Templates
- **Propósito**: Respuestas genéricas cuando no se encuentra template específico
- **Error Code**: `990000`
- **Error Message**: "Error no especificado"

## Variables de Template

Los templates soportan las siguientes variables:

### Campos del Request
- `[code]` - Código de la transacción
- `[endpointType]` - Tipo de endpoint (transaction, opi, command, notification)
- `[siteId]` - ID del sitio
- `[wsNo]` - Número de workstation
- `[posInfo]` - Información del POS
- `[sequenceNo]` - Número de secuencia
- `[thingId]` - ID del dispositivo IoT

### Timestamps
- `[timestamp:iso]` - Timestamp en formato ISO
- `[timestamp:date:DDMMYY]` - Fecha en formato DDMMYY
- `[timestamp:time:HHMMSS]` - Hora en formato HHMMSS

## Ejemplo de Uso

```python
# Generar respuesta de timeout
timeout_response = template_engine.generate_timeout_response(request_body, endpoint_type)

# Generar respuesta de error
error_response = template_engine.generate_error_response(request_body, endpoint_type, "Error específico")
```

## Orden de Búsqueda

El template engine busca templates directamente:

1. `{template_type}.json` - Template del tipo solicitado (timeout, error, default)

## Agregar Nuevos Templates

Para agregar un nuevo template:

1. Crear archivo de template: `templates/{template_type}.json`
2. Usar variables de template según sea necesario
3. El template se cargará automáticamente en el próximo request

**Tipos disponibles**: `timeout`, `error`, `default`
