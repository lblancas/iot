#!/usr/bin/env python3
"""
Gateway Microservice
Handles incoming requests from 4 endpoints and routes them via RabbitMQ
"""

import os
import sys
import json
import uuid
import asyncio
import logging
import threading
from datetime import datetime
from typing import Dict, Any, Optional
from contextlib import asynccontextmanager

import xmltodict
import uvloop
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from config import config
from models import (
    OPIRequest, TransactionRequest, CommandRequest, NotificationRequest, 
    HealthResponse
)
from performance_config import PerformanceConfig
from template_engine import GatewayTemplateEngine
from gateway_manager import get_gateway_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("orion-gateway")

# Template engine for timeout responses
template_engine = GatewayTemplateEngine()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage FastAPI lifespan events"""
    global gateway_manager
    
    # Startup
    try:
        # Initialize gateway manager in FastAPI event loop context
        gateway_manager = get_gateway_manager()
        await gateway_manager.initialize()
        logger.info("✅ Gateway manager initialized in FastAPI startup")
    except Exception as e:
        logger.error(f"❌ Failed to initialize gateway manager on startup: {e}")
        raise
    
    yield  # Run the application
    
    # Shutdown
    try:
        if gateway_manager:
            await gateway_manager.disconnect()
            logger.info("✅ Gateway manager disconnected on shutdown")
    except Exception as e:
        logger.error(f"❌ Error during gateway manager shutdown: {e}")

# FastAPI app with lifespan context manager
app = FastAPI(title="Gateway Microservice", version="1.0.0", lifespan=lifespan)

def _get_http_status_code(response: Dict[str, Any]) -> int:
    """
    Determine HTTP status code based on response requestStatus field
    - If requestStatus is 'SUCCESS': return 200
    - If requestStatus is 'ERROR' or 'FAILED': return 400
    - If requestStatus is empty, missing, or any other value: return 500
    """
    if not response:
        return 500
    
    # Check for specific error codes that indicate internal server errors FIRST
    # These should return 500 regardless of status field
    error_code = response.get("error_code", "").lower()
    if error_code in ["timeout", "late_response", "processing_error", "internal_error"]:
        return 500
    
    # Check for success status using requestStatus field (case insensitive)
    request_status = response.get("requestStatus")
    if request_status and request_status.upper() in ["SUCCESS", "SUCCESSFUL"]:
        return 200
    
    # Check for error status using requestStatus field
    if request_status and request_status.upper() in ["ERROR", "FAILED", "FAILURE"]:
        return 400
    
    # Return 500 for:
    # - Empty requestStatus field (requestStatus = "")
    # - Missing requestStatus field (requestStatus = None)
    # - Any other unknown requestStatus values
    return 500

def _create_json_response(response: Dict[str, Any]) -> JSONResponse:
    """
    Create JSONResponse with appropriate HTTP status code based on response content
    """
    status_code = _get_http_status_code(response)
    return JSONResponse(content=response, status_code=status_code)

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        service="gateway",
        timestamp=datetime.now(),
        version="1.0.0"
    )



# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/opi")
async def handle_opi(request: Request):
    """Handle OPI requests in XML format"""
    try:
        # Get XML body
        xml_body = await request.body()
        xml_content = xml_body.decode('utf-8')
        
        logger.info(f"Received OPI request: {xml_content[:200]}...")
        
        # Convert XML to JSON
        json_data = xmltodict.parse(xml_content)
        
        # Extract required fields
        payload_data = _extract_common_fields(json_data)
        
        # Create OPI request model
        opi_request = OPIRequest(
            **payload_data,
            xml_data=json_data
        )
        
        # Process request
        response = await _process_request(opi_request.model_dump(), "opi")
        return _create_json_response(response)
        
    except Exception as e:
        logger.error(f"Error processing OPI request: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/transaction")
async def handle_transaction(request: Request):
    """Handle transaction requests in JSON format"""
    # Capture start time when message is received
    execution_start = datetime.now()
    transaction_uuid = str(uuid.uuid4())
    
    try:
        # Parse payload directly (no intermediate serialization)
        raw_body = await request.body()
        raw_payload = json.loads(raw_body.decode())
        
        # Extract key fields directly (no Pydantic overhead)
        code = raw_payload.get("code")
        ws_no = raw_payload.get("wsNo", "unknown")
        site_id = raw_payload.get("siteId", "unknown")
        flag = raw_payload.get("flag","False")
        
        logger.info(f"📥 Request: code={code}, wsNo={ws_no}, siteId={site_id}, flag={flag}")
        
        # Build payload directly (no model_dump overhead)
        transaction_data = {
            **raw_payload,
            "transactionFolio": transaction_uuid,
            "stateId": "request"
        }
        
        # Remove any conflicting fields
        if "UUID" in transaction_data:
            del transaction_data["UUID"]
        
        logger.info(f"📤 Processing: code={code}, wsNo={ws_no}, siteId={site_id}, transactionFolio={transaction_uuid}, stateId=request")
        
        # FIRST: Process request (send to watcher/workflow) - MAIN ACTION
        response = await _process_request(transaction_data, "transaction")
        
        # SECOND: Send "request received" to state_handler - TRACKING
        await _send_to_state_handler_rabbitmq(
            transaction_uuid, code, "request", transaction_data, 
            execution_start, "success", "200", "Request received successfully"
        )
        
        logger.info(f"📋 Response received, sending final state_handler message")
        
        # SECOND: Send final response to state_handler
        if response.get("success", True):
            await _send_to_state_handler_rabbitmq(
                transaction_uuid, code, "response", response, 
                execution_start, "success", "200", "Response sent successfully"
            )
        else:
            error_code = response.get("error_code", "UNKNOWN_ERROR")  
            error_message = response.get("error_message", "Unknown error occurred")
            await _send_to_state_handler_rabbitmq(
                transaction_uuid, code, "response", response, 
                execution_start, "error", "500", f"Error: {error_code} - {error_message}"
            )
        
        return _create_json_response(response)
        
    except Exception as e:
        # Sanitize exception message to prevent log injection
        safe_error = str(e).replace('\n', ' ').replace('\r', ' ')[:200]
        logger.error(f"Error processing transaction request: {safe_error}")
        
        # Send error message to state_handler
        await _send_to_state_handler_rabbitmq(
            transaction_uuid, code, "request", raw_payload, 
            execution_start, "error", "500", f"Error processing request: {str(e)}"
        )
        
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/command")
async def handle_command(command: CommandRequest):
    """Handle command requests in JSON format"""
    # Capture start time when message is received
    execution_start = datetime.now()
    transaction_uuid = str(uuid.uuid4())
    
    try:
        # Get the command data and add transaction_folio
        command_data = command.model_dump(exclude_none=True)
        command_data["transaction_folio"] = transaction_uuid
        command_data["StateID"] = "request"
        
        # Use code as transactionType for commands
        transaction_type = command.code
        
        logger.info(f"Received command request: {command.wsNo} - {command.code}, UUID: {transaction_uuid}")
        
        # Send request received message to state_handler
        await _send_to_state_handler_rabbitmq(
            transaction_uuid, transaction_type, "request", command_data, 
            execution_start, "success", "200", "Request received successfully"
        )
        
        # Process request
        response = await _process_request(command_data, "command")
        
        # Send response message to state_handler based on response content
        if response.get("success", True):
            await _send_to_state_handler_rabbitmq(
                transaction_uuid, transaction_type, "response", response, 
                execution_start, "success", "200", "Response sent successfully"
            )
        else:
            error_code = response.get("error_code", "UNKNOWN_ERROR")
            error_message = response.get("error_message", "Unknown error occurred")
            await _send_to_state_handler_rabbitmq(
                transaction_uuid, transaction_type, "response", response, 
                execution_start, "error", "500", f"{error_code}: {error_message}"
            )
        
        return _create_json_response(response)
        
    except Exception as e:
        logger.error(f"Error processing command request: {e}")
        
        # Send error message to state_handler
        await _send_to_state_handler_rabbitmq(
            transaction_uuid, command.code, "request", command.model_dump(), 
            execution_start, "error", "500", f"Error processing request: {str(e)}"
        )
        
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/notification")
async def handle_notification(notification: NotificationRequest):
    """Handle notification requests in JSON format"""
    # Capture start time when message is received
    execution_start = datetime.now()
    transaction_uuid = str(uuid.uuid4())
    
    try:
        # Get the notification data and add transaction_folio
        notification_data = notification.model_dump(exclude_none=True)
        notification_data["transaction_folio"] = transaction_uuid
        notification_data["StateID"] = "request"
        
        # Ensure UUID field is not present for notification endpoint
        if "UUID" in notification_data:
            del notification_data["UUID"]
        
        logger.info(f"Received notification request: {notification.WSNo} - {notification.notification_type}, UUID: {transaction_uuid}")
        
        # Send request received message to state_handler
        await _send_to_state_handler_rabbitmq(
            transaction_uuid, notification.transactionType, "request", notification_data, 
            execution_start, "success", "200", "Request received successfully"
        )
        
        # Process request
        response = await _process_request(notification_data, "notification")
        
        # Send response message to state_handler based on response content
        if response.get("success", True):
            await _send_to_state_handler_rabbitmq(
                transaction_uuid, notification.transactionType, "response", response, 
                execution_start, "success", "200", "Response sent successfully"
            )
        else:
            error_code = response.get("error_code", "UNKNOWN_ERROR")
            error_message = response.get("error_message", "Unknown error occurred")
            await _send_to_state_handler_rabbitmq(
                transaction_uuid, notification.transactionType, "response", response, 
                execution_start, "error", "500", f"{error_code}: {error_message}"
            )
        
        return _create_json_response(response)
        
    except Exception as e:
        logger.error(f"Error processing notification request: {e}")
        
        # Send error message to state_handler
        await _send_to_state_handler_rabbitmq(
            transaction_uuid, notification.transactionType, "request", notification.model_dump(), 
            execution_start, "error", "500", f"Error processing request: {str(e)}"
        )
        
        raise HTTPException(status_code=500, detail=str(e))

# Global variables
gateway_manager = None  # Global gateway manager instance

async def _process_request(payload_data: Dict[str, Any], endpoint_type: str) -> Dict[str, Any]:
    """Process incoming request using gateway manager (RabbitMQ)"""
    global gateway_manager
    
    # Use transactionFolio if present, otherwise generate UUID
    transaction_uuid = payload_data.get("transactionFolio", str(uuid.uuid4()))
    
    try:
        # Use payload as-is (already cleaned in caller) and add required fields in camelCase
        enhanced_payload = {
            **payload_data,
            "transactionFolio": transaction_uuid,
            "stateId": "request",
            "endpointType": endpoint_type
        }
        
        # For opi endpoint, use UUID; for all others should already have transactionFolio
        if endpoint_type == "opi":
            enhanced_payload["UUID"] = transaction_uuid
            # Remove transactionFolio if present for opi
            if "transactionFolio" in enhanced_payload:
                del enhanced_payload["transactionFolio"]
        
        # CardPresent optimization: Single calculation for routing and timeout
        card_present_raw = enhanced_payload.get("dataTransaction", {}).get("cardPresent", "false")
        card_present_bool = card_present_raw.lower() == "true"
        
        # Force all traffic through watcher (testing flag)
        # Change this to True to force all traffic through watcher
        flag_value = enhanced_payload.get("flag", False)
        FORCE_WATCHER_MODE = flag_value is True or (isinstance(flag_value, str) and flag_value.lower() == "true")
        
        # COMMAND endpoint always goes to WATCHER (no cardPresent field)
        if endpoint_type == "command":
            logger.info(f"📤 COMMAND endpoint - Always sending to WATCHER")
            await gateway_manager.send_to_watcher(enhanced_payload)
            logger.info(f"📤 Sent to WATCHER - Command dispatched")
        elif FORCE_WATCHER_MODE:
            # Force all traffic through watcher (testing mode)
            logger.info(f"🧪 FORCE WATCHER MODE - All traffic goes through watcher")
            await gateway_manager.send_to_watcher(enhanced_payload)
            logger.info(f"📤 Sent to WATCHER - Message dispatched")
        elif card_present_raw == "false":
            # Direct to workflow bypass for cardPresent=false (optimization)
            logger.info(f"🚀 Bypass to WORKFLOW (cardPresent=false)")
            await gateway_manager.send_to_workflow(enhanced_payload)
        else:
            # Normal flow: Send to WATCHER
            await gateway_manager.send_to_watcher(enhanced_payload)
            logger.info(f"📤 Sent to WATCHER - Message dispatched")
        
        # Wait for response from RabbitMQ
        # For commands, use card_not_present timeout (shorter) since no user interaction
        if endpoint_type == "command":
            card_present_bool = False  # Commands don't have cardPresent, use shorter timeout
            logger.info(f"📤 COMMAND endpoint - Using card_not_present timeout")
        
        # RabbitMQ: Direct response waiting
        response = await gateway_manager.wait_for_response(
            transaction_uuid,
            timeout_seconds=None,  # Use adaptive timeout
            card_present=card_present_bool
        )
        
        if response:
            logger.info(f"Received response for {transaction_uuid}")
            # Return response as-is without adding status field
            return response
        else:
            # Determine timeout message based on card presence
            timeout_seconds = PerformanceConfig.CARD_PRESENT_TIMEOUT_SECONDS if card_present_bool else PerformanceConfig.CARD_NOT_PRESENT_TIMEOUT_SECONDS
            logger.error(f"Timeout waiting for response {transaction_uuid} (cardPresent={card_present_bool}, timeout={timeout_seconds}s)")
            # Generate timeout response using template engine
            timeout_response = template_engine.generate_timeout_response(enhanced_payload, endpoint_type)
            
            # Ensure proper ID field
            if endpoint_type == "opi":
                timeout_response["UUID"] = transaction_uuid
            else:
                timeout_response["transactionFolio"] = transaction_uuid
                
            return timeout_response
            
    except Exception as e:
        logger.error(f"Error processing request {transaction_uuid}: {e}")
        
        # Generate error response using template engine
        error_response = template_engine.generate_error_response(enhanced_payload, endpoint_type, str(e))
        
        # Override with processing error details
        error_response["dataCommand"]["errorCode"] = "990017"
        error_response["dataCommand"]["errorMessage"] = str(e)
        
        # Ensure proper ID field
        if endpoint_type == "opi":
            error_response["UUID"] = transaction_uuid
        else:
            error_response["transactionFolio"] = transaction_uuid
            
        return error_response

def _extract_common_fields(data: Dict[str, Any]) -> Dict[str, Any]:
    """Extract common fields from request data"""
    extracted = {
        "transactionType": "unknown",
        "SiteID": "unknown", 
        "WSNo": "unknown",
        "SequenceNo": "unknown"
    }
    
    def search_dict(d: Dict[str, Any], target_keys: set) -> Dict[str, Any]:
        """Recursively search for target keys in nested dictionary"""
        found = {}
        
        # Pre-compute lowercase target keys for O(1) lookup
        target_keys_lower = {tk.lower(): tk for tk in target_keys}
        
        if isinstance(d, dict):
            for key, value in d.items():
                # Direct key match (case insensitive) - O(1) lookup
                key_lower = key.lower()
                if key_lower in target_keys_lower:
                    # Get original target key
                    original_key = target_keys_lower[key_lower]
                    found[original_key] = value
                
                # Recursive search in nested dictionaries
                elif isinstance(value, dict):
                    nested_found = search_dict(value, target_keys)
                    found.update(nested_found)
        
        return found
    
    # Search for required fields
    target_keys = {"transactionType", "SiteID", "WSNo", "SequenceNo"}
    found_fields = search_dict(data, target_keys)
    
    # Update extracted with found fields
    extracted.update(found_fields)
    
    logger.debug(f"Extracted fields: {extracted}")
    return extracted

async def _handle_late_response(uuid: str, response_message: Dict[str, Any]):
    """Handle late responses that arrive after timeout"""
    try:
        logger.info(f"🕐 Processing late response for {uuid}")
        
        # Extract information from the late response
        code = response_message.get("code", "unknown")
        
        # Create error payload for late response
        error_payload = {
            "transaction_folio": uuid,
            "StateID": "response",
            "code": code,
            "error_type": "LATE_RESPONSE",
            "original_response": response_message
        }
        
        # Send to state_handler as error
        await _send_to_state_handler_rabbitmq(
            uuid, code, "response", error_payload, 
            datetime.now(), "error", "408", 
            f"Late response received after timeout for transaction {uuid}"
        )
        
        logger.info(f"📤 Late response error sent to state_handler for {uuid}")
        
    except Exception as e:
        logger.error(f"❌ Error handling late response for {uuid}: {e}")

async def _send_to_state_handler_rabbitmq(transaction_folio: str, code: str, state_id: str, 
                                         payload: Dict[str, Any], execution_start: datetime, 
                                         status: str, response_code: str, response_message: str):
    """Send message to state_handler using gateway manager (RabbitMQ preferred)"""
    global gateway_manager
    
    try:
        # Capture end time and calculate execution time
        execution_end = datetime.now()
        total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
        
        # Build operation_type like link does
        operation_type = f"{code}-{state_id}"
        
        # Create state handler payload (simplified for RabbitMQ)
        state_handler_payload = {
            "transaction_folio": transaction_folio,
            "operation_type": operation_type,
            "current_step": "gateway",
            "status": status,
            "payload": payload,
            "execution_start_time": execution_start.isoformat(),
            "execution_end_time": execution_end.isoformat(),
            "execution_total_time": str(int(total_execution_ms)),
            "response_code": response_code,
            "response_message": response_message
        }
        
        # Send using gateway manager (RabbitMQ)
        await gateway_manager.send_to_state_handler(state_handler_payload)
        
        logger.info(f"📤 Sent to state_handler via gateway manager")
        logger.info(f"📋 Message details - Transaction: {transaction_folio}, Operation: {operation_type}, Status: {status}")
        logger.info(f"⏱️ Execution time: {total_execution_ms:.2f}ms")
        
    except Exception as e:
        logger.error(f"Error sending to state_handler: {e}")

async def process_messages():
    """Main message processing loop with RabbitMQ"""
    global gateway_manager
    
    try:
        # Gateway manager is now initialized in FastAPI startup event
        logger.info("✅ RabbitMQ mode: Direct messaging enabled")
        logger.info("Starting message processing loop...")
        
        # Keep running (like link pattern)
        while True:
            await asyncio.sleep(1)
            
    except Exception as e:
        logger.error(f"Fatal error in process_messages: {e}")
        raise

# Main application entry point moved to __main__ section below

if __name__ == "__main__":
    try:
        # Configure uvloop for ultra-high performance async I/O (1.5-2x faster RabbitMQ operations)
        logger.info("🚀 Configuring uvloop for ultra-high performance Gateway...")
        asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
        logger.info("✅ uvloop configured - RabbitMQ and FastAPI operations will be 1.5-2x faster")
        
        # Run FastAPI directly with uvicorn (RabbitMQ initialized in startup event)
        logger.info(f"Starting Gateway Microservice on port {config.PORT}")
        uvicorn.run(app, host="0.0.0.0", port=config.PORT, log_level="info")
    except KeyboardInterrupt:
        logger.info("🛑 Gateway shutting down...")
    except Exception as e:
        logger.error(f"❌ Application error: {e}")
        sys.exit(1)