"""
Shared data models for SPS IoT microservices
"""

from datetime import datetime
from typing import Dict, Any, Optional
from pydantic import BaseModel
from enum import Enum

class StateID(str, Enum):
    REQUEST = "request"
    RESPONSE = "response"
    PROCESSING = "processing"
    ERROR = "error"

class EndpointType(str, Enum):
    OPI = "opi"
    TRANSACTION = "transaction"
    COMMAND = "command"
    NOTIFICATION = "notification"

class BaseMessage(BaseModel):
    UUID: str
    StateID: str
    transactionType: str
    SiteID: str
    WSNo: str
    SequenceNo: str
    timestamp: Optional[datetime] = None
    endpoint_type: Optional[str] = None

class RequestMessage(BaseModel):
    UUID: str
    StateID: str = "request"
    transactionType: str
    SiteID: str
    WSNo: str
    SequenceNo: str
    timestamp: Optional[datetime] = None
    endpoint_type: Optional[str] = None
    payload: Dict[str, Any] = {}

class ResponseMessage(BaseModel):
    UUID: str
    StateID: str = "response"
    success: bool = True
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    timestamp: Optional[datetime] = None
    data: Dict[str, Any] = {}

class DeviceStatus(BaseModel):
    WSNo: str
    ClientID: str
    is_online: bool
    last_seen: datetime
    connection_status: str

class OPIRequest(BaseModel):
    UUID: Optional[str] = None
    StateID: str = "request"
    transactionType: str
    SiteID: str
    WSNo: str
    SequenceNo: str
    timestamp: Optional[datetime] = None
    endpoint_type: str = "opi"
    xml_data: Dict[str, Any] = {}

class TransactionRequest(BaseModel):
    # Allow any additional fields beyond the required ones
    class Config:
        extra = "allow"
    
    StateID: str = "request"
    code: str  # Required field
    SequenceNo: Optional[str] = None  # Validate existence but not used
    endpoint_type: str = "transaction"
    
    # Extract required fields from anywhere in the JSON structure
    @property
    def transactionType(self) -> str:
        # Use code as transactionType
        return str(self.code)
    
    @property
    def SiteID(self) -> str:
        # Look for SiteId in root level or in dataTransaction
        data = self.__dict__
        if "dataTransaction" in data and isinstance(data["dataTransaction"], dict):
            print(f"🔍 dataTransaction.SiteId: {data['dataTransaction'].get('SiteId')}")
        
        if "SiteId" in data:
            return data["SiteId"]
        elif "dataTransaction" in data and isinstance(data["dataTransaction"], dict):
            return data["dataTransaction"].get("SiteId", "unknown")
        return data.get("SiteID", "unknown")
    
    @property
    def wsNo(self) -> str:
        # Look for wsNo in root level or in dataTransaction (camelCase)
        data = self.__dict__
        
        if "wsNo" in data:
            return data["wsNo"]
        elif "dataTransaction" in data and isinstance(data["dataTransaction"], dict):
            return data["dataTransaction"].get("wsNo", "unknown")
        # Fallback to old format
        elif "WSNo" in data:
            return data["WSNo"]
        return "unknown"

class CommandRequest(BaseModel):
    """Command request model - Only validates basic required fields"""
    class Config:
        extra = "allow"  # Allow any additional fields
    
    # Only these fields are required and validated
    code: str
    sequenceNo: str
    siteId: str
    wsNo: str
    posInfo: str
    
    # Optional fields with defaults
    thingId: Optional[str] = None  # Will be added by WATCHER after processing
    message: Optional[str] = None
    timestamp: Optional[datetime] = None
    
    # Optional fields with defaults
    message: Optional[str] = None
    timestamp: Optional[datetime] = None
    
    # These fields are not validated but can be present
    UUID: Optional[str] = None
    stateId: Optional[str] = None
    endpointType: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None

class NotificationRequest(BaseModel):
    """Notification request model"""
    WSNo: str
    notification_type: str
    transactionType: str
    payload: Dict[str, Any]
    timestamp: Optional[datetime] = None

class CommandResponse(BaseModel):
    """Command response model"""
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None
    error_code: Optional[str] = None

class StateHandlerMessage(BaseModel):
    """State handler message model"""
    transaction_folio: str
    operation_type: str
    current_step: str
    status: str
    payload: Dict[str, Any]
    execution_start_time: datetime
    execution_end_time: datetime
    execution_total_time: str
    response_code: str
    response_message: str

class WorkflowRequest(BaseModel):
    """Workflow request model"""
    uuid: str
    state_id: str
    code: str  # Changed from int to str
    endpoint_type: str
    payload: Dict[str, Any]

class WorkflowResponse(BaseModel):
    """Workflow response model"""
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None
    response_code: str

class LinkRequest(BaseModel):
    """Link request model"""
    uuid: str
    state_id: str
    code: str  # Changed from int to str
    endpoint_type: str
    payload: Dict[str, Any]

class LinkResponse(BaseModel):
    """Link response model"""
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None
    response_code: str

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str = "healthy"
    service: str = "gateway"
    timestamp: datetime
    version: str = "1.0.0"