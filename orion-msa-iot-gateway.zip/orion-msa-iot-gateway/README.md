# Orion MSA IoT Gateway 🚪

Microservicio Gateway para el sistema Orion IoT que actúa como punto de entrada único para las solicitudes IoT, enrutando mensajes a través de RabbitMQ hacia los microservicios correspondientes.

## Tecnologías 🚀

- **Python**: 3.11+
- **FastAPI**: 0.104.1 - Framework web moderno y de alto rendimiento
- **Uvicorn**: 0.24.0 - Servidor ASGI de alto rendimiento con soporte para uvloop
- **Pydantic**: 2.5.0 - Validación de datos usando Python type hints
- **RabbitMQ**: Sistema de mensajería para comunicación asíncrona
  - aio-pika: 9.3.0+ - Cliente RabbitMQ asíncrono
  - aiormq: 6.7.0+ - Driver AMQP para Python asyncio
- **AWS SDK (boto3)**: 1.34.0
  - AWS Secrets Manager para gestión segura de credenciales
- **uvloop**: 0.17.0+ - Implementación más rápida del event loop de asyncio
- **Herramientas adicionales**:
  - xmltodict: 0.13.0 - Procesamiento de XML
  - python-dotenv: 1.0.0 - Gestión de variables de entorno
  - aiohttp: 3.8.0+ - Cliente HTTP asíncrono
  - prometheus-client: 0.17.0+ - Métricas y monitoreo

## Estructura del Proyecto 📁

```
orion-msa-iot-gateway/
├── __pycache__/             # Cache de Python compilado
├── templates/               # Plantillas para respuestas
├── main.py                  # Aplicación principal FastAPI con endpoints
├── config.py                # Configuración y gestión de secretos AWS
├── models.py                # Modelos de datos Pydantic
├── gateway_manager.py       # Gestor principal del gateway
├── rabbitmq_client.py       # Cliente base de RabbitMQ
├── rabbitmq_gateway_client.py # Cliente específico para gateway
├── template_engine.py       # Motor de plantillas para respuestas
├── performance_config.py    # Configuración de rendimiento
├── requirements.txt         # Dependencias del proyecto
├── Dockerfile              # Definición de imagen Docker
├── docker-compose.yml      # Orquestación de contenedores
├── .env                    # Variables de entorno
└── docs/
    └── mmd/               # Diagramas de secuencia Mermaid
```

## Instalación y Configuración 🛠️

### Prerrequisitos

- Python 3.11+
- pip (gestor de paquetes de Python)
- Acceso a instancia RabbitMQ
- Credenciales AWS configuradas (para ambientes cloud)

### Configuración Local

1. Clonar el repositorio:
```bash
git clone <repository-url>
cd orion-msa-iot-gateway
```

2. Crear entorno virtual:
```bash
python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate
```

3. Instalar dependencias:
```bash
pip install -r requirements.txt
```

4. Configurar variables de entorno en `.env`:
```bash
AWS_REGION=us-east-1
AWS_SECRET_NAME=sps-dev-orion-secret-iot-gateway
ENVIRONMENT=local  # o aws para ambientes cloud
PORT=40080

# Para desarrollo local
RABBITMQ_HOST=localhost
RABBITMQ_USERNAME=guest
RABBITMQ_PASSWORD=guest
RABBITMQ_ENVIRONMENT=dev
```

5. Ejecutar el servicio:
```bash
# Desarrollo con recarga automática
uvicorn main:app --reload --port 40080

# Producción con uvloop
python main.py
```

### Configuración para Ambientes Cloud

**IMPORTANTE**: Los ambientes `dev`, `qa`, `sbx` y `prod` utilizan **AWS Secrets Manager** para obtener las credenciales de forma segura. Las credenciales no se almacenan en archivos de configuración.

El secreto en AWS Secrets Manager debe contener:
```json
{
  "rabbitmq_host": "host-rabbitmq",
  "rabbitmq_username": "usuario",
  "rabbitmq_password": "contraseña",
  "rabbitmq_environment": "dev|qa|sbx|prod"
}
```

Para ejecutar en ambientes cloud:
```bash
# Configurar variable de entorno
export ENVIRONMENT=aws
export AWS_SECRET_NAME=sps-{env}-orion-secret-iot-gateway

# Ejecutar servicio
python main.py
```

### Permisos IAM Necesarios

Para ejecutar en ambientes cloud, el rol/usuario IAM debe tener permisos para:
- `secretsmanager:GetSecretValue` - Para obtener credenciales desde AWS Secrets Manager
- `secretsmanager:DescribeSecret` - Para describir el secreto
- Acceso a los recursos de red necesarios (VPC, Security Groups) para conectar con RabbitMQ

### Ejecución con Docker

```bash
# Construir imagen
docker build -t orion-gateway .

# Ejecutar con docker-compose
docker-compose up -d

# Ver logs
docker-compose logs -f gateway
```

## Configuración 🔧

### Variables de Entorno

| Variable | Descripción | Valor por defecto |
|----------|-------------|-------------------|
| `ENVIRONMENT` | Ambiente de ejecución (local/aws) | local |
| `PORT` | Puerto del servicio | 40080 |
| `AWS_REGION` | Región de AWS | us-east-1 |
| `AWS_SECRET_NAME` | Nombre del secreto en AWS Secrets Manager | sps-dev-orion-secret-iot-gateway |
| `RABBITMQ_HOST` | Host de RabbitMQ (solo local) | localhost |
| `RABBITMQ_USERNAME` | Usuario RabbitMQ (solo local) | guest |
| `RABBITMQ_PASSWORD` | Contraseña RabbitMQ (solo local) | guest |
| `RABBITMQ_ENVIRONMENT` | Ambiente RabbitMQ | dev |

## Documentación API 📚

### Swagger UI
- http://localhost:40080/docs

### OpenAPI Specification
- http://localhost:40080/openapi.json

### ReDoc
- http://localhost:40080/redoc

## Endpoints Principales 🛡️

### Health Check

| Método | Path | Descripción |
|--------|------|-------------|
| GET | `/health` | Verificar estado del servicio |

**Respuesta exitosa:**
```json
{
  "status": "healthy",
  "service": "gateway",
  "timestamp": "2024-01-01T12:00:00",
  "version": "1.0.0"
}
```

### OPI Endpoint

| Método | Path | Descripción |
|--------|------|-------------|
| POST | `/opi` | Procesar solicitudes OPI en formato XML |

**Características:**
- Acepta contenido XML
- Convierte XML a JSON internamente
- Enruta a través de RabbitMQ al servicio correspondiente

### Transaction Endpoint

| Método | Path | Descripción |
|--------|------|-------------|
| POST | `/transaction` | Procesar transacciones en formato JSON |

**Características:**
- Procesamiento optimizado para alto rendimiento
- Genera UUID único para cada transacción
- Tracking completo del estado de la transacción
- Envío de mensajes a state_handler para auditoría

**Campos requeridos:**
- `code`: Código de la transacción
- `wsNo`: Número de estación de trabajo
- `siteId`: Identificador del sitio
- `flag`: Bandera de procesamiento

### Command Endpoint

| Método | Path | Descripción |
|--------|------|-------------|
| POST | `/command` | Procesar comandos del sistema |

**Campos requeridos:**
- `code`: Código del comando
- `sequenceNo`: Número de secuencia
- `siteId`: Identificador del sitio
- `wsNo`: Número de estación de trabajo
- `posInfo`: Información del punto de venta

### Notification Endpoint

| Método | Path | Descripción |
|--------|------|-------------|
| POST | `/notification` | Procesar notificaciones del sistema |

**Campos requeridos:**
- `WSNo`: Número de estación de trabajo
- `notification_type`: Tipo de notificación
- `transactionType`: Tipo de transacción
- `payload`: Datos de la notificación

## Health Check 🏥

### Endpoint de Estado
- **URL**: `/health`
- **Método**: GET
- **Respuesta**: Estado del servicio, versión y timestamp

El endpoint de health check verifica:
- Estado del servicio FastAPI
- Conectividad (implícita al responder)
- Información de versión

## Llamar al servicio como integrador
```json
curl https://api.{enviroment}.stg.smartpayment.com.mx/iot-gateway/transaction \
--request POST \
--header 'Content-Type: application/json' \
--header 'X-API-Key: {api-key}' \
--data '{
  "code": "1001",
  "sequenceNo": "87654321",
  "siteId": "COM001|SUC001",
  "wsNo": "POS026",
  "posInfo": "TEAMWORKS|V1.04",
  "dataTransaction": {
    "transAmount": "3010.00",
    "tipAmount": "0.00",
    "tipOnPinpad": "true",
    "promoOnPinpad": "true",
    "transCurrency": "484",
    "cardPresent": "true"
  }
}'
```

## Interacción con Servicios Externos 🔗

### RabbitMQ

El gateway se comunica con RabbitMQ para:
- **Publicación de mensajes**: Envía solicitudes a las colas correspondientes
- **Consumo de respuestas**: Recibe respuestas de los microservicios
- **Gestión de timeouts**: Maneja respuestas tardías y timeouts

**Colas utilizadas:**
- `sps-{env}-orion-queue-gateway-{pod_name}`: Cola única por instancia para respuestas
- `sps-{env}-orion-queue-watcher`: Cola para el servicio watcher
- `sps-{env}-orion-queue-workflow`: Cola para el servicio workflow
- `sps-{env}-orion-queue-link`: Cola para el servicio link
- `sps-{env}-orion-queue-state-handler`: Cola para tracking de estado

**Exchanges:**
- `sps-{env}-orion-dlx`: Dead Letter Exchange para mensajes no procesados

### AWS Secrets Manager

Utilizado en ambientes cloud para:
- Obtención segura de credenciales de RabbitMQ
- Gestión centralizada de secretos
- Rotación automática de credenciales (cuando está configurada)

## Performance y Optimización 🚀

### Configuraciones de Rendimiento

El servicio utiliza `uvloop` para mejorar el rendimiento del event loop de asyncio, proporcionando:
- Mayor throughput en operaciones I/O
- Menor latencia en el procesamiento de mensajes
- Mejor utilización de recursos del sistema

### Timeouts Configurables

- **Request timeout**: 15 segundos (configurable)
- **Connection pool**: Gestión automática de conexiones RabbitMQ
- **Retry logic**: Reintentos automáticos en caso de fallas de conexión

### Manejo de Concurrencia

- Procesamiento asíncrono de todas las solicitudes
- Pool de conexiones para RabbitMQ
- Gestión eficiente de corrutinas con asyncio

## Testing 🧪

### Ejecutar Tests
```bash
# Tests unitarios
pytest tests/

# Tests con cobertura
pytest --cov=. tests/

# Tests específicos
pytest tests/test_main.py -v
```

### Tests de Carga
```bash
# Usando locust
locust -f tests/load_test.py --host=http://localhost:40080

# Usando Apache Bench
ab -n 1000 -c 10 http://localhost:40080/health
```

## Diagramas 📊

Los diagramas de secuencia en formato Mermaid se encuentran en `/docs/mmd/`:

### Diagramas Disponibles

1. **01-health-check.mmd** - Flujo del endpoint de health check
   - Verificación del estado del servicio
   - Respuesta con información de salud

2. **02-opi-flow.mmd** - Procesamiento de solicitudes OPI
   - Conversión de XML a JSON
   - Enrutamiento a través de RabbitMQ
   - Manejo de respuestas síncronas

3. **03-transaction-flow.mmd** - Flujo completo de transacciones
   - Generación de UUID único
   - Procesamiento paralelo con state tracking
   - Integración con Watcher y Workflow

4. **04-command-flow.mmd** - Procesamiento de comandos
   - Validación de campos requeridos
   - Enrutamiento a Link cuando es necesario
   - Tracking de estado completo

5. **05-notification-flow.mmd** - Flujo de notificaciones
   - Procesamiento por tipo de notificación
   - Priorización de notificaciones críticas
   - Auditoría y tracking

6. **06-rabbitmq-integration.mmd** - Arquitectura de integración con RabbitMQ
   - Conexión y configuración inicial
   - Declaración de exchanges y colas
   - Patrón de publicación/suscripción

7. **07-error-handling.mmd** - Manejo de errores y recuperación
   - Estrategias de timeout
   - Dead Letter Exchange
   - Patrones de reintentos y circuit breaker

8. **08-state-handler-tracking.mmd** - Tracking de estado de transacciones
   - Auditoría completa de transacciones
   - Almacenamiento en base de datos
   - Cálculo de tiempos de ejecución

9. **09-aws-secrets-integration.mmd** - Integración con AWS Secrets Manager
   - Obtención segura de credenciales
   - Manejo de ambientes (local vs cloud)
   - Consideraciones de seguridad

10. **10-performance-optimization.mmd** - Optimizaciones de rendimiento
    - Uso de uvloop para mejor performance
    - Procesamiento asíncrono concurrente
    - Connection pooling y caching

## Monitoreo y Logs 📈

### Logs

El servicio genera logs estructurados con los siguientes niveles:
- **INFO**: Operaciones normales
- **WARNING**: Situaciones que requieren atención
- **ERROR**: Errores que no detienen el servicio
- **CRITICAL**: Errores críticos del sistema

### Métricas Prometheus

Cuando está configurado, el servicio expone métricas en:
- `/metrics` - Métricas de Prometheus

Métricas disponibles:
- Número de requests por endpoint
- Tiempos de respuesta
- Errores y timeouts
- Estado de conexiones RabbitMQ

## Troubleshooting 🔧

### Problemas Comunes

1. **Error de conexión a RabbitMQ**
   - Verificar credenciales en AWS Secrets Manager o variables de entorno
   - Confirmar que el servicio RabbitMQ está activo
   - Revisar configuración de red/firewall

2. **Timeouts en respuestas**
   - Ajustar configuración de timeout en `performance_config.py`
   - Verificar carga del sistema
   - Revisar logs de los microservicios downstream

3. **Error al obtener secretos de AWS**
   - Verificar permisos IAM
   - Confirmar nombre correcto del secreto
   - Validar región de AWS

## Contacto y Soporte 📞

Para soporte o preguntas sobre este microservicio, contactar al equipo de desarrollo de Orion IoT.