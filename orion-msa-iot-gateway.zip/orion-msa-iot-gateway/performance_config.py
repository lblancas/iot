"""
Performance Configuration for Gateway Microservice
Centralized configuration for performance parameters
"""

import os

class PerformanceConfig:
    """Performance configuration for gateway microservice"""
    
    # Response Configuration - Adaptativo para diferentes escenarios
    RESPONSE_TIMEOUT_SECONDS = int(os.getenv("RESPONSE_TIMEOUT_SECONDS", "90"))  # 90s para terminales físicas
    RESPONSE_POLLING_INTERVAL = int(os.getenv("RESPONSE_POLLING_INTERVAL", "1"))  # Poll cada 1 segundo
    
    # Timeout configuration based on card presence - Optimized for uvloop performance
    CARD_NOT_PRESENT_TIMEOUT_SECONDS = int(os.getenv("CARD_NOT_PRESENT_TIMEOUT_SECONDS", "6"))   # 6s para cardPresent=false (optimized with uvloop)
    CARD_PRESENT_TIMEOUT_SECONDS = int(os.getenv("CARD_PRESENT_TIMEOUT_SECONDS", "90"))  # 90s para cardPresent=true (terminal físico)
    
    # RabbitMQ Configuration - Ultra-optimized for uvloop low latency
    RABBITMQ_CONNECTION_TIMEOUT = int(os.getenv("RABBITMQ_CONNECTION_TIMEOUT", "20"))    # Reduced from 30s (uvloop faster connections)
    RABBITMQ_HEARTBEAT = int(os.getenv("RABBITMQ_HEARTBEAT", "45"))                      # Reduced from 60s (uvloop efficiency)
    RABBITMQ_BLOCKED_CONNECTION_TIMEOUT = int(os.getenv("RABBITMQ_BLOCKED_CONNECTION_TIMEOUT", "200"))  # Reduced from 300s
    
    # Logging Configuration
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    
    @classmethod
    def get_rabbitmq_config(cls):
        """Get RabbitMQ client configuration"""
        return {
            "connection_timeout": cls.RABBITMQ_CONNECTION_TIMEOUT,
            "heartbeat": cls.RABBITMQ_HEARTBEAT,
            "blocked_connection_timeout": cls.RABBITMQ_BLOCKED_CONNECTION_TIMEOUT
        }
    
    @classmethod
    def log_configuration(cls):
        """Log current performance configuration"""
        return f"""
🔧 Gateway Performance Configuration (uvloop optimized):
   RabbitMQ Connection Timeout: {cls.RABBITMQ_CONNECTION_TIMEOUT}s (optimized for uvloop)
   RabbitMQ Heartbeat: {cls.RABBITMQ_HEARTBEAT}s (reduced for uvloop efficiency)
   RabbitMQ Blocked Connection Timeout: {cls.RABBITMQ_BLOCKED_CONNECTION_TIMEOUT}s (uvloop faster recovery)
   Response Timeout: {cls.RESPONSE_TIMEOUT_SECONDS}s
   Response Polling Interval: {cls.RESPONSE_POLLING_INTERVAL}s
   Card Not Present Timeout: {cls.CARD_NOT_PRESENT_TIMEOUT_SECONDS}s (optimized with uvloop - was 8s)
   Card Present Timeout: {cls.CARD_PRESENT_TIMEOUT_SECONDS}s (cardPresent=true)
   Log Level: {cls.LOG_LEVEL}
        """.strip()
