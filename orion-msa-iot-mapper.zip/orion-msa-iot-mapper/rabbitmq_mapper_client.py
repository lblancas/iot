"""
RabbitMQ client specific for Mapper microservice
"""

import asyncio
import logging
import json
from typing import Dict, Any, Optional
from rabbitmq_client import RabbitMQClient, RabbitMQConfig

logger = logging.getLogger("orion-mapper")

class MapperRabbitMQClient(RabbitMQClient):
    """RabbitMQ client specific for Mapper microservice"""
    
    def __init__(self, config: RabbitMQConfig):
        super().__init__(config)
        self.mapper_queue: Optional[Any] = None
        self.running = False

    async def initialize(self) -> None:
        """Initialize Mapper RabbitMQ client"""
        try:
            await self.connect()
            
            # Declare mapper queue
            routing_keys = [
                "orion.mapper.request",
                "orion.mapper.response"
            ]
            
            self.mapper_queue = await self.declare_queue("mapper", routing_keys)
            
            logger.info("✅ Mapper RabbitMQ client initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Mapper RabbitMQ client: {e}")
            raise

    async def start_consuming(self, message_handler) -> None:
        """Start consuming messages"""
        if not self.mapper_queue:
            raise RuntimeError("Mapper queue not initialized")
        
        self.running = True
        await self.consume_messages(self.mapper_queue, message_handler)
        logger.info("🔄 Started consuming messages for Mapper")

    async def stop_consuming(self) -> None:
        """Stop consuming messages"""
        self.running = False
        logger.info("⏹️ Stopped consuming messages for Mapper")

    async def send_to_gateway(self, message: Dict[str, Any]) -> None:
        """Send translated message to gateway"""
        routing_key = "orion.gateway.response"
        await self.publish_message(routing_key, message)
        logger.info("📤 Sent message to gateway")

    async def send_to_link(self, message: Dict[str, Any]) -> None:
        """Send translated message to link"""
        routing_key = "orion.link.request"
        await self.publish_message(routing_key, message)
        logger.info("📤 Sent message to link")

    async def send_to_switch_link(self, message: Dict[str, Any]) -> None:
        """Send translated message to switch-link"""
        routing_key = "orion.switch-link.request"
        await self.publish_message(routing_key, message)
        logger.info("📤 Sent message to switch-link")

    async def send_to_state_handler(self, message: Dict[str, Any]) -> None:
        """Send status update to state-handler"""
        routing_key = "orion.state-handler.update"
        await self.publish_message(routing_key, message)
        logger.info("📤 Sent status update to state-handler")

    def route_message(self, translated_message: Dict[str, Any]) -> str:
        """Route translated message based on workflow criteria"""
        try:
            # Extract routing information
            state_id = translated_message.get("stateId")
            data_command = translated_message.get("dataCommand", {})
            card_present = data_command.get("cardPresent", False)
            
            # Routing logic (same as workflow)
            if state_id == "response":
                return "gateway"  # All responses go to gateway
            elif card_present:
                return "link"     # Card present transactions go to link
            else:
                return "switch-link"  # Card not present go to switch-link
                
        except Exception as e:
            logger.error(f"❌ Error routing message: {e}")
            return "gateway"  # Default to gateway on error

    async def route_and_send_message(self, translated_message: Dict[str, Any]) -> None:
        """Route and send translated message to appropriate destination"""
        try:
            destination = self.route_message(translated_message)
            
            if destination == "gateway":
                await self.send_to_gateway(translated_message)
            elif destination == "link":
                await self.send_to_link(translated_message)
            elif destination == "switch-link":
                await self.send_to_switch_link(translated_message)
            else:
                logger.warning(f"⚠️ Unknown destination: {destination}")
                
        except Exception as e:
            logger.error(f"❌ Error routing and sending message: {e}")
            raise
