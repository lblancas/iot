"""
Mapping Engine for Mapper microservice
Handles CSV-based field mapping and template processing
"""

import os
import csv
import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger("orion-mapper")

class MappingEngine:
    """Engine for mapping fields using CSV files and JSON templates"""
    
    def __init__(self, base_path: str = "."):
        self.base_path = base_path
        self.mapping_cache: Dict[str, Dict[str, str]] = {}
        self.template_cache: Dict[str, Dict[str, Any]] = {}

    def load_mapping_csv(self, endpoint_type: str, code: Optional[str] = None) -> Dict[str, str]:
        """Load mapping CSV file for endpoint and code"""
        try:
            # Try code-specific mapping first
            if code:
                csv_path = os.path.join(
                    self.base_path, 
                    "mapperReference", 
                    endpoint_type, 
                    f"{code}.csv"
                )
                if os.path.exists(csv_path):
                    return self._load_csv_file(csv_path, f"{endpoint_type}_{code}")
            
            # Fall back to general mapping
            csv_path = os.path.join(
                self.base_path, 
                "mapperReference", 
                endpoint_type, 
                "mapper.csv"
            )
            
            if os.path.exists(csv_path):
                return self._load_csv_file(csv_path, endpoint_type)
            else:
                logger.warning(f"⚠️ No mapping CSV found for {endpoint_type}")
                return {}
                
        except Exception as e:
            logger.error(f"❌ Error loading mapping CSV for {endpoint_type}: {e}")
            return {}

    def _load_csv_file(self, csv_path: str, cache_key: str) -> Dict[str, str]:
        """Load CSV file and cache the mapping"""
        if cache_key in self.mapping_cache:
            return self.mapping_cache[cache_key]
        
        mapping = {}
        try:
            with open(csv_path, 'r', encoding='utf-8') as file:
                reader = csv.reader(file)
                for row in reader:
                    if len(row) >= 2:
                        source_field = row[0].strip()
                        target_field = row[1].strip()
                        mapping[source_field] = target_field
            
            self.mapping_cache[cache_key] = mapping
            logger.info(f"📄 Loaded mapping CSV: {csv_path} ({len(mapping)} mappings)")
            return mapping
            
        except Exception as e:
            logger.error(f"❌ Error reading CSV file {csv_path}: {e}")
            return {}

    def load_template(self, endpoint_type: str, code: Optional[str] = None) -> Dict[str, Any]:
        """Load JSON template for endpoint and code"""
        try:
            # Try code-specific template first
            if code:
                template_path = os.path.join(
                    self.base_path, 
                    "templates", 
                    endpoint_type, 
                    f"{code}.json"
                )
                if os.path.exists(template_path):
                    return self._load_json_file(template_path, f"{endpoint_type}_{code}")
            
            # Fall back to default template
            template_path = os.path.join(
                self.base_path, 
                "templates", 
                endpoint_type, 
                "default.json"
            )
            
            if os.path.exists(template_path):
                return self._load_json_file(template_path, f"{endpoint_type}_default")
            
            # Fall back to responses directory (legacy)
            if code:
                template_path = os.path.join(
                    self.base_path, 
                    "responses", 
                    f"{code}.json"
                )
                if os.path.exists(template_path):
                    return self._load_json_file(template_path, f"legacy_{code}")
            
            # Final fallback to default response
            template_path = os.path.join(
                self.base_path, 
                "responses", 
                "default.json"
            )
            
            if os.path.exists(template_path):
                return self._load_json_file(template_path, "legacy_default")
            else:
                logger.warning(f"⚠️ No template found for {endpoint_type}/{code}")
                return self._create_default_template()
                
        except Exception as e:
            logger.error(f"❌ Error loading template for {endpoint_type}/{code}: {e}")
            return self._create_default_template()

    def _load_json_file(self, json_path: str, cache_key: str) -> Dict[str, Any]:
        """Load JSON file and cache the template"""
        if cache_key in self.template_cache:
            return self.template_cache[cache_key]
        
        try:
            with open(json_path, 'r', encoding='utf-8') as file:
                template = json.load(file)
            
            self.template_cache[cache_key] = template
            logger.info(f"📄 Loaded template: {json_path}")
            return template
            
        except Exception as e:
            logger.error(f"❌ Error reading JSON file {json_path}: {e}")
            return self._create_default_template()

    def _create_default_template(self) -> Dict[str, Any]:
        """Create a default template when none is found"""
        return {
            "code": "[code]",
            "stateId": "[stateId]",
            "endpointType": "[endpointType]",
            "transactionFolio": "[transactionFolio]",
            "timestamp": "[timestamp]",
            "dataCommand": {}
        }

    def map_fields(self, source_data: Dict[str, Any], mapping: Dict[str, str]) -> Dict[str, Any]:
        """Map fields from source to target using mapping dictionary"""
        try:
            mapped_data = {}
            
            for source_field, target_field in mapping.items():
                if source_field in source_data:
                    mapped_data[target_field] = source_data[source_field]
                else:
                    logger.debug(f"🔍 Source field '{source_field}' not found in data")
            
            logger.info(f"✅ Mapped {len(mapped_data)} fields")
            return mapped_data
            
        except Exception as e:
            logger.error(f"❌ Error mapping fields: {e}")
            return {}

    def apply_template(self, template: Dict[str, Any], mapped_data: Dict[str, Any], 
                      original_message: Dict[str, Any]) -> Dict[str, Any]:
        """Apply template with mapped data and original message context"""
        try:
            import copy
            
            # Create a deep copy of the template
            result = copy.deepcopy(template)
            
            # Get data command from original message
            original_data_command = original_message.get("dataCommand", {})
            
            # Define replacement values
            replacements = {
                "[code]": original_message.get("code"),
                "[stateId]": original_message.get("stateId"),
                "[endpointType]": original_message.get("endpointType"),
                "[transactionFolio]": original_message.get("transactionFolio") or original_message.get("UUID"),
                "[siteId]": original_message.get("siteId", ""),
                "[wsNo]": original_message.get("wsNo", ""),
                "[posInfo]": original_message.get("posInfo", ""),
                "[sequenceNo]": original_message.get("sequenceNo", ""),
                "[thingId]": original_message.get("thingId", ""),
                "[timestamp]": datetime.now().isoformat() + "Z"
            }
            
            # Function to recursively replace placeholders
            def replace_recursive(obj):
                if isinstance(obj, dict):
                    return {k: replace_recursive(v) for k, v in obj.items()}
                elif isinstance(obj, list):
                    return [replace_recursive(item) for item in obj]
                elif isinstance(obj, str):
                    # Replace all placeholders in the string
                    result = obj
                    for placeholder, value in replacements.items():
                        if value is not None:
                            result = result.replace(placeholder, str(value))
                    return result
                else:
                    return obj
            
            # Apply replacements
            result = replace_recursive(result)
            
            # Replace the dataCommand section with mapped data
            if "dataCommand" in result:
                result["dataCommand"] = mapped_data
            
            logger.info("✅ Applied template successfully")
            return result
            
        except Exception as e:
            logger.error(f"❌ Error applying template: {e}")
            return template

    def translate_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Main translation method - maps fields and applies template"""
        try:
            # Extract message information
            endpoint_type = message.get("endpointType", "transaction")
            code = message.get("code")
            state_id = message.get("stateId")
            
            logger.info(f"🔄 Translating message: {endpoint_type}/{code}/{state_id}")
            
            # Load mapping and template
            mapping = self.load_mapping_csv(endpoint_type, code)
            template = self.load_template(endpoint_type, code)
            
            # Get source data from dataCommand
            source_data = message.get("dataCommand", {})
            
            # Map fields
            mapped_data = self.map_fields(source_data, mapping)
            
            # Apply template
            translated_message = self.apply_template(template, mapped_data, message)
            
            logger.info(f"✅ Message translated successfully")
            return translated_message
            
        except Exception as e:
            logger.error(f"❌ Error translating message: {e}")
            return message  # Return original message on error
