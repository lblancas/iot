"""
Data models for Mapper microservice
"""

from datetime import datetime
from typing import Optional, Dict, Any
from pydantic import BaseModel


class StateHandlerMessage(BaseModel):
    """Message structure for state handler communications"""
    transaction_folio: str
    operation_type: str
    current_step: str = "mapper"
    status: str  # "success" or "error"
    payload: Dict[str, Any]
    execution_start_time: str  # ISO format string
    execution_end_time: str    # ISO format string
    execution_total_time: str  # in milliseconds as string
    response_code: str
    response_message: str

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str = "healthy"
    service: str = "mapper"
    timestamp: datetime
    version: str = "1.0.0"