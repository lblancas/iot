"""
Base RabbitMQ client for Mapper microservice
"""

import asyncio
import logging
import aio_pika
from dataclasses import dataclass
from typing import Optional, Dict, Any, Callable
import json

logger = logging.getLogger("orion-mapper")

@dataclass
class RabbitMQConfig:
    """RabbitMQ configuration"""
    host: str
    username: str
    password: str
    port: int = 5671
    virtual_host: str = "/"
    use_ssl: bool = True
    environment: str = "dev"

    @property
    def connection_url(self) -> str:
        """Generate connection URL"""
        protocol = "amqps" if self.use_ssl else "amqp"
        return f"{protocol}://{self.username}:{self.password}@{self.host}:{self.port}{self.virtual_host}"
    
    def get_queue_name(self, service: str) -> str:
        return f"sps-{self.environment}-orion-queue-{service}"

    def get_exchange_name(self) -> str:
        return f"sps-{self.environment}-orion-exchange"

    def get_dlx_name(self) -> str:
        return f"sps-{self.environment}-orion-dlx"

class RabbitMQClient:
    """Base RabbitMQ client for Mapper"""
    
    def __init__(self, config: RabbitMQConfig):
        self.config = config
        self.connection: Optional[aio_pika.Connection] = None
        self.channel: Optional[aio_pika.Channel] = None
        self.exchange: Optional[aio_pika.Exchange] = None
        self.connected = False

    async def connect(self) -> None:
        """Connect to RabbitMQ"""
        try:
            logger.info(f"🔗 Attempting to connect to RabbitMQ:")
            logger.info(f"   - Host: {self.config.host}")
            logger.info(f"   - Username: {self.config.username}")
            logger.info(f"   - Port: {self.config.port}")
            logger.info(f"   - Virtual Host: {self.config.virtual_host}")
            logger.info(f"   - SSL: {self.config.use_ssl}")
            logger.info(f"   - Connection URL: {self.config.connection_url.replace(self.config.password, '***')}")

            # Configure SSL context if needed
            ssl_context = None
            if self.config.use_ssl:
                import ssl
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE
            
            self.connection = await aio_pika.connect_robust(
                self.config.connection_url,
                ssl_context=ssl_context,
                heartbeat=60,
                client_properties={"connection_name": "orion-mapper"}
            )
            self.channel = await self.connection.channel()
            
            # Declare main exchange
            self.exchange = await self.channel.declare_exchange(
                self.config.get_exchange_name(),
                aio_pika.ExchangeType.TOPIC,
                durable=True
            )
            
            # Declare DLX (Dead Letter Exchange)
            await self.channel.declare_exchange(
                self.config.get_dlx_name(),
                aio_pika.ExchangeType.DIRECT,
                durable=True
            )
            
            self.connected = True
            logger.info(f"✅ Connected to RabbitMQ: {self.config.host}")
            
        except Exception as e:
            logger.error(f"❌ Failed to connect to RabbitMQ: {e}")
            raise

    async def disconnect(self) -> None:
        """Disconnect from RabbitMQ"""
        try:
            if self.connection and not self.connection.is_closed:
                await self.connection.close()
            self.connected = False
            logger.info("🔌 Disconnected from RabbitMQ")
        except Exception as e:
            logger.error(f"❌ Error disconnecting from RabbitMQ: {e}")

    async def declare_queue(self, service: str, routing_keys: list) -> aio_pika.Queue:
        """Declare queue with TTL and DLX"""
        queue_name = self.config.get_queue_name(service)
        
        queue = await self.channel.declare_queue(
            queue_name,
            durable=True,
            arguments={
                'x-message-ttl': 300000,  # 5 minutes TTL
                'x-dead-letter-exchange': self.config.get_dlx_name(),
                'x-dead-letter-routing-key': 'mapper'  # Corregido para coincidir con el binding
            }
        )
        
        # Bind queue to exchange with routing keys
        for routing_key in routing_keys:
            await queue.bind(self.exchange, routing_key)
            logger.info(f"📥 Bound queue {queue_name} to routing key: {routing_key}")
        
        return queue

    async def publish_message(self, routing_key: str, message: Dict[str, Any]) -> None:
        """Publish message to exchange"""
        try:
            message_body = json.dumps(message).encode()
            
            await self.exchange.publish(
                aio_pika.Message(
                    body=message_body,
                    delivery_mode=aio_pika.DeliveryMode.PERSISTENT
                ),
                routing_key=routing_key
            )
            
            logger.info(f"📤 Published message to routing key: {routing_key}")
            
        except Exception as e:
            logger.error(f"❌ Failed to publish message: {e}")
            raise

    async def consume_messages(self, queue: aio_pika.Queue, callback: Callable) -> None:
        """Start consuming messages from queue"""
        try:
            await queue.consume(callback)
            logger.info(f"🔄 Started consuming messages from queue: {queue.name}")
        except Exception as e:
            logger.error(f"❌ Failed to start consuming messages: {e}")
            raise
