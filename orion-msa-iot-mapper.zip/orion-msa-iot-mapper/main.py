#!/usr/bin/env python3
"""
Mapper Microservice
Transaction translator for IoT requests and responses
"""

import os
import sys
import json
import asyncio
import logging
import threading
from datetime import datetime
from typing import Dict, Any
from fastapi import FastAPI
import uvicorn

from config import config
from models import HealthResponse, StateHandlerMessage
from rabbitmq_mapper_client import MapperRabbitMQClient
from mapping_engine import MappingEngine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("orion-mapper")

# FastAPI app for health endpoint
app = FastAPI(title="Mapper Microservice", version="1.0.0")

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        service="mapper", 
        timestamp=datetime.now(),
        version="1.0.0"
    )

class MapperService:
    """Main Mapper service class"""
    
    def __init__(self):
        self.rabbitmq_client: MapperRabbitMQClient = None
        self.mapping_engine = MappingEngine()
        self.running = False

    async def initialize(self) -> None:
        """Initialize Mapper service"""
        try:
            logger.info("🚀 STARTING MAPPER SERVICE INITIALIZATION...")
            
            # Initialize RabbitMQ client
            rabbitmq_config = config.get_rabbitmq_config()
            self.rabbitmq_client = MapperRabbitMQClient(rabbitmq_config)
            await self.rabbitmq_client.initialize()
            
            logger.info("✅ Mapper service initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Mapper service: {e}")
            raise

    async def start(self) -> None:
        """Start Mapper service"""
        if not self.rabbitmq_client:
            raise RuntimeError("Mapper service not initialized")
        
        self.running = True
        await self.rabbitmq_client.start_consuming(self.message_handler)
        logger.info("🔄 Mapper service started")

    async def stop(self) -> None:
        """Stop Mapper service"""
        self.running = False
        if self.rabbitmq_client:
            await self.rabbitmq_client.stop_consuming()
            await self.rabbitmq_client.disconnect()
        logger.info("⏹️ Mapper service stopped")

    async def message_handler(self, message) -> None:
        """Handle incoming messages from RabbitMQ"""
        try:
            # Capture start time
            execution_start = datetime.now()
            
            # Parse message
            body = json.loads(message.body.decode())
            logger.info(f"📥 Received message: {body}")
            
            # Extract required fields
            transaction_folio = body.get("transactionFolio") or body.get("UUID")
            state_id = body.get("stateId")
            code = body.get("code")
            endpoint_type = body.get("endpointType", "transaction")
            
            # Validate message
            if not all([transaction_folio, state_id, code]):
                logger.warning(f"⚠️ Missing required fields in message: {body}")
                message.ack()
                return
            
            logger.info(f"🔄 Processing: {endpoint_type}/{code}/{state_id} - {transaction_folio}")
            
            try:
                # Translate message using mapping engine
                translated_message = self.mapping_engine.translate_message(body)
                
                # Route and send translated message
                await self.rabbitmq_client.route_and_send_message(translated_message)
                
                # Send success status to state-handler
                await self.send_to_state_handler(
                    transaction_folio, code, state_id, body, 
                    execution_start, "success", "200", 
                    f"Message translated and routed successfully"
                )
                
                logger.info(f"✅ Message processed successfully: {transaction_folio}")
                
            except Exception as e:
                # Handle translation/routing errors
                error_message = f"Error translating/routing message: {str(e)}"
                logger.error(f"❌ {error_message}")
                
                # Send error status to state-handler
                await self.send_to_state_handler(
                    transaction_folio, code, state_id, body, 
                    execution_start, "error", "500", error_message
                )
            
            # Acknowledge message
            await message.ack()
            
        except json.JSONDecodeError as e:
            logger.error(f"❌ Error parsing message JSON: {e}")
            await message.ack()  # Acknowledge to remove malformed message
        except Exception as e:
            logger.error(f"❌ Error processing message: {e}")
            await message.ack()  # Acknowledge to prevent infinite retry

    async def send_to_state_handler(self, transaction_folio: str, code: str, 
                                  state_id: str, payload: Dict[str, Any], 
                                  execution_start: datetime, status: str, 
                                  response_code: str, response_message: str) -> None:
        """Send status update to state-handler"""
        try:
            # Capture end time and calculate execution time
            execution_end = datetime.now()
            total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
            
            # Build operation_type
            operation_type = f"{code}-{state_id}"
            
            # Create state handler message
            state_msg = StateHandlerMessage(
                transaction_folio=transaction_folio,
                operation_type=operation_type,
                current_step="mapper",
                status=status,
                payload=payload,
                execution_start_time=execution_start.isoformat(),
                execution_end_time=execution_end.isoformat(),
                execution_total_time=str(int(total_execution_ms)),
                response_code=response_code,
                response_message=response_message
            )
            
            # Send to state-handler
            await self.rabbitmq_client.send_to_state_handler(state_msg.model_dump())
            
            logger.info(f"📤 Sent status update to state-handler: {status}")
            logger.info(f"⏱️ Execution time: {total_execution_ms:.2f}ms")
            
        except Exception as e:
            logger.error(f"❌ Error sending to state-handler: {e}")

# Global mapper service instance
mapper_service = MapperService()

def run_fastapi():
    """Run FastAPI server in a separate thread"""
    uvicorn.run(app, host="0.0.0.0", port=config.PORT, log_level="info")

async def main():
    """Main function to run both FastAPI and message processing"""
    try:
        # Start FastAPI in a separate thread
        fastapi_thread = threading.Thread(target=run_fastapi, daemon=True)
        fastapi_thread.start()
        
        logger.info(f"Health endpoint available at http://0.0.0.0:{config.PORT}/health")
        
        # Initialize and start mapper service
        await mapper_service.initialize()
        await mapper_service.start()
        
        # Keep running
        while True:
            await asyncio.sleep(1)
            
    except KeyboardInterrupt:
        logger.info("🛑 Shutting down...")
        await mapper_service.stop()
    except Exception as e:
        logger.error(f"❌ Application error: {e}")
        await mapper_service.stop()
        sys.exit(1)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("🛑 Shutting down...")
    except Exception as e:
        logger.error(f"❌ Application error: {e}")
        sys.exit(1)
