#!/usr/bin/env python3
"""
Configuration management for Mapper microservice
"""

import os
import json
import logging
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger("orion-mapper")

class Config:
    """Configuration class for Mapper microservice"""
    
    def __init__(self):
        self.AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
        self.AWS_SECRET_NAME = os.getenv("AWS_SECRET_NAME", "sps-dev-orion-secret-iot-mapper")
        self.ENVIRONMENT = os.getenv("ENVIRONMENT", "dev")
        self.PORT = int(os.getenv("PORT", 40085))
        
        # RabbitMQ configuration
        self.RABBITMQ_HOST: str = os.getenv("RABBITMQ_HOST", "")
        self.RABBITMQ_USERNAME: str = os.getenv("RABBITMQ_USERNAME", "")
        self.RABBITMQ_PASSWORD: str = os.getenv("RABBITMQ_PASSWORD", "")
        self.RABBITMQ_ENVIRONMENT: str = os.getenv("RABBITMQ_ENVIRONMENT", "dev")
        
    def get_secrets(self) -> dict:
        """Get secrets from AWS Secrets Manager"""
        try:
            session = boto3.session.Session()
            client = session.client("secretsmanager", region_name=self.AWS_REGION)
            
            response = client.get_secret_value(SecretId=self.AWS_SECRET_NAME)
            secrets = json.loads(response["SecretString"])
            
            logger.info(f"Successfully loaded secrets from {self.AWS_SECRET_NAME}")
            return secrets
            
        except ClientError as e:
            logger.error(f"Error retrieving secret {self.AWS_SECRET_NAME}: {e}")
            raise e

    def get_rabbitmq_config(self):
        """Get RabbitMQ configuration from secrets"""
        from rabbitmq_client import RabbitMQConfig
        
        secrets = self.get_secrets()
        
        # Get rabbitmq_host from secrets (same as watcher)
        rabbitmq_host = secrets.get("rabbitmq_host")
        if not rabbitmq_host:
            raise ValueError("rabbitmq_host not found in secrets")
        
        # Log configuration values for debugging
        logger.info(f"🔧 RabbitMQ Configuration from secrets:")
        logger.info(f"   - Host: {rabbitmq_host}")
        logger.info(f"   - Username: {secrets.get('rabbitmq_username', 'orion_admin')}")
        logger.info(f"   - Password: {'***' if secrets.get('rabbitmq_password') else 'NOT_SET'}")
        logger.info(f"   - Environment: {secrets.get('rabbitmq_environment', self.RABBITMQ_ENVIRONMENT)}")
        
        return RabbitMQConfig(
            host=rabbitmq_host,
            username=secrets.get("rabbitmq_username", "orion_admin"),
            password=secrets.get("rabbitmq_password", ""),
            environment=secrets.get("rabbitmq_environment", self.RABBITMQ_ENVIRONMENT)
        )

# Global config instance
config = Config()