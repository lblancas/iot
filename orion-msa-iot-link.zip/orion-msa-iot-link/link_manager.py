#!/usr/bin/env python3
"""
Link Manager - Handles both SQS and RabbitMQ based on configuration
"""


import logging
import boto3
from typing import Dict, Any, Optional, Callable
from config import config

# Import both clients
from rabbitmq_link_client import LinkRabbitMQClient

logger = logging.getLogger(__name__)

class LinkManager:
    """
    Manages message broker connections and operations for Link
    Supports both SQS (legacy) and RabbitMQ (new) backends
    """
    
    def __init__(self):
        # Get broker type from secrets instead of environment
        secrets = config.get_secrets()
        self.broker_type = secrets.get("message_broker", "sqs")
        self.rabbitmq_client: Optional[LinkRabbitMQClient] = None
        self.boto3_sqs_client = None
        
        logger.info(f"🔧 Link Manager initialized with broker: {self.broker_type}")
    
    async def initialize(self) -> None:
        """Initialize the appropriate message broker client"""
        try:
            secrets = config.get_secrets()
            
            if self.broker_type == "rabbitmq":
                # Initialize RabbitMQ client with secrets
                rabbitmq_host = secrets.get("rabbitmq_host")
                rabbitmq_env = secrets.get("rabbitmq_environment", "dev")
                
                if not rabbitmq_host:
                    raise ValueError("rabbitmq_host not found in secrets")
                
                self.rabbitmq_client = LinkRabbitMQClient(
                    rabbitmq_host=rabbitmq_host,
                    environment=rabbitmq_env
                )
                await self.rabbitmq_client.initialize()
                logger.info("✅ RabbitMQ client initialized")
                
            elif self.broker_type == "sqs":
                # Initialize boto3 SQS client for legacy SQS operations
                self.boto3_sqs_client = boto3.client("sqs", region_name=config.AWS_REGION)
                logger.info("✅ SQS client initialized")
                
            else:
                raise ValueError(f"Unknown message broker type: {self.broker_type}")
                
        except Exception as e:
            logger.error(f"❌ Failed to initialize Link Manager: {e}")
            raise
    
    async def start_consuming(self, message_handler: Callable[[Dict[str, Any]], None]) -> None:
        """Start consuming messages from link queue"""
        if self.broker_type == "rabbitmq":
            await self.rabbitmq_client.start_consuming(message_handler)
        elif self.broker_type == "sqs":
            # SQS consumption is handled in main.py process_messages loop
            # Store the handler for use in SQS message processing
            self._sqs_message_handler = message_handler
            logger.info("✅ SQS message handler registered")
        else:
            raise ValueError(f"Unknown broker type: {self.broker_type}")
    
    async def send_to_workflow(self, payload: Dict[str, Any]) -> None:
        """Send response message back to workflow"""
        if self.broker_type == "rabbitmq":
            await self.rabbitmq_client.send_to_workflow(payload)
        elif self.broker_type == "sqs":
            # Use SQS direct send for workflow
            secrets = config.get_secrets()
            workflow_queue_url = secrets.get("workflow_queue") or secrets.get("workflow_queue_url")
            
            if workflow_queue_url and self.boto3_sqs_client:
                import json
                self.boto3_sqs_client.send_message(
                    QueueUrl=workflow_queue_url,
                    MessageBody=json.dumps(payload)
                )
                logger.info(f"📤 Sent to WORKFLOW via SQS: {payload.get('transactionFolio') or payload.get('UUID', 'unknown')}")
        else:
            raise ValueError(f"Unknown broker type: {self.broker_type}")
    
    async def send_to_state_handler(self, payload: Dict[str, Any]) -> None:
        """Send message to state handler service"""
        if self.broker_type == "rabbitmq":
            await self.rabbitmq_client.send_to_state_handler(payload)
        elif self.broker_type == "sqs":
            # Use SQS direct send for state handler
            secrets = config.get_secrets()
            state_handler_url = secrets.get("state_handler_queue") or secrets.get("state_handler_queue_url")
            
            if state_handler_url and self.boto3_sqs_client:
                import json
                payload_json = payload if isinstance(payload, str) else json.dumps(payload)
                self.boto3_sqs_client.send_message(
                    QueueUrl=state_handler_url,
                    MessageBody=payload_json
                )
                logger.info(f"📤 Sent to state_handler via SQS: {payload.get('transaction_folio', 'unknown')}")
        else:
            raise ValueError(f"Unknown broker type: {self.broker_type}")
    
    async def health_check(self) -> bool:
        """Check broker health"""
        try:
            if self.broker_type == "rabbitmq":
                return await self.rabbitmq_client.health_check()
            elif self.broker_type == "sqs":
                # Simple SQS health check
                return self.boto3_sqs_client is not None
            return False
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def disconnect(self) -> None:
        """Disconnect from message broker"""
        try:
            if self.broker_type == "rabbitmq" and self.rabbitmq_client:
                await self.rabbitmq_client.disconnect()
            elif self.broker_type == "sqs":
                # SQS doesn't need explicit disconnect
                pass
                
            logger.info(f"🔌 {self.broker_type.upper()} client disconnected")
            
        except Exception as e:
            logger.error(f"Error disconnecting from {self.broker_type}: {e}")

# Global link manager instance
link_manager: Optional[LinkManager] = None

def get_link_manager() -> LinkManager:
    """Get or create link manager singleton"""
    global link_manager
    if link_manager is None:
        link_manager = LinkManager()
    return link_manager