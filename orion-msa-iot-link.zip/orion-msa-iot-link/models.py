"""
Data models for Link microservice
"""

from datetime import datetime
from typing import Optional, Any, Dict
from pydantic import BaseModel

class BaseMessage(BaseModel):
    """Base message structure for IoT communications"""
    StateID: str
    thingId: Optional[str] = None
    UUID: Optional[str] = None
    SiteID: Optional[str] = None
    WSNo: Optional[str] = None
    SequenceNo: Optional[str] = None
    timestamp: Optional[datetime] = None
    transactionType: Optional[str] = None

class RequestMessage(BaseMessage):
    """Message structure for IoT requests"""
    StateID: str = "request"
    
class ResponseMessage(BaseMessage):  
    """Message structure for IoT responses"""
    StateID: str = "response"
    response_data: Optional[Dict[str, Any]] = None

class StateHandlerMessage(BaseModel):
    """Message structure for state handler communications"""
    transaction_folio: str
    operation_type: str
    current_step: str = "link"
    status: str  # "success" or "error"
    payload: Dict[str, Any]
    execution_start_time: str  # ISO format string
    execution_end_time: str    # ISO format string
    execution_total_time: str  # in milliseconds as string
    response_code: str
    response_message: str

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str = "healthy"
    service: str = "link"
    timestamp: datetime
    version: str = "1.0.0"