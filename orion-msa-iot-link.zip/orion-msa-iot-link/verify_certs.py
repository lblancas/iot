#!/usr/bin/env python3
"""
Script para verificar la estructura de certificados del microservicio Link
"""

import os
import sys
from pathlib import Path

def verify_cert_structure():
    """Verifica que la estructura de certificados esté correcta"""
    
    # Obtener el ambiente desde variable de entorno
    environment = os.getenv("ENVIRONMENT", "dev")
    print(f"🔍 Verificando estructura de certificados para ambiente: {environment}")
    
    # Definir la estructura esperada
    certs_dir = Path("certs")
    expected_structure = {
        "common": ["root-CA.crt"],
        environment: [
            f"orion-link-{environment}-certificate.pem.crt",
            f"orion-link-{environment}-private.pem.key"
        ]
    }
    
    print(f"\n📁 Estructura esperada:")
    print(f"   {certs_dir}/common/root-CA.crt")
    print(f"   {certs_dir}/{environment}/orion-link-{environment}-certificate.pem.crt")
    print(f"   {certs_dir}/{environment}/orion-link-{environment}-private.pem.key")
    
    # Verificar directorios
    print(f"\n🔍 Verificando directorios...")
    for dir_name in ["common", environment]:
        dir_path = certs_dir / dir_name
        if dir_path.exists():
            print(f"   ✅ {dir_path} existe")
        else:
            print(f"   ❌ {dir_path} NO existe")
            return False
    
    # Verificar archivos
    print(f"\n🔍 Verificando archivos...")
    missing_files = []
    
    for dir_name, files in expected_structure.items():
        for file_name in files:
            file_path = certs_dir / dir_name / file_name
            if file_path.exists():
                file_size = file_path.stat().st_size
                print(f"   ✅ {file_path} existe ({file_size} bytes)")
            else:
                print(f"   ❌ {file_path} NO existe")
                missing_files.append(str(file_path))
    
    if missing_files:
        print(f"\n⚠️ Archivos faltantes:")
        for file_path in missing_files:
            print(f"   - {file_path}")
        print(f"\n💡 Coloca los archivos de certificados en las ubicaciones indicadas")
        return False
    
    print(f"\n✅ Estructura de certificados correcta para ambiente '{environment}'")
    return True

def main():
    """Función principal"""
    print("🔐 Verificador de Estructura de Certificados - Microservicio Link")
    print("=" * 70)
    
    if not verify_cert_structure():
        sys.exit(1)
    
    print(f"\n🎉 ¡Todo listo! Los certificados están en su lugar.")

if __name__ == "__main__":
    main()
