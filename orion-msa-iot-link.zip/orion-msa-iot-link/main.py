import os
import sys
import json
import asyncio
import logging
import threading
from datetime import datetime
from typing import Dict, Any
import boto3
from botocore.exceptions import ClientError
from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient
from fastapi import FastAPI
import uvicorn



# Import other modules
from config import config
from models import RequestMessage, ResponseMessage, StateHandlerMessage, HealthResponse
from link_manager import get_link_manager

# Global link manager instance
link_manager = None

# Performance Configuration - Integrated directly in main.py
class PerformanceConfig:
    """Performance configuration for link microservice"""
    
    # RabbitMQ Configuration - Performance optimized
    RABBITMQ_CONNECT_TIMEOUT = int(os.getenv("RABBITMQ_CONNECT_TIMEOUT", "30"))
    RABBITMQ_HEARTBEAT = int(os.getenv("RABBITMQ_HEARTBEAT", "60"))
    
    # MQTT Configuration
    MQTT_CONNECT_TIMEOUT = int(os.getenv("MQTT_CONNECT_TIMEOUT", "60"))
    MQTT_OPERATION_TIMEOUT = int(os.getenv("MQTT_OPERATION_TIMEOUT", "60"))
    
    # Logging Configuration
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    
    @classmethod
    def get_rabbitmq_config(cls):
        """Get RabbitMQ client configuration"""
        return {
            "connect_timeout": cls.RABBITMQ_CONNECT_TIMEOUT,
            "heartbeat": cls.RABBITMQ_HEARTBEAT
        }
    
    @classmethod
    def log_configuration(cls):
        """Log current performance configuration"""
        return f"""
🔧 Link Performance Configuration:
   RabbitMQ Connect Timeout: {cls.RABBITMQ_CONNECT_TIMEOUT}s
   RabbitMQ Heartbeat: {cls.RABBITMQ_HEARTBEAT}s
   MQTT Connect Timeout: {cls.MQTT_CONNECT_TIMEOUT}s
   MQTT Operation Timeout: {cls.MQTT_OPERATION_TIMEOUT}s
   Log Level: {cls.LOG_LEVEL}
""".strip()

# Configure logging with timestamps
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger("orion-link")

# Global link manager instance
link_manager = None

# FastAPI app for health endpoint
app = FastAPI(title="Link Microservice", version="1.0.0")

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        service="link", 
        timestamp=datetime.now(),
        version="1.0.0"
    )

def init_mqtt_client(client_id: str, endpoint: str, cert_path: str) -> AWSIoTMQTTClient:
    """Initialize MQTT client with proper error handling"""
    try:
        logger.info(f"🔧 Initializing MQTT client with ID: {client_id}")
        logger.info(f"🔧 MQTT Endpoint: {endpoint}")
        logger.info(f"🔧 Certificate path: {cert_path}")
        
        mqtt_client = AWSIoTMQTTClient(client_id)
        mqtt_client.configureEndpoint(endpoint, 8883)
        
        # Get certificate paths based on environment
        cert_paths = config.get_cert_paths()
        ca_file = cert_paths["ca_cert"]
        private_key = cert_paths["key_file"]
        certificate = cert_paths["cert_file"]
        
        # Verify certificate files exist (only log errors)
        for cert_file in [ca_file, private_key, certificate]:
            if not os.path.exists(cert_file):
                logger.error(f"❌ Certificate file not found: {cert_file}")
                raise FileNotFoundError(f"Certificate file not found: {cert_file}")
        
        # Verify certificate and key match (only log errors)
        try:
            import subprocess
            cert_modulus = subprocess.check_output([
                "openssl", "x509", "-noout", "-modulus", "-in", certificate
            ], text=True).strip()
            key_modulus = subprocess.check_output([
                "openssl", "rsa", "-noout", "-modulus", "-in", private_key
            ], text=True).strip()
            
            if cert_modulus != key_modulus:
                logger.error("❌ Certificate and private key do NOT match!")
                
        except Exception as e:
            # Only log if there's an actual error, not just missing openssl
            if "No such file or directory" not in str(e):
                logger.error(f"❌ Certificate verification error: {e}")
        
        logger.info(f"🔧 Configuring MQTT credentials...")
        mqtt_client.configureCredentials(ca_file, private_key, certificate)
        mqtt_client.configureOfflinePublishQueueing(-1)
        mqtt_client.configureDrainingFrequency(2)
        mqtt_client.configureConnectDisconnectTimeout(PerformanceConfig.MQTT_CONNECT_TIMEOUT)
        mqtt_client.configureMQTTOperationTimeout(PerformanceConfig.MQTT_OPERATION_TIMEOUT)
        
        logger.info(f"🔧 MQTT Configuration:")
        logger.info(f"   Connect Timeout: {PerformanceConfig.MQTT_CONNECT_TIMEOUT}s")
        logger.info(f"   Operation Timeout: {PerformanceConfig.MQTT_OPERATION_TIMEOUT}s")
        
        logger.info(f"🔧 Attempting MQTT connection...")
        if mqtt_client.connect():
            logger.info(f"✅ MQTT client {client_id} connected successfully")
            return mqtt_client
        else:
            logger.error(f"❌ Failed to connect MQTT client")
            raise ConnectionError("Failed to connect MQTT client")
            
    except Exception as e:
        logger.error(f"❌ Error initializing MQTT client: {e}")
        raise

def on_message_callback(client, userdata, message):
    """Callback function to handle incoming MQTT messages"""
    try:
        topic = message.topic
        payload = message.payload.decode('utf-8')
        logger.info(f"🎯 MQTT MESSAGE RECEIVED!")
        logger.info(f"📥 MQTT Topic: {topic}")
        logger.info(f"📥 MQTT Payload: {payload}")
        logger.info(f"🔧 MQTT QoS: {message.qos}")
        
        # Parse the message payload
        body = json.loads(payload)
        
        # Skip test messages
        if body.get("test") is True:
            logger.info("🧪 Test message received - ignoring")
            return
        
        # Get link manager and main loop from userdata
        link_manager = userdata['link_manager']
        main_loop = userdata['main_loop']
        
        # Capture start time
        execution_start = datetime.now()
        
        try:
            # Forward response message to workflow queue via RabbitMQ
            # Use run_coroutine_threadsafe to execute async function from MQTT callback
            asyncio.run_coroutine_threadsafe(link_manager.send_to_workflow(body), main_loop)
            logger.info(f"📤 RabbitMQ Sent to workflow queue via link_manager")
            
            # Capture end time and calculate execution time
            execution_end = datetime.now()
            total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
            
            # Build state handler message
            logger.info(f"🔍 Building state handler message. Available fields in body: {list(body.keys())}")
            transaction_folio = body.get("transaction_folio", body.get("UUID", body.get("transactionFolio", "unknown")))
            code = body.get("code", "unknown")
            operation_type = f"{code}-response"
            
            state_msg = StateHandlerMessage(
                transaction_folio=transaction_folio,
                operation_type=operation_type,
                current_step="link",
                status="success",
                payload=body,
                execution_start_time=execution_start.isoformat(),
                execution_end_time=execution_end.isoformat(),
                execution_total_time=str(int(total_execution_ms)),
                response_code="200",
                response_message="Executed Successfully"
            )
            state_handler_payload = state_msg.model_dump()
            # Use run_coroutine_threadsafe to execute async function from MQTT callback
            asyncio.run_coroutine_threadsafe(link_manager.send_to_state_handler(state_handler_payload), main_loop)
            logger.info("📤 RabbitMQ Sent to state_handler queue via link_manager")
            logger.info(f"⏱️ Execution time: {total_execution_ms:.2f}ms")
            
        except Exception as e:
            # Handle errors and send error state
            execution_end = datetime.now()
            total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
            
            transaction_folio = body.get("transaction_folio", body.get("UUID", body.get("transactionFolio", "unknown")))
            code = body.get("code", "unknown")
            operation_type = f"{code}-response"
            
            state_msg = StateHandlerMessage(
                transaction_folio=transaction_folio,
                operation_type=operation_type,
                current_step="link",
                status="error",
                payload=body,
                execution_start_time=execution_start.isoformat(),
                execution_end_time=execution_end.isoformat(),
                execution_total_time=str(int(total_execution_ms)),
                response_code="500",
                response_message=f"Error processing MQTT response: {str(e)}"
            )
            state_handler_payload = state_msg.model_dump()
            # Use run_coroutine_threadsafe to execute async function from MQTT callback
            asyncio.run_coroutine_threadsafe(link_manager.send_to_state_handler(state_handler_payload), main_loop)
            logger.error(f"❌ Error processing MQTT response message: {e}")
            logger.info("📤 RabbitMQ Sent error to state_handler queue via link_manager")
            
    except Exception as e:
        logger.error(f"❌ Error in MQTT message callback: {e}")

async def handle_link_message(message_body: Dict[str, Any], mqtt_client, request_topic: str) -> None:
    """Handle a single link message from RabbitMQ"""
    global link_manager
    
    # Check if link_manager is initialized
    if link_manager is None:
        logger.error("❌ Link manager not initialized")
        return
    
    # Capture start time when message is received
    execution_start = datetime.now()
    
    try:
        # Extract required fields in camelCase (as set by workflow)
        uuid = message_body.get("UUID") or message_body.get("transactionFolio")
        state_id = message_body.get("stateId")  # camelCase
        code = message_body.get("code")
        thing_id = message_body.get("thingId")
        
        logger.info(f"📥 Request: code={code}, wsNo={message_body.get('wsNo')}, siteId={message_body.get('siteId')}, transactionFolio={uuid}, stateId={state_id}")

        if state_id == "request" and thing_id:
            try:
                # Handle request message - send MQTT to IoT device
                topic = request_topic.replace("{thing_id}", thing_id)
                message_payload = json.dumps(message_body)
                mqtt_client.publish(topic, message_payload, 1)
                logger.info(f"📤 MQTT Published to topic: {topic}")
                logger.info(f"📤 MQTT Message: {message_payload}")
                
                # Capture end time and calculate execution time
                execution_end = datetime.now()
                total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
                
                # Send success to state_handler via link_manager
                await send_to_state_handler_rabbitmq(
                    uuid, code, "request", message_body, 
                    execution_start, "success", "200", "MQTT message sent successfully"
                )
                
                logger.info(f"⏱️ Execution time: {total_execution_ms:.2f}ms")
                
            except Exception as e:
                # Handle MQTT errors
                execution_end = datetime.now()
                total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
                
                # Send error to state_handler
                await send_to_state_handler_rabbitmq(
                    uuid, code, "request", message_body, 
                    execution_start, "error", "500", f"MQTT error: {str(e)}"
                )
                
                logger.error(f"❌ MQTT error for {uuid}: {e}")
        else:
            logger.warning(f"⚠️ Invalid message: stateId={state_id}, thingId={thing_id}")
                
    except Exception as e:
        logger.error(f"❌ Error processing link message: {e}")

async def send_to_state_handler_rabbitmq(transaction_folio: str, code: str, state_id: str, 
                                        payload: Dict[str, Any], execution_start: datetime, 
                                        status: str, response_code: str, response_message: str):
    """Send message to state_handler using link manager (RabbitMQ preferred)"""
    global link_manager
    
    # Check if link_manager is initialized
    if link_manager is None:
        logger.error("❌ Link manager not initialized")
        return
    
    try:
        # Capture end time and calculate execution time
        execution_end = datetime.now()
        total_execution_ms = (execution_end - execution_start).total_seconds() * 1000
        
        # Build operation_type like other services
        operation_type = f"{code}-{state_id}"
        
        # Create state handler payload using the model
        state_msg = StateHandlerMessage(
            transaction_folio=transaction_folio,
            operation_type=operation_type,
            current_step="link",
            status=status,
            payload=payload,
            execution_start_time=execution_start.isoformat(),
            execution_end_time=execution_end.isoformat(),
            execution_total_time=str(int(total_execution_ms)),
            response_code=response_code,
            response_message=response_message
        )
        state_handler_payload = state_msg.model_dump()
        
        # Send using link manager (will use RabbitMQ or SQS based on broker_type)
        await link_manager.send_to_state_handler(state_handler_payload)
        
        logger.info(f"📤 Sent to state_handler via link manager")
        logger.info(f"📋 Message details - Transaction: {transaction_folio}, Operation: {operation_type}, Status: {status}")
        logger.info(f"⏱️ Execution time: {total_execution_ms:.2f}ms")
        
    except Exception as e:
        logger.error(f"Error sending to state_handler: {e}")

async def process_messages():
    """Main message processing loop"""
    global link_manager
    
    try:
        # Initialize link manager
        link_manager = get_link_manager()
        await link_manager.initialize()
        logger.info("✅ Link manager initialized")
        
        # Get configuration
        # Get secrets and initialize MQTT client
        logger.info(f"🔍 Loading secrets from AWS Secrets Manager...")
        secrets = config.get_secrets()
        broker_mode = secrets.get("message_broker", "rabbitmq")
        logger.info(f"✅ Secrets loaded successfully")
        
        # Simplified secrets logging
        if secrets:
            logger.info(f"🔍 Key configuration loaded:")
            logger.info(f"   message_broker: {secrets.get('message_broker', 'unknown')}")
            logger.info(f"   iot_endpoint: {secrets.get('iot_endpoint', 'unknown')[:20]}...")
            logger.info(f"   thing_name: {secrets.get('thing_name', 'unknown')}")
        else:
            logger.warning(f"⚠️ No secrets found!")
        
        # Extract MQTT configuration from secrets
        mqtt_endpoint = secrets["iot_endpoint"]
        thing_name = secrets["thing_name"]
        
        cert_dir = secrets["cert_dir"]
        
        logger.info(f"🔍 MQTT Configuration:")
        logger.info(f"   MQTT Endpoint: {mqtt_endpoint}")
        logger.info(f"   Thing Name: {thing_name}")
        logger.info(f"   Certificate Directory: {cert_dir}")

        # Add unique suffix to thing_name for multiple replicas
        thing_name = f"{thing_name}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        logger.info(f"🔧 MQTT client name: {thing_name}")

        # Initialize MQTT client
        mqtt_client = init_mqtt_client(thing_name, mqtt_endpoint, cert_dir)
        
        # Set up MQTT subscription for centralized responses
        # Use topics from secrets instead of hardcoded values
        request_topic = secrets["request_topic"]
        response_topic = secrets["response_topic"]
        
        logger.info(f"   Request Topic Pattern: {request_topic}")
        logger.info(f"   Response Topic Pattern: {response_topic}")
        
        logger.info(f"🔧 Setting up MQTT subscription...")
        logger.info(f"🔧 Request topic pattern: {request_topic}")
        logger.info(f"🔧 Response topic pattern: {response_topic}")
        logger.info(f"🔧 Thing name: {thing_name}")
        logger.info(f"🔧 QoS level: 1")
        
        # Create a closure to capture the link manager and event loop
        main_loop = asyncio.get_event_loop()
        def message_handler(client, _userdata, message):
            on_message_callback(client, {
                'link_manager': link_manager,
                'main_loop': main_loop
            }, message)
        
        logger.info(f"🔧 Attempting to subscribe to MQTT topic...")
        result = mqtt_client.subscribe(response_topic, 1, message_handler)
        if result:
            logger.info(f"📡 MQTT Successfully subscribed to topic: {response_topic}")
        else:
            logger.error(f"❌ MQTT Failed to subscribe to topic: {response_topic}")
        
        logger.debug(f"🔧 Debug: thing_name = '{thing_name}'")
        logger.debug(f"🔧 Debug: Expected to receive messages from topic pattern: {response_topic}")
        
        # Test MQTT connectivity by publishing a test message to ourselves
        test_topic = response_topic.replace("+", f"test-{thing_name}")
        test_message = json.dumps({"test": True, "timestamp": datetime.now().isoformat()})
        try:
            mqtt_client.publish(test_topic, test_message, 0)
            logger.info(f"🧪 Published test message to: {test_topic}")
        except Exception as e:
            logger.error(f"❌ Failed to publish test message: {e}")
        
        logger.info("🚀 Starting message processing loop...")
        logger.info(PerformanceConfig.log_configuration())
        
        if broker_mode == "rabbitmq":
            # RabbitMQ mode - start consuming messages
            # Create async wrapper for handle_link_message
            async def message_wrapper(message: Dict[str, Any]) -> None:
                await handle_link_message(message, mqtt_client, request_topic)
            
            await link_manager.start_consuming(message_wrapper)
            logger.info("✅ RabbitMQ mode: Started consuming link messages")
            
            # Keep running (RabbitMQ handles the message loop)
            while True:
                await asyncio.sleep(1)
        else:
            logger.error("❌ Only RabbitMQ mode is supported")
            raise ValueError("Only RabbitMQ mode is supported")
            
    except Exception as e:
        logger.error(f"Fatal error in process_messages: {e}")
        raise

def run_fastapi():
    """Run FastAPI server in a separate thread"""
    uvicorn.run(app, host="0.0.0.0", port=config.PORT, log_level="info")

async def main():
    """Main function to run both FastAPI and message processing"""
    # Start FastAPI in a separate thread
    fastapi_thread = threading.Thread(target=run_fastapi, daemon=True)
    fastapi_thread.start()
    
    logger.info(f"Health endpoint available at http://0.0.0.0:{config.PORT}/health")
    
    # Start message processing
    await process_messages()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    except Exception as e:
        logger.error(f"Application error: {e}")
        sys.exit(1)
