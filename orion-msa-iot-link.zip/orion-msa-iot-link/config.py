"""
Configuration management for Link microservice
"""

import os
import json
import boto3
import logging
from typing import Dict, Any
from pydantic import BaseModel
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

class BaseConfig(BaseModel):
    """Base configuration model"""
    class Config:
        extra = "allow"
    
    # Environment
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "local")
    AWS_REGION: str = os.getenv("AWS_REGION", "us-east-1")
    
    # Service configuration
    PORT: int = int(os.getenv("PORT", "40082"))
    
    # AWS Secrets Manager
    SECRETS_MANAGER_SECRET_NAME: str = os.getenv("SECRETS_MANAGER_SECRET_NAME", "sps-dev-orion-secret-iot-link")
    AWS_SECRET_NAME: str = os.getenv("AWS_SECRET_NAME", "sps-dev-orion-secret-iot-link")
    
    # IoT Configuration
    IOT_ENDPOINT: str = os.getenv("IOT_ENDPOINT", "")
    IOT_CERT_FOLDER: str = os.getenv("IOT_CERT_FOLDER", "")
    IOT_THING_NAME: str = os.getenv("IOT_THING_NAME", "orion-link")
    
    # SQS Configuration
    LINK_QUEUE_URL: str = os.getenv("LINK_QUEUE_URL", "")
    WORKFLOW_QUEUE_URL: str = os.getenv("WORKFLOW_QUEUE_URL", "")
    STATE_HANDLER_QUEUE_URL: str = os.getenv("STATE_HANDLER_QUEUE_URL", "")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._secrets_cache = None

    def _is_running_in_container(self) -> bool:
        """Check if running in container environment"""
        return os.path.exists("/app") or os.getenv("KUBERNETES_SERVICE_HOST") is not None

    def _get_cert_base_path(self) -> str:
        """Get the base certificate path based on environment"""
        # If IOT_CERT_FOLDER is explicitly set, use it
        if self.IOT_CERT_FOLDER:
            return self.IOT_CERT_FOLDER
        
        # Check if running in container (Docker/Kubernetes)
        if self._is_running_in_container():
            # Running in container - use /app/certs
            cert_dir = "/app/certs"
            logger.info(f"🔧 Detected container environment, using: {cert_dir}")
        else:
            # Running locally - use ./certs
            cert_dir = "./certs"
            logger.info(f"🔧 Detected local environment, using: {cert_dir}")
        
        return cert_dir

    def get_cert_paths(self) -> Dict[str, str]:
        """Get certificate paths based on environment"""
        # Use local file system (same as watcher)
        cert_dir = self._get_cert_base_path()
        environment = self.ENVIRONMENT
        
        cert_paths = {
            "ca_cert": f"{cert_dir}/common/root-CA.crt",
            "cert_file": f"{cert_dir}/{environment}/orion-link-{environment}-certificate.pem.crt",
            "key_file": f"{cert_dir}/{environment}/orion-link-{environment}-private.pem.key"
        }
        
        logger.info(f"🔐 Certificate paths for environment '{environment}':")
        logger.info(f"   CA Certificate: {cert_paths['ca_cert']}")
        logger.info(f"   Client Certificate: {cert_paths['cert_file']}")
        logger.info(f"   Private Key: {cert_paths['key_file']}")
        
        return cert_paths

    def get_secrets(self) -> Dict[str, Any]:
        """Get configuration from AWS Secrets Manager or environment variables"""
        if self._secrets_cache is not None:
            return self._secrets_cache

        if self.ENVIRONMENT == "local" and not self._is_running_in_container():
            # Use environment variables for local development
            self._secrets_cache = {
                "iot_endpoint": self.IOT_ENDPOINT,
                "thing_name": self.IOT_THING_NAME,
                "cert_dir": self._get_cert_base_path(),
                "link_queue": self.LINK_QUEUE_URL,
                "workflow_queue": self.WORKFLOW_QUEUE_URL,
                "state_handler_queue": self.STATE_HANDLER_QUEUE_URL
            }
        else:
            # Use AWS Secrets Manager for cloud environments
            try:
                session = boto3.session.Session()
                client = session.client(
                    service_name="secretsmanager", 
                    region_name=self.AWS_REGION
                )
                
                response = client.get_secret_value(SecretId=self.AWS_SECRET_NAME)
                self._secrets_cache = json.loads(response["SecretString"])
                
                logger.info(f"Successfully loaded secrets from {self.AWS_SECRET_NAME}")
                
            except ClientError as e:
                logger.error(f"Error retrieving secrets from {self.AWS_SECRET_NAME}: {e}")
                raise e
            except Exception as e:
                logger.error(f"Unexpected error loading secrets: {e}")
                raise e

        return self._secrets_cache

# Global configuration instance
config = BaseConfig()