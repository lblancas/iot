# Certificados IoT por Ambiente - Microservicio Link

Esta carpeta contiene los certificados necesarios para la conexión con AWS IoT Core, organizados por ambiente.

## Estrategia de Certificados

El microservicio utiliza archivos locales de certificados, igual que el microservicio `watcher`:

### **🖥️ Desarrollo Local**
- **Fuente**: Archivos locales en `./certs/`
- **Configuración**: Variables de entorno
- **Uso**: Para desarrollo y pruebas locales

### **🐳 Contenedor (Docker/Kubernetes)**
- **Fuente**: Archivos locales copiados al contenedor
- **Configuración**: Automática desde archivos
- **Uso**: Para entornos de producción y staging

## Estructura de Directorios

```
certs/
├── common/
│   └── root-CA.crt                    # Certificado de autoridad raíz (común para todos los ambientes)
├── dev/
│   ├── orion-link-dev-certificate.pem.crt    # Certificado del cliente para ambiente dev
│   └── orion-link-dev-private.pem.key        # Clave privada para ambiente dev
├── qa/
│   ├── orion-link-qa-certificate.pem.crt     # Certificado del cliente para ambiente qa
│   └── orion-link-qa-private.pem.key         # Clave privada para ambiente qa
├── sbx/
│   ├── orion-link-sbx-certificate.pem.crt    # Certificado del cliente para ambiente sbx
│   └── orion-link-sbx-private.pem.key        # Clave privada para ambiente sbx
└── prod/
    ├── orion-link-prod-certificate.pem.crt   # Certificado del cliente para ambiente prod
    └── orion-link-prod-private.pem.key       # Clave privada para ambiente prod
```

## Configuración por Ambiente

El microservicio utiliza la variable de entorno `ENVIRONMENT` para determinar qué certificados usar:

- **ENVIRONMENT=dev**: Usa certificados de `certs/dev/`
- **ENVIRONMENT=qa**: Usa certificados de `certs/qa/`
- **ENVIRONMENT=sbx**: Usa certificados de `certs/sbx/`
- **ENVIRONMENT=prod**: Usa certificados de `certs/prod/`

## Detección Automática de Rutas

El microservicio detecta automáticamente si está ejecutándose localmente o en contenedor:

### **Ejecución Local**
- **Ruta base**: `./certs`
- **Detección**: Automática (cuando no existe `/app` o `KUBERNETES_SERVICE_HOST`)
- **Estrategia**: Archivos locales

### **Ejecución en Contenedor (Docker/Kubernetes)**
- **Ruta base**: `/app/certs`
- **Detección**: Automática (cuando existe `/app` o `KUBERNETES_SERVICE_HOST`)
- **Estrategia**: Archivos locales copiados al contenedor

### **Configuración Manual**
- **Variable**: `IOT_CERT_FOLDER`
- **Ejemplo**: `IOT_CERT_FOLDER=/custom/path/certs`

## Archivos Requeridos

Para cada ambiente, necesitas colocar los siguientes archivos:

### Certificado CA (común)
- **Ubicación**: `certs/common/root-CA.crt`
- **Descripción**: Certificado de autoridad raíz de AWS IoT Core
- **Uso**: Común para todos los ambientes

### Certificados por Ambiente
- **Certificado del cliente**: `certs/{environment}/orion-link-{environment}-certificate.pem.crt`
- **Clave privada**: `certs/{environment}/orion-link-{environment}-private.pem.key`

## Nombres de Archivos

Los archivos deben seguir esta convención de nombres:
- `orion-link-{environment}-certificate.pem.crt`
- `orion-link-{environment}-private.pem.key`

Donde `{environment}` es: `dev`, `qa`, `sbx`, o `prod`.

## Verificación

El microservicio verifica automáticamente:
1. Que todos los archivos de certificados existan
2. Que el certificado y la clave privada coincidan
3. Los detalles del certificado (subject, fingerprint)

## Seguridad

⚠️ **Importante**: 
- Los archivos de certificados y claves privadas están incluidos en el repositorio
- Esto es temporal y se debe cambiar a una solución más segura en producción
- Asegúrate de que tengan los permisos correctos en el contenedor

## Ejemplo de Uso

### **Desarrollo Local**
```bash
# Para ambiente de desarrollo (local)
ENVIRONMENT=dev python main.py

# Para ambiente de QA (local)
ENVIRONMENT=qa python main.py

# Para ambiente de producción (local)
ENVIRONMENT=prod python main.py

# Con ruta personalizada
IOT_CERT_FOLDER=/custom/path/certs ENVIRONMENT=dev python main.py
```

### **Contenedor**
```bash
# Los certificados se copian automáticamente al contenedor
ENVIRONMENT=dev python main.py
```

## Solución de Problemas

### Error: "Certificate file not found"
- Verifica que los archivos existan en las rutas correctas
- Asegúrate de que la variable `ENVIRONMENT` esté configurada correctamente
- Ejecuta el script de verificación: `python3 verify_certs.py`

### Error: "Certificate and private key do NOT match"
- Verifica que el certificado y la clave privada correspondan al mismo par
- Regenera los certificados si es necesario
